# Staffroom Bingo

A daily school-community bingo game. The bundled 500-prompt catalog retains the supplied library with organization-specific wording generalized. Each card has 12 student and 12 staff prompts and a free space. Dates use `America/Edmonton`; change the date helpers and tests if your community needs another time zone.

## Add to a repository and run locally

Extract the ZIP, create an empty GitHub repository, and add the extracted files at its root (including `.github`). Review the prompts and privacy implications before publishing. Do not commit `local.settings.json`, environment files, production keys, connection strings or client secrets. The included `.gitignore` is a safeguard, not a substitute for checking your files before committing.

Use Node.js 22 and serve this folder with a static web server, for example `python -m http.server 4173`, then open `http://localhost:4173`. On localhost, when multiplayer is unavailable, the demo keeps marks, ideas and settings only in that browser's unencrypted local storage. Production does not fall back to demo data.

For tests and the managed API build:

```sh
npm ci --prefix api
npm test
npm run build --prefix api
```

## Privacy and access

The app's main page and multiplayer API require authenticated users; configure a single-tenant sign-in application with assignment required and restrict assignments to intended staff. Static files, including the bundled catalog, are publicly accessible, and a public repository exposes its entire contents. Never put private data in them. Do not expose real staff data without proper authentication. Signed-in participants can see staff display names on daily and overall leaderboards, school names and aggregate points on school rankings, and active approved community prompts. Decide whether this is appropriate under your organization's privacy policies and communicate it to participants before enabling the game. Do not submit student names, identifying details or confidential information in prompts. Demo browser data is not encrypted. Review access, retention, moderation and consent with your organization.

## Configure Azure Static Web Apps

The workflow is a deployment template, not a provisioner. Custom Entra authentication requires the Static Web Apps Standard plan. Use the managed API behind Static Web Apps: the API trusts the principal header supplied by that gateway and must not be exposed directly to untrusted clients. Create your own Static Web App, storage account and app registrations; nothing is provisioned or imported automatically.

1. Register a **single-tenant** Microsoft Entra sign-in app in your own tenant. Add a Web redirect URI `https://<YOUR-SWA-HOST>/.auth/login/aad/callback`. In its Enterprise application, set **Assignment required?** to **Yes**, and assign only the users/groups permitted to play. Replace `REPLACE_WITH_BINGO_TENANT_ID` in `staticwebapp.config.json` with your own tenant GUID. Never use `common` or `organizations`; the issuer must identify the same tenant as the server setting below. The configured UPN claim must actually contain the intended staff email/UPN.
2. Register a separate server-side Graph app in that same tenant. Grant Microsoft Graph **application** permission `User.Read.All` and administrator consent. Graph resolves exactly one matching email/UPN to a GUID object ID and provides display name and office location. The application uses the verified object ID, not a browser-supplied identity or SWA `userId`, for ownership. Accounts with no unique matching directory identity, Graph failures, and identities outside the configured domain fail closed.
3. Create empty Azure Table Storage tables named `TeacherCards`, `BingoSquares`, and `BingoWinners`; the API does not create them. Store the connection string only as a server application setting. No existing data is included or automatically migrated.
4. Configure the following **server-side Static Web App application settings** in Azure. Placeholder descriptions are not credentials; never put actual values in this repository.

   | Setting | Value |
   | --- | --- |
   | `BINGO_MULTIPLAYER_ENABLED` | `false` during setup; `true` only after checks and catalog import |
   | `BINGO_SWA_USER_DETAILS_IS_EMAIL` | unset or `false` until the private identity check below; then `true` |
   | `BINGO_TENANT_ID` | Your tenant GUID, identical to the issuer tenant |
   | `BINGO_ALLOWED_EMAIL_DOMAIN` | Your one exact staff email/UPN domain, without `@` (for example `school.example`); no wildcards |
   | `BINGO_STORAGE_CONNECTION` | Your storage connection string, kept secret |
   | `AZURE_CLIENT_ID` | The single-tenant sign-in app client ID |
   | `AZURE_CLIENT_SECRET_APP_SETTING_NAME` | The sign-in app client secret, under this exact setting name |
   | `GRAPH_CLIENT_ID` | The Graph app client ID |
   | `GRAPH_CLIENT_SECRET` | The Graph app client secret |

5. Add the Static Web App deployment token as the GitHub Actions repository secret `AZURE_STATIC_WEB_APPS_API_TOKEN`. Push to `main` to validate and deploy. Pull requests validate without deploying. The workflow stages only the public frontend into `public`, sets `app_location: public`, and builds the managed API from `api` with `npm run build`; the API build copies the shared game/catalog modules. Keep `skip_app_build: true` and do not set `skip_api_build`. The deployment token is a secret, not source code.
6. With multiplayer still disabled, sign in and privately inspect `/.auth/me`: verify `userDetails` is your expected staff email/UPN in the configured domain; do not share the response. In Static Web App **Role Management**, invite your own account using that same identity, choose the correct site domain and the lowercase custom role `admin`, accept the invitation, and privately verify that role in `/.auth/me`. Set `BINGO_SWA_USER_DETAILS_IS_EMAIL=true` only after this check. The API independently enforces the admin role and Graph verification.
7. Open **Square admin**, choose **Import bundled library**, and confirm all 500 entries were imported. Import is admin-only and available while multiplayer is disabled; it adds missing entries without overwriting existing records. Review and moderate the catalog, test access with an assigned account and rejection with an unassigned or foreign-domain account, then set `BINGO_MULTIPLAYER_ENABLED=true`. Verify cards, synchronized marks, suggestions and the leaderboards. Graph failures prevent multiplayer access; school totals exclude cards without a verified office location.

Missing or invalid tenant/domain configuration, storage/Graph settings, or identity confirmation prevents access. Keep the issuer and backend tenant setting aligned. Email/UPN can be reassigned: revoke admin roles and end old SWA sessions before changing or reassigning an administrator's address. The API cannot bind a prior SWA session to an immutable OID, so Graph resolves the current directory identity on each request.

The API stores cards per verified object ID and date, uses optimistic concurrency for marks, and stores winner and moderation records in the tables above. Leaderboards resolve display names from Graph; school totals use each card's verified saved office location. Changing a location does not backfill old cards.

References: [SWA custom authentication](https://learn.microsoft.com/en-us/azure/static-web-apps/authentication-custom), [SWA application settings](https://learn.microsoft.com/en-us/azure/static-web-apps/application-settings), [Graph list users](https://learn.microsoft.com/en-us/graph/api/user-list?view=graph-rest-1.0).
