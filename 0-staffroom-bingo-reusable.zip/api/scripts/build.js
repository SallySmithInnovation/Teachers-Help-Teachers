import { cp, mkdir } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const apiRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const repoRoot = resolve(apiRoot, "..");
const output = resolve(apiRoot, "dist");
const outputSource = resolve(output, "src");

await mkdir(outputSource, { recursive: true });
await cp(resolve(apiRoot, "src"), outputSource, { recursive: true, force: true });
await cp(resolve(repoRoot, "src", "data", "experiences.js"), resolve(outputSource, "shared", "experiences.js"));
await cp(resolve(repoRoot, "src", "game.js"), resolve(outputSource, "shared", "game.js"));
await cp(resolve(repoRoot, "src", "time.js"), resolve(outputSource, "shared", "time.js"));
