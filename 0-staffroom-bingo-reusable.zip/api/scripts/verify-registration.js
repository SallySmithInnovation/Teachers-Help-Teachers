import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { dirname, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const apiRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const apiPackage = JSON.parse(await readFile(resolve(apiRoot, "package.json"), "utf8"));
const host = JSON.parse(await readFile(resolve(apiRoot, "host.json"), "utf8"));
const entryPoint = resolve(apiRoot, apiPackage.main);
assert.equal(apiPackage.main, "dist/src/functions.js");

const routePrefix = host.extensions?.http?.routePrefix ?? "api";
assert.equal(routePrefix, "api");

const registeredFunctions = [];
const functionsCore = {
  setProgrammingModel() {},
  registerFunction(metadata, handler) {
    registeredFunctions.push({ metadata, handler });
  }
};
const Module = createRequire(import.meta.url)("node:module");
const originalLoad = Module._load;
Module._load = function (request, ...args) {
  if (request === "@azure/functions-core") return functionsCore;
  return originalLoad.call(this, request, ...args);
};

try {
  await import(pathToFileURL(entryPoint).href);
} finally {
  Module._load = originalLoad;
}

const byName = new Map(registeredFunctions.map(({ metadata, handler }) => {
  const trigger = Object.values(metadata.bindings).find(({ type }) => type === "httpTrigger");
  assert.ok(trigger, `${metadata.name} must register an HTTP trigger`);
  assert.equal(typeof handler, "function", `${metadata.name} must register a handler`);
  return [metadata.name, { trigger, handler }];
}));
assert.equal(byName.size, registeredFunctions.length, "registered function names must be unique");
for (const { trigger } of byName.values()) {
  assert.doesNotMatch(trigger.route.replace(/^\/+|\/+$/g, ""), /^(admin|runtime)/i,
    `${trigger.route} conflicts with an Azure Functions host reserved route`);
}

function assertHttpRegistration(name, route, methods) {
  const registration = byName.get(name);
  assert.ok(registration, `${name} must be registered by the built API entry point`);
  assert.equal(registration.trigger.route, route);
  assert.deepEqual(registration.trigger.methods, methods);
  assert.equal(registration.trigger.authLevel, "anonymous");
  return registration.handler;
}

assertHttpRegistration("multiplayerStatus", "status", ["GET"]);
const adminCatalog = assertHttpRegistration("adminCatalog", "manage/catalog", ["GET", "POST"]);
const adminCatalogImport = assertHttpRegistration("adminCatalogImport", "manage/catalog/import", ["POST"]);
const adminCatalogExperience = assertHttpRegistration("adminCatalogExperience", "manage/catalog/{id}", ["PATCH"]);
const fakeStorageKey = Buffer.alloc(32).toString("base64");

for (const [name, methods, route] of [
  ["multiplayerStatus", ["GET"], "status"],
  ["adminCatalog", ["GET", "POST"], "manage/catalog"],
  ["adminCatalogImport", ["POST"], "manage/catalog/import"],
  ["adminCatalogExperience", ["PATCH"], "manage/catalog/{id}"]
]) {
  assert.deepEqual(
    { methods, route: `${routePrefix}/${route}` },
    { methods: byName.get(name).trigger.methods, route: `${routePrefix}/${byName.get(name).trigger.route}` }
  );
}

Object.assign(process.env, {
  BINGO_MULTIPLAYER_ENABLED: "false",
  BINGO_SWA_USER_DETAILS_IS_EMAIL: "true",
  BINGO_STORAGE_CONNECTION: `DefaultEndpointsProtocol=https;AccountName=fake-test-only;AccountKey=${fakeStorageKey};TableEndpoint=http://127.0.0.1:10002/fake-test-only;`,
  BINGO_TENANT_ID: "00000000-0000-4000-8000-000000000004",
  BINGO_ALLOWED_EMAIL_DOMAIN: "example.test",
  AZURE_CLIENT_ID: "00000000-0000-4000-8000-000000000005",
  AZURE_CLIENT_SECRET_APP_SETTING_NAME: "FAKE_TEST_AUTH_SECRET_SETTING_NAME",
  GRAPH_CLIENT_ID: "00000000-0000-4000-8000-000000000006",
  GRAPH_CLIENT_SECRET: "fake-unused-test-secret"
});

const principal = Buffer.from(JSON.stringify({
  identityProvider: "aad",
  userId: "00000000-0000-4000-8000-000000000002",
  userDetails: "staff@example.test",
  userRoles: ["anonymous", "authenticated"]
})).toString("base64");
const request = (method) => ({
  method,
  headers: new Headers({ "x-ms-client-principal": principal }),
  params: { id: "test-entry" },
  json: async () => ({})
});
const context = { error() {} };

for (const [handler, method] of [
  [adminCatalog, "GET"],
  [adminCatalog, "POST"],
  [adminCatalogImport, "POST"],
  [adminCatalogExperience, "PATCH"]
]) {
  const response = await handler(request(method), context);
  assert.equal(response.status, 403, `${method} admin route must enforce the admin role`);
  assert.equal(JSON.parse(response.body).error, "The admin role is required for catalog management.");
}

console.log(`Verified ${registeredFunctions.length} Azure Functions registrations from ${apiPackage.main}.`);
