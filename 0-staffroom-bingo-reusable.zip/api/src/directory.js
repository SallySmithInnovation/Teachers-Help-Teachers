import { ClientSecretCredential } from "@azure/identity";
import { getIdentityConfiguration, isAllowedEmail } from "./identity-config.js";

const OBJECT_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function createDirectory(env, {
  credential,
  fetchImpl = fetch
} = {}) {
  const identity = getIdentityConfiguration(env);
  if (!identity) throw new Error("Tenant and allowed email domain must be configured.");
  let tokenCredential = credential;

  async function getProfile(id, token) {
    if (typeof id !== "string" || !OBJECT_ID_PATTERN.test(id)) {
      throw new Error("The directory user ID is invalid.");
    }
    const response = await fetchImpl(
      `https://graph.microsoft.com/v1.0/users/${encodeURIComponent(id)}?$select=id,displayName,officeLocation`,
      { headers: { authorization: `Bearer ${token}` } }
    );
    if (response.status === 404) {
      const error = new Error("The resolved user was not found in the configured tenant.");
      error.status = 404;
      throw error;
    }
    if (!response.ok) throw new Error(`Microsoft Graph returned HTTP ${response.status}.`);
    const profile = await response.json();
    if (!profile || typeof profile.id !== "string" || !OBJECT_ID_PATTERN.test(profile.id)
      || profile.id.toLowerCase() !== id.toLowerCase()) {
      const error = new Error("Microsoft Graph returned a mismatched user profile.");
      error.status = 403;
      throw error;
    }
    return profile;
  }

  async function accessToken() {
    tokenCredential ??= new ClientSecretCredential(
      identity.tenantId,
      env.GRAPH_CLIENT_ID,
      env.GRAPH_CLIENT_SECRET
    );
    const token = await tokenCredential.getToken("https://graph.microsoft.com/.default");
    if (!token?.token) throw new Error("Microsoft Graph did not issue an access token.");
    return token.token;
  }

  return {
    async getUserById(id) {
      return getProfile(id, await accessToken());
    },
    async getUserByEmail(email) {
      if (!isAllowedEmail(email, identity.allowedEmailDomain)) {
        const error = new Error("The authenticated account does not have an address in the configured domain.");
        error.status = 403;
        throw error;
      }

      const normalizedEmail = email.toLowerCase();
      const token = await accessToken();
      const escapedEmail = normalizedEmail.replaceAll("'", "''");
      const url = new URL("https://graph.microsoft.com/v1.0/users");
      url.searchParams.set("$filter", `mail eq '${escapedEmail}' or userPrincipalName eq '${escapedEmail}'`);
      url.searchParams.set("$select", "id,mail,userPrincipalName,officeLocation");
      url.searchParams.set("$top", "2");
      const response = await fetchImpl(
        url,
        { headers: { authorization: `Bearer ${token}` } }
      );
      if (!response.ok) throw new Error(`Microsoft Graph returned HTTP ${response.status}.`);
      const result = await response.json();
      if (!result || !Array.isArray(result.value)) {
        throw new Error("Microsoft Graph returned an invalid user lookup result.");
      }
      if (result.value.length === 0) {
        const error = new Error("User was not found in the configured tenant.");
        error.status = 404;
        throw error;
      }
      if (result.value.length !== 1) {
        const error = new Error("The authenticated account matched multiple directory users.");
        error.status = 409;
        throw error;
      }

      const user = result.value[0];
      if (!user || typeof user !== "object") {
        const error = new Error("Microsoft Graph returned an invalid directory user.");
        error.status = 403;
        throw error;
      }
      const matchesEmail = [user.mail, user.userPrincipalName]
        .some((value) => typeof value === "string" && value.toLowerCase() === normalizedEmail);
      if (typeof user.id !== "string" || !OBJECT_ID_PATTERN.test(user.id) || !matchesEmail) {
        const error = new Error("Microsoft Graph returned an invalid or mismatched directory user.");
        error.status = 403;
        throw error;
      }

      const profile = await getProfile(user.id, token);
      return {
        id: profile.id,
        mail: user.mail,
        userPrincipalName: user.userPrincipalName,
        officeLocation: profile.officeLocation,
        displayName: profile.displayName
      };
    }
  };
}
