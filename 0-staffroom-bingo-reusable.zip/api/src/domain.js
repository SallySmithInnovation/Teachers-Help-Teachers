import { randomUUID } from "node:crypto";
import { experiences as sourceExperiences } from "./shared/experiences.js";
import { countMarkedSquares, createDailyCard, detectBingos } from "./shared/game.js";
import { getEdmontonDateKey } from "./shared/time.js";
import { getIdentityConfiguration, isAllowedEmail } from "./identity-config.js";

const OBJECT_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const CATALOG_ID_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const FREE_INDEX = 12;
const RARITIES = new Set(["common", "uncommon", "rare"]);
const MODERATION_STATES = new Set(["pending", "approved", "rejected"]);
const CATALOG_FIELDS = ["text", "category", "level", "rarity", "active", "moderationState"];
const PRIVATE_IDENTITY_PATTERN = /[^\s@]+@[^\s@]+\.[^\s@]+|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;

export class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export function serviceConfigured(env) {
  return Boolean(getIdentityConfiguration(env))
    && Boolean(env.BINGO_STORAGE_CONNECTION)
    && OBJECT_ID_PATTERN.test(env.AZURE_CLIENT_ID ?? "")
    && Boolean(env.AZURE_CLIENT_SECRET_APP_SETTING_NAME)
    && OBJECT_ID_PATTERN.test(env.GRAPH_CLIENT_ID ?? "")
    && Boolean(env.GRAPH_CLIENT_SECRET);
}

export function multiplayerConfigured(env) {
  return env.BINGO_MULTIPLAYER_ENABLED === "true"
    && env.BINGO_SWA_USER_DETAILS_IS_EMAIL === "true"
    && serviceConfigured(env);
}

export function parsePrincipal(header) {
  if (typeof header !== "string" || header.length === 0 || header.length > 8192
    || !/^[A-Za-z0-9+/]+={0,2}$/.test(header) || header.length % 4 !== 0) {
    return null;
  }

  try {
    const principal = JSON.parse(Buffer.from(header, "base64").toString("utf8"));
    if (!principal || typeof principal !== "object" || Array.isArray(principal)) return null;
    if (typeof principal.identityProvider !== "string"
      || typeof principal.userDetails !== "string"
      || typeof principal.userId !== "string"
      || !Array.isArray(principal.userRoles)
      || principal.userRoles.some((role) => typeof role !== "string")) {
      return null;
    }
    return principal;
  } catch {
    return null;
  }
}

export function normalizeOffice(officeLocation) {
  if (typeof officeLocation !== "string") return null;
  const label = officeLocation.normalize("NFKC").replace(/[\u0000-\u001f\u007f]/g, "").trim().replace(/\s+/g, " ");
  if (!label || label.length > 100) return null;
  return { key: label.toLocaleLowerCase("en-CA"), label };
}

function displayName(value) {
  if (typeof value !== "string") return null;
  const name = value.normalize("NFKC").replace(/[\u0000-\u001f\u007f]/g, "").trim().replace(/\s+/g, " ");
  return name && name.length <= 200 && !PRIVATE_IDENTITY_PATTERN.test(name) ? name : null;
}

function sortedEntries(entries) {
  return entries
    .sort((left, right) => right.score - left.score || left.name.localeCompare(right.name))
    .slice(0, 10)
    .map(({ name, score }, index) => ({
      name, initials: name.split(" ").slice(0, 2).map((part) => Array.from(part)[0]).join("").toUpperCase(),
      score, rank: index + 1
    }));
}

function storedCatalogRecord(row, includeAdminFields = false) {
  if (!row || typeof row.rowKey !== "string" || !CATALOG_ID_PATTERN.test(row.rowKey)
    || typeof row.text !== "string" || !row.text.trim() || row.text.length > 300
    || typeof row.category !== "string" || !row.category.trim() || row.category.length > 80
    || !["student", "staff"].includes(row.level)
    || !RARITIES.has(row.rarity)
    || typeof row.active !== "boolean"
    || !MODERATION_STATES.has(row.moderationState)) {
    throw new HttpError(503, "The saved experience catalog is invalid.");
  }
  const record = {
    id: row.rowKey,
    text: row.text,
    category: row.category,
    level: row.level,
    rarity: row.rarity,
    active: row.active,
    moderationState: row.moderationState
  };
  if (includeAdminFields) {
    record.submittedBy = row.submittedBy ?? "";
    record.createdBy = row.createdBy ?? "";
    record.moderatedBy = row.moderatedBy ?? "";
    record.moderatedAt = row.moderatedAt ?? "";
    record.updatedBy = row.updatedBy ?? "";
    record.createdAt = row.createdAt ?? "";
    record.updatedAt = row.updatedAt ?? "";
  }
  return record;
}

function gameExperience(record) {
  return {
    id: record.id,
    title: record.text,
    category: record.category,
    audience: record.level
  };
}

function sortedCatalog(rows) {
  return rows.map(storedCatalogRecord).sort((left, right) => left.id.localeCompare(right.id));
}

function buildCard(experienceIds, markedIndices, catalogRows) {
  if (!Array.isArray(experienceIds) || experienceIds.length !== 24
    || new Set(experienceIds).size !== 24
    || !Array.isArray(markedIndices)
    || markedIndices.some((index) => !Number.isInteger(index) || index < 0 || index >= 25 || index === FREE_INDEX)
    || new Set(markedIndices).size !== markedIndices.length
    || !Array.isArray(catalogRows) || catalogRows.length !== experienceIds.length) {
    throw new HttpError(503, "The saved daily card is invalid.");
  }

  const catalog = catalogRows.map(storedCatalogRecord);
  const byId = new Map(catalog.map((experience) => [experience.id, experience]));
  if (experienceIds.some((id) => !byId.has(id))) {
    throw new HttpError(503, "The saved daily card refers to a missing catalog experience.");
  }
  const marked = new Set(markedIndices);
  let experienceIndex = 0;
  const card = Array.from({ length: 25 }, (_, index) => {
    if (index === FREE_INDEX) return { experienceId: null, marked: true };
    return {
      experienceId: experienceIds[experienceIndex++],
      marked: marked.has(index)
    };
  });
  return { card, catalog };
}

function validateMarkInput(body) {
  if (!body || typeof body !== "object" || Array.isArray(body)
    || Object.keys(body).some((key) => !["squareIndex", "marked", "expectedVersion"].includes(key))
    || !Number.isInteger(body.squareIndex) || body.squareIndex < 0 || body.squareIndex >= 25 || body.squareIndex === FREE_INDEX
    || typeof body.marked !== "boolean"
    || !Number.isSafeInteger(body.expectedVersion) || body.expectedVersion < 0) {
    throw new HttpError(400, "Provide a square index, desired mark state, and card version.");
  }
}

function parseStoredArray(value) {
  try {
    return JSON.parse(value);
  } catch {
    throw new HttpError(503, "Saved multiplayer data is invalid.");
  }
}

function requestObject(body, allowedKeys) {
  if (!body || typeof body !== "object" || Array.isArray(body)
    || Object.keys(body).some((key) => !allowedKeys.includes(key))) {
    throw new HttpError(400, "The catalog request contains invalid fields.");
  }
}

function requiredText(value, field, maxLength) {
  if (typeof value !== "string" || !value.trim() || value.trim().length > maxLength) {
    throw new HttpError(400, `${field} must be a non-empty string of at most ${maxLength} characters.`);
  }
  return value.trim();
}

function validateCatalogCreate(body) {
  requestObject(body, ["id", ...CATALOG_FIELDS]);
  if (typeof body.id !== "string" || !CATALOG_ID_PATTERN.test(body.id) || body.id.length > 80) {
    throw new HttpError(400, "Catalog IDs must contain lowercase letters, digits, and single hyphens.");
  }
  if (!["student", "staff"].includes(body.level)) {
    throw new HttpError(400, "level must be student or staff.");
  }
  if (body.rarity !== undefined && !RARITIES.has(body.rarity)) {
    throw new HttpError(400, "rarity must be common, uncommon, or rare.");
  }
  if (body.active !== undefined && typeof body.active !== "boolean") {
    throw new HttpError(400, "active must be a boolean.");
  }
  if (body.moderationState !== undefined && !MODERATION_STATES.has(body.moderationState)) {
    throw new HttpError(400, "moderationState must be pending, approved, or rejected.");
  }
  return {
    id: body.id,
    text: requiredText(body.text, "text", 300),
    category: requiredText(body.category, "category", 80),
    level: body.level,
    rarity: body.rarity ?? "common",
    active: body.active ?? false,
    moderationState: body.moderationState ?? "pending"
  };
}

function validateCatalogUpdate(body) {
  requestObject(body, CATALOG_FIELDS);
  if (Object.keys(body).length === 0) {
    throw new HttpError(400, "At least one catalog field must be provided.");
  }
  const patch = {};
  if (Object.hasOwn(body, "text")) patch.text = requiredText(body.text, "text", 300);
  if (Object.hasOwn(body, "category")) patch.category = requiredText(body.category, "category", 80);
  if (Object.hasOwn(body, "level")) {
    if (!["student", "staff"].includes(body.level)) throw new HttpError(400, "level must be student or staff.");
    patch.level = body.level;
  }
  if (Object.hasOwn(body, "rarity")) {
    if (!RARITIES.has(body.rarity)) throw new HttpError(400, "rarity must be common, uncommon, or rare.");
    patch.rarity = body.rarity;
  }
  if (Object.hasOwn(body, "active")) {
    if (typeof body.active !== "boolean") throw new HttpError(400, "active must be a boolean.");
    patch.active = body.active;
  }
  if (Object.hasOwn(body, "moderationState")) {
    if (!MODERATION_STATES.has(body.moderationState)) {
      throw new HttpError(400, "moderationState must be pending, approved, or rejected.");
    }
    patch.moderationState = body.moderationState;
  }
  return patch;
}

function validateSuggestion(body) {
  requestObject(body, ["text", "category", "level"]);
  if (!["student", "staff"].includes(body.level)) {
    throw new HttpError(400, "level must be student or staff.");
  }
  return {
    text: requiredText(body.text, "text", 300),
    category: requiredText(body.category, "category", 80),
    level: body.level
  };
}

export function createBingoService({ store, directory, env, now = () => new Date() }) {
  function requireConfigured() {
    if (!serviceConfigured(env)) {
      throw new HttpError(503, "Bingo multiplayer is not configured.");
    }
  }

  function requireEnabled() {
    requireConfigured();
    if (env.BINGO_MULTIPLAYER_ENABLED !== "true") {
      throw new HttpError(503, "Bingo multiplayer is not enabled.");
    }
  }

  async function authorize(principal, { admin = false, allowDisabled = false } = {}) {
    requireConfigured();
    if (env.BINGO_SWA_USER_DETAILS_IS_EMAIL !== "true") {
      throw new HttpError(503, "Identity verification is unavailable because SWA userDetails is not configured as an email address.");
    }
    if (!allowDisabled) requireEnabled();
    if (!principal || principal.identityProvider !== "aad"
      || !principal.userRoles.includes("authenticated")
      || !isAllowedEmail(principal.userDetails, getIdentityConfiguration(env).allowedEmailDomain)) {
      throw new HttpError(401, "Sign in with an account from the configured organization to use multiplayer.");
    }
    if (admin && !principal.userRoles.includes("admin")) {
      throw new HttpError(403, "The admin role is required for catalog management.");
    }

    let profile;
    try {
      profile = await directory.getUserByEmail(principal.userDetails);
    } catch (error) {
      if ([404, 409].includes(error?.status)) {
        throw new HttpError(403, "This account could not be resolved unambiguously in the configured tenant.");
      }
      throw new HttpError(503, "Identity verification is temporarily unavailable.");
    }
    if (!profile || typeof profile.id !== "string"
      || !OBJECT_ID_PATTERN.test(profile.id)
      || ![profile.mail, profile.userPrincipalName].some((value) =>
        typeof value === "string" && value.toLowerCase() === principal.userDetails.toLowerCase())) {
      throw new HttpError(403, "This account is not present in the configured tenant.");
    }

    return {
      entraObjectId: profile.id.toLowerCase(),
      school: normalizeOffice(profile.officeLocation),
      name: displayName(profile.displayName)
    };
  }

  async function synchronizeSchool(user, dayKey, cardRecord) {
    const schoolKey = user.school?.key ?? "";
    const schoolLabel = user.school?.label ?? "";
    for (let attempt = 0; attempt < 3; attempt++) {
      if (cardRecord.schoolKey === schoolKey && cardRecord.schoolLabel === schoolLabel) {
        return cardRecord;
      }

      try {
        return await store.updateCard({
          ...cardRecord,
          schoolKey,
          schoolLabel,
          updatedAt: now().toISOString()
        }, cardRecord.etag);
      } catch (error) {
        if (![409, 412].includes(error?.status ?? error?.statusCode)) throw error;
        cardRecord = await store.getCard(user.entraObjectId, dayKey);
      }
    }
    if (cardRecord?.schoolKey === schoolKey && cardRecord?.schoolLabel === schoolLabel) return cardRecord;
    throw new HttpError(409, "This card is changing on another device. Retry the request.");
  }

  async function getDailyCardRecord(user, dayKey) {
    const existing = await store.getCard(user.entraObjectId, dayKey);
    if (existing) return existing;
    const catalog = sortedCatalog(await store.listCatalog({ activeOnly: true }));
    let generated;
    try {
      generated = createDailyCard(dayKey, catalog.map(gameExperience));
    } catch (error) {
      if (error instanceof RangeError) {
        throw new HttpError(503, "The active approved catalog needs at least 12 student and 12 staff experiences.");
      }
      throw error;
    }
    const experienceIds = generated.filter((_, index) => index !== FREE_INDEX).map(({ experienceId }) => experienceId);
    const timestamp = now().toISOString();
    return store.getOrCreateCard(user.entraObjectId, dayKey, {
      experienceIdsJson: JSON.stringify(experienceIds),
      markedIndicesJson: JSON.stringify([]),
      version: 0,
      schoolKey: user.school?.key ?? "",
      schoolLabel: user.school?.label ?? "",
      createdAt: timestamp,
      updatedAt: timestamp
    });
  }

  async function loadCard(cardRecord) {
    const experienceIds = parseStoredArray(cardRecord.experienceIdsJson);
    const markedIndices = parseStoredArray(cardRecord.markedIndicesJson);
    const catalogRows = Array.isArray(experienceIds)
      ? await store.getCatalogExperiences(experienceIds)
      : null;
    return buildCard(experienceIds, markedIndices, catalogRows);
  }

  async function getCard(principal) {
    const user = await authorize(principal);
    const dayKey = getEdmontonDateKey(now());
    let cardRecord = await getDailyCardRecord(user, dayKey);
    cardRecord = await synchronizeSchool(user, dayKey, cardRecord);
    const loaded = await loadCard(cardRecord);
    if (!Number.isSafeInteger(cardRecord.version) || cardRecord.version < 0) {
      throw new HttpError(503, "The saved daily card version is invalid.");
    }
    const bingos = detectBingos(loaded.card);
    if (bingos.length > 0) {
      await store.createWinner({
        entraObjectId: user.entraObjectId,
        dayKey,
        lineId: bingos[0],
        schoolKey: user.school?.key ?? "",
        schoolLabel: user.school?.label ?? "",
        points: countMarkedSquares(loaded.card),
        createdAt: now().toISOString()
      });
    }
    const history = await store.listCards({ entraObjectId: user.entraObjectId });
    const overallScores = aggregateScores(history);
    return {
      dayKey,
      card: loaded.card,
      catalog: loaded.catalog,
      bingos,
      points: countMarkedSquares(loaded.card),
      overallPoints: overallScores.get(user.entraObjectId) ?? 0,
      version: cardRecord.version,
      schoolAvailable: Boolean(user.school)
    };
  }

  async function setSquare(principal, body) {
    validateMarkInput(body);
    const user = await authorize(principal);
    const dayKey = getEdmontonDateKey(now());
    let cardRecord = await getDailyCardRecord(user, dayKey);
    cardRecord = await synchronizeSchool(user, dayKey, cardRecord);
    if (!Number.isSafeInteger(cardRecord.version) || cardRecord.version < 0) {
      throw new HttpError(503, "The saved daily card version is invalid.");
    }
    const markedIndices = parseStoredArray(cardRecord.markedIndicesJson);
    if (!Array.isArray(markedIndices) || markedIndices.some((index) =>
      !Number.isInteger(index) || index < 0 || index >= 25 || index === FREE_INDEX)
      || new Set(markedIndices).size !== markedIndices.length) {
      throw new HttpError(503, "Saved square data is invalid.");
    }

    if (body.expectedVersion !== cardRecord.version) {
      if (markedIndices.includes(body.squareIndex) !== body.marked) {
        throw new HttpError(409, "This card changed on another device. Reload it before marking another square.");
      }
    } else if (markedIndices.includes(body.squareIndex) !== body.marked) {
      const nextMarked = body.marked
        ? [...markedIndices, body.squareIndex].sort((left, right) => left - right)
        : markedIndices.filter((index) => index !== body.squareIndex);
      const candidate = {
        ...cardRecord,
        markedIndicesJson: JSON.stringify(nextMarked),
        version: cardRecord.version + 1,
        schoolKey: user.school?.key ?? "",
        schoolLabel: user.school?.label ?? "",
        updatedAt: now().toISOString()
      };
      try {
        cardRecord = await store.updateCard(candidate, cardRecord.etag);
      } catch (error) {
        if ([409, 412].includes(error?.status ?? error?.statusCode)) {
          throw new HttpError(409, "This card changed on another device. Reload it before marking another square.");
        }
        throw error;
      }
    }

    const loaded = await loadCard(cardRecord);
    const bingos = detectBingos(loaded.card);
    let bingoClaimed = false;
    if (bingos.length > 0) {
      bingoClaimed = await store.createWinner({
        entraObjectId: user.entraObjectId,
        dayKey,
        lineId: bingos[0],
        schoolKey: user.school?.key ?? "",
        schoolLabel: user.school?.label ?? "",
        points: countMarkedSquares(loaded.card),
        createdAt: now().toISOString()
      });
    }
    const history = await store.listCards({ entraObjectId: user.entraObjectId });
    return {
      dayKey,
      card: loaded.card,
      catalog: loaded.catalog,
      bingos,
      points: countMarkedSquares(loaded.card),
      overallPoints: aggregateScores(history).get(user.entraObjectId) ?? 0,
      version: cardRecord.version,
      bingoClaimed
    };
  }

  async function getLeaderboards(principal) {
    const user = await authorize(principal);
    const dayKey = getEdmontonDateKey(now());
    const currentCard = await store.getCard(user.entraObjectId, dayKey);
    if (currentCard) await synchronizeSchool(user, dayKey, currentCard);
    const rows = await store.listCards();
    const daily = aggregateScores(rows.filter((row) => row.rowKey === dayKey));
    const overall = aggregateScores(rows);
    const school = new Map();
    for (const row of rows) {
      if (!row.schoolKey && !row.schoolLabel) continue;
      const verifiedSchool = normalizeOffice(row.schoolLabel);
      if (!verifiedSchool || verifiedSchool.key !== row.schoolKey || PRIVATE_IDENTITY_PATTERN.test(verifiedSchool.label)) {
        throw new HttpError(503, "Saved school data is invalid.");
      }
      const score = aggregateScores([row]).get(row.partitionKey);
      const existing = school.get(verifiedSchool.key);
      school.set(verifiedSchool.key, { name: existing?.name ?? verifiedSchool.label, score: (existing?.score ?? 0) + score });
    }

    // Only resolve names that can appear in either top ten, including score ties.
    const candidates = new Set();
    for (const scores of [daily, overall]) {
      const ordered = [...scores.entries()].sort((a, b) => b[1] - a[1]);
      const threshold = ordered[Math.min(9, ordered.length - 1)]?.[1];
      for (const [id, score] of ordered) if (score >= threshold) candidates.add(id);
    }
    const names = new Map();
    const ids = [...candidates];
    for (let offset = 0; offset < ids.length; offset += 10) {
      await Promise.all(ids.slice(offset, offset + 10).map(async (id) => {
        if (!OBJECT_ID_PATTERN.test(id)) throw new HttpError(503, "Saved leaderboard identity is invalid.");
        let name;
        if (id.toLowerCase() === user.entraObjectId) {
          name = user.name;
        } else {
          try {
            const profile = await directory.getUserById(id);
            if (typeof profile?.id !== "string" || profile.id.toLowerCase() !== id.toLowerCase()) {
              throw new Error("Mismatched directory profile.");
            }
            name = displayName(profile.displayName);
          } catch {
            throw new HttpError(503, "Leaderboard names are temporarily unavailable from identity verification.");
          }
        }
        if (!name) throw new HttpError(503, "A leaderboard participant has no verified display name.");
        names.set(id, name);
      }));
    }
    const individualEntries = (scores) => sortedEntries([...scores.entries()]
      .filter(([id]) => names.has(id))
      .map(([id, score]) => ({ name: names.get(id), score })));
    return {
      daily: {
        caption: "Today's points",
        note: "Shared standings for multiplayer.",
        entries: individualEntries(daily)
      },
      overall: {
        caption: "Overall points · all cards",
        note: "Your marks sync across devices.",
        entries: individualEntries(overall)
      },
      school: {
        caption: "School totals · overall points",
        note: "School totals use verified Entra office locations saved with each card; cards without one are excluded.",
        entries: sortedEntries([...school.values()])
      }
    };
  }

  async function getCatalog(principal) {
    await authorize(principal);
    return sortedCatalog(await store.listCatalog({ activeOnly: true }));
  }

  async function getMySuggestions(principal) {
    const user = await authorize(principal);
    return (await store.listCatalog({ submittedBy: user.entraObjectId }))
      .map((row) => storedCatalogRecord(row, true))
      .map(({ id, text, category, level, moderationState, createdAt }) => ({
        id,
        text,
        category,
        level,
        moderationState,
        createdAt
      }))
      .sort((left, right) => left.createdAt.localeCompare(right.createdAt));
  }

  async function submitSuggestion(principal, body) {
    const user = await authorize(principal);
    const suggestion = validateSuggestion(body);
    const timestamp = now().toISOString();
    const record = {
      ...suggestion,
      id: `suggestion-${randomUUID().replaceAll("-", "")}`,
      rarity: "common",
      active: false,
      moderationState: "pending",
      submittedBy: user.entraObjectId,
      createdBy: user.entraObjectId,
      updatedBy: user.entraObjectId,
      createdAt: timestamp,
      updatedAt: timestamp
    };
    if (!await store.createCatalogExperience(record)) {
      throw new HttpError(409, "The suggestion could not be saved. Please try again.");
    }
    return {
      id: record.id,
      text: record.text,
      category: record.category,
      level: record.level,
      moderationState: record.moderationState,
      createdAt: record.createdAt
    };
  }

  async function getAdminCatalog(principal) {
    const user = await authorize(principal, { admin: true, allowDisabled: true });
    return (await store.listCatalog())
      .map((row) => ({
        ...storedCatalogRecord(row, true),
        isOwnSuggestion: typeof row.submittedBy === "string"
          && row.submittedBy.toLowerCase() === user.entraObjectId
      }))
      .sort((left, right) => left.id.localeCompare(right.id));
  }

  async function importCatalog(principal) {
    const user = await authorize(principal, { admin: true, allowDisabled: true });
    let created = 0;
    const batchSize = 10;
    for (let offset = 0; offset < sourceExperiences.length; offset += batchSize) {
      const batch = await Promise.all(sourceExperiences.slice(offset, offset + batchSize).map((experience) => {
        const timestamp = now().toISOString();
        return store.createCatalogExperience({
          id: experience.id,
          text: experience.title,
          category: experience.category,
          level: experience.audience,
          rarity: "common",
          active: true,
          moderationState: "approved",
          createdBy: "bundled-catalog",
          updatedBy: user.entraObjectId,
          createdAt: timestamp,
          updatedAt: timestamp
        });
      }));
      created += batch.filter(Boolean).length;
    }
    return { created, existing: sourceExperiences.length - created };
  }

  async function createCatalogExperience(principal, body) {
    const user = await authorize(principal, { admin: true, allowDisabled: true });
    const experience = validateCatalogCreate(body);
    const timestamp = now().toISOString();
    const record = {
      ...experience,
      active: experience.moderationState === "approved" && experience.active,
      createdBy: user.entraObjectId,
      updatedBy: user.entraObjectId,
      createdAt: timestamp,
      updatedAt: timestamp
    };
    if (!await store.createCatalogExperience(record)) {
      throw new HttpError(409, "A catalog experience with this ID already exists.");
    }
    return storedCatalogRecord({ ...record, rowKey: record.id }, true);
  }

  async function updateCatalogExperience(principal, id, body) {
    const user = await authorize(principal, { admin: true, allowDisabled: true });
    if (typeof id !== "string" || !CATALOG_ID_PATTERN.test(id) || id.length > 80) {
      throw new HttpError(400, "The catalog ID is invalid.");
    }
    const existing = await store.getCatalogExperience(id);
    if (!existing) throw new HttpError(404, "The catalog experience was not found.");
    const patch = validateCatalogUpdate(body);
    if (patch.moderationState === "approved" && existing.submittedBy === user.entraObjectId) {
      throw new HttpError(403, "An administrator cannot approve their own suggestion.");
    }
    if (patch.moderationState && patch.moderationState !== "approved") patch.active = false;
    const timestamp = now().toISOString();
    try {
      return storedCatalogRecord(await store.updateCatalogExperience({
        ...existing,
        id,
        ...patch,
        updatedBy: user.entraObjectId,
        ...(patch.moderationState ? { moderatedBy: user.entraObjectId, moderatedAt: timestamp } : {}),
        updatedAt: timestamp
      }, existing.etag), true);
    } catch (error) {
      if ([409, 412].includes(error?.status ?? error?.statusCode)) {
        throw new HttpError(409, "This catalog experience changed in another admin session. Reload and retry.");
      }
      throw error;
    }
  }

  return {
    getCard,
    getLeaderboards,
    setSquare,
    getCatalog,
    getMySuggestions,
    submitSuggestion,
    getAdminCatalog,
    importCatalog,
    createCatalogExperience,
    updateCatalogExperience
  };
}

function aggregateScores(rows) {
  const scores = new Map();
  for (const row of rows) {
    const marks = parseStoredArray(row.markedIndicesJson);
    if (!Array.isArray(marks) || marks.some((index) => !Number.isInteger(index) || index < 0 || index >= 25 || index === FREE_INDEX)
      || new Set(marks).size !== marks.length) {
      throw new HttpError(503, "Saved square data is invalid.");
    }
    scores.set(row.partitionKey, (scores.get(row.partitionKey) ?? 0) + marks.length);
  }
  return scores;
}
