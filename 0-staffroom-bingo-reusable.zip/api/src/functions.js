import { app } from "@azure/functions";
import { createDirectory } from "./directory.js";
import { createBingoService, HttpError, multiplayerConfigured, parsePrincipal, serviceConfigured } from "./domain.js";
import { createTableStore } from "./storage.js";

const env = process.env;
let service;

function getService() {
  if (!serviceConfigured(env)) {
    throw new HttpError(503, "Bingo multiplayer is not configured.");
  }
  if (!service) {
    service = createBingoService({
      store: createTableStore(env.BINGO_STORAGE_CONNECTION),
      directory: createDirectory(env),
      env
    });
  }
  return service;
}

function principalFor(request) {
  return parsePrincipal(request.headers.get("x-ms-client-principal"));
}

function jsonResponse(status, body) {
  return {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
    body: JSON.stringify(body)
  };
}

async function handle(request, context, callback, successStatus = 200) {
  try {
    return jsonResponse(successStatus, await callback(getService(), principalFor(request)));
  } catch (error) {
    const status = error instanceof HttpError ? error.status : 500;
    if (status >= 500) context.error("Bingo API request failed.");
    return jsonResponse(status, { error: error instanceof HttpError ? error.message : "The request could not be completed." });
  }
}

async function requestBody(request) {
  try {
    return { body: await request.json() };
  } catch {
    return { response: jsonResponse(400, { error: "Request body must be valid JSON." }) };
  }
}

app.http("multiplayerStatus", {
  route: "status",
  methods: ["GET"],
  authLevel: "anonymous",
  handler: async () => jsonResponse(200, {
    enabled: multiplayerConfigured(env),
    signInPath: "/.auth/login/aad"
  })
});

app.http("card", {
  route: "card",
  methods: ["GET"],
  authLevel: "anonymous",
  handler: (request, context) => handle(request, context, (api, principal) => api.getCard(principal))
});

app.http("markSquare", {
  route: "marks",
  methods: ["PUT"],
  authLevel: "anonymous",
  handler: async (request, context) => {
    const { body, response } = await requestBody(request);
    if (response) return response;
    return handle(request, context, (api, principal) => api.setSquare(principal, body));
  }
});

app.http("leaderboards", {
  route: "leaderboards",
  methods: ["GET"],
  authLevel: "anonymous",
  handler: (request, context) => handle(request, context, (api, principal) => api.getLeaderboards(principal))
});

app.http("catalog", {
  route: "catalog",
  methods: ["GET"],
  authLevel: "anonymous",
  handler: (request, context) => handle(request, context, (api, principal) => api.getCatalog(principal))
});

app.http("catalogSuggestions", {
  route: "catalog/suggestions",
  methods: ["GET", "POST"],
  authLevel: "anonymous",
  handler: async (request, context) => {
    if (request.method === "GET") {
      return handle(request, context, (api, principal) => api.getMySuggestions(principal));
    }
    const { body, response } = await requestBody(request);
    if (response) return response;
    return handle(request, context, (api, principal) => api.submitSuggestion(principal, body), 201);
  }
});

app.http("adminCatalog", {
  route: "manage/catalog",
  methods: ["GET", "POST"],
  authLevel: "anonymous",
  handler: async (request, context) => {
    if (request.method === "GET") {
      return handle(request, context, (api, principal) => api.getAdminCatalog(principal));
    }
    const { body, response } = await requestBody(request);
    if (response) return response;
    return handle(request, context, (api, principal) => api.createCatalogExperience(principal, body), 201);
  }
});

app.http("adminCatalogImport", {
  route: "manage/catalog/import",
  methods: ["POST"],
  authLevel: "anonymous",
  handler: (request, context) => handle(request, context, (api, principal) => api.importCatalog(principal))
});

app.http("adminCatalogExperience", {
  route: "manage/catalog/{id}",
  methods: ["PATCH"],
  authLevel: "anonymous",
  handler: async (request, context) => {
    const { body, response } = await requestBody(request);
    if (response) return response;
    return handle(request, context, (api, principal) =>
      api.updateCatalogExperience(principal, request.params.id, body));
  }
});
