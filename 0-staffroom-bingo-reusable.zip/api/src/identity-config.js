const OBJECT_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DOMAIN_PATTERN = /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i;

export function getIdentityConfiguration(env) {
  const tenantId = env.BINGO_TENANT_ID;
  const allowedEmailDomain = env.BINGO_ALLOWED_EMAIL_DOMAIN;
  if (typeof tenantId !== "string" || !OBJECT_ID_PATTERN.test(tenantId)
    || typeof allowedEmailDomain !== "string" || !DOMAIN_PATTERN.test(allowedEmailDomain)) {
    return null;
  }
  return { tenantId, allowedEmailDomain: allowedEmailDomain.toLowerCase() };
}

export function isAllowedEmail(email, allowedEmailDomain) {
  if (typeof email !== "string" || email.length > 254) return false;
  const separator = email.lastIndexOf("@");
  return separator > 0
    && separator === email.indexOf("@")
    && !/\s/.test(email)
    && email.slice(separator + 1).toLowerCase() === allowedEmailDomain;
}
