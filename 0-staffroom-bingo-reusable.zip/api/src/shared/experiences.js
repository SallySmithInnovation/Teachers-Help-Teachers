export { experiences } from "../../../src/data/experiences.js";
