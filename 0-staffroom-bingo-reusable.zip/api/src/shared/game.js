export { countMarkedSquares, createDailyCard, detectBingos } from "../../../src/game.js";
