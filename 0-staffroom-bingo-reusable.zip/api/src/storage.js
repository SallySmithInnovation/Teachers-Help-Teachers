import { TableClient } from "@azure/data-tables";

const CATALOG_PARTITION = "catalog";

function statusOf(error) {
  return error?.statusCode ?? error?.status;
}

function isMissing(error) {
  return statusOf(error) === 404;
}

function isConflict(error) {
  return statusOf(error) === 409;
}

function withoutTableMetadata(entity) {
  const updated = { ...entity };
  delete updated.etag;
  delete updated.timestamp;
  return updated;
}

export function createTableStore(connectionString) {
  if (!connectionString) throw new Error("BINGO_STORAGE_CONNECTION is required.");
  const cards = TableClient.fromConnectionString(connectionString, "TeacherCards");
  const catalog = TableClient.fromConnectionString(connectionString, "BingoSquares");
  const winners = TableClient.fromConnectionString(connectionString, "BingoWinners");

  async function readOrCreate(table, partitionKey, rowKey, properties) {
    try {
      return await table.getEntity(partitionKey, rowKey);
    } catch (error) {
      if (!isMissing(error)) throw error;
    }
    const entity = { partitionKey, rowKey, ...properties };
    try {
      await table.createEntity(entity);
      return await table.getEntity(partitionKey, rowKey);
    } catch (error) {
      if (!isConflict(error)) throw error;
      return table.getEntity(partitionKey, rowKey);
    }
  }

  async function getCatalogExperience(id) {
    try {
      return await catalog.getEntity(CATALOG_PARTITION, id);
    } catch (error) {
      if (isMissing(error)) return null;
      throw error;
    }
  }

  return {
    async getCard(entraObjectId, dayKey) {
      try {
        return await cards.getEntity(entraObjectId, dayKey);
      } catch (error) {
        if (isMissing(error)) return null;
        throw error;
      }
    },
    getOrCreateCard(entraObjectId, dayKey, properties) {
      return readOrCreate(cards, entraObjectId, dayKey, properties);
    },
    async updateCard(entity, etag) {
      await cards.updateEntity(withoutTableMetadata(entity), "Replace", { etag });
      return cards.getEntity(entity.partitionKey, entity.rowKey);
    },
    async listCards({ entraObjectId, dayKey, schoolKey } = {}) {
      const filters = [];
      if (entraObjectId) filters.push(`PartitionKey eq '${entraObjectId}'`);
      if (dayKey) filters.push(`RowKey eq '${dayKey}'`);
      if (schoolKey) filters.push(`schoolKey eq '${schoolKey.replace(/'/g, "''")}'`);
      const result = [];
      const queryOptions = filters.length > 0 ? { queryOptions: { filter: filters.join(" and ") } } : undefined;
      for await (const entity of cards.listEntities(queryOptions)) result.push(entity);
      return result;
    },
    async getCatalogExperience(id) {
      return getCatalogExperience(id);
    },
    async getCatalogExperiences(ids) {
      const requested = new Set(ids);
      const byId = new Map();
      for await (const entity of catalog.listEntities({
        queryOptions: { filter: `PartitionKey eq '${CATALOG_PARTITION}'` }
      })) {
        if (requested.has(entity.rowKey)) byId.set(entity.rowKey, entity);
      }
      return ids.map((id) => byId.get(id) ?? null);
    },
    async listCatalog({ activeOnly = false, submittedBy } = {}) {
      const result = [];
      const filters = [`PartitionKey eq '${CATALOG_PARTITION}'`];
      if (submittedBy) filters.push(`submittedBy eq '${submittedBy.replace(/'/g, "''")}'`);
      for await (const entity of catalog.listEntities({
        queryOptions: { filter: filters.join(" and ") }
      })) {
        if (!activeOnly || (entity.active === true && entity.moderationState === "approved")) {
          result.push(entity);
        }
      }
      return result;
    },
    async createCatalogExperience(experience) {
      try {
        const entity = {
          partitionKey: CATALOG_PARTITION,
          rowKey: experience.id,
          text: experience.text,
          category: experience.category,
          level: experience.level,
          rarity: experience.rarity,
          active: experience.active,
          moderationState: experience.moderationState,
          createdAt: experience.createdAt,
          updatedAt: experience.updatedAt
        };
        for (const field of ["submittedBy", "createdBy", "updatedBy", "moderatedBy", "moderatedAt"]) {
          if (typeof experience[field] === "string") entity[field] = experience[field];
        }
        await catalog.createEntity(entity);
        return true;
      } catch (error) {
        if (isConflict(error)) return false;
        throw error;
      }
    },
    async updateCatalogExperience(experience, etag) {
      const updated = withoutTableMetadata(experience);
      delete updated.id;
      updated.partitionKey = CATALOG_PARTITION;
      updated.rowKey = experience.id;
      await catalog.updateEntity(updated, "Replace", { etag });
      return getCatalogExperience(experience.id);
    },
    async createWinner(winner) {
      try {
        await winners.createEntity({
          partitionKey: winner.dayKey,
          rowKey: winner.entraObjectId,
          lineId: winner.lineId,
          schoolKey: winner.schoolKey,
          schoolLabel: winner.schoolLabel,
          points: winner.points,
          createdAt: winner.createdAt
        });
        return true;
      } catch (error) {
        if (isConflict(error)) return false;
        throw error;
      }
    }
  };
}
