export const categories = Object.freeze(["General classroom moments","Student logic, quotes, and delightful chaos","Low-key staff challenges","Musical, theatrical, and silly mini-challenges","Technology and Microsoft 365 moments","School-community and innovation moments","Learning wins and wholesome moments","Staff, colleague, and school-community moments","Alberta, weather, and school-day reality","Long-game, rare, and legendary squares"]);

export const experiences = Object.freeze(
[
  {
    "id": "staffroom-bingo-001",
    "title": "A student asks, “Is this for marks?” before you finish the first sentence.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student asks, “Is this for marks?” before you finish the first sentence."
  },
  {
    "id": "staffroom-bingo-002",
    "title": "Someone says, “I was literally just going to do that.”",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "Someone says, “I was literally just going to do that.”"
  },
  {
    "id": "staffroom-bingo-003",
    "title": "A pencil hits the floor during the quietest moment of the day.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "A pencil hits the floor during the quietest moment of the day."
  },
  {
    "id": "staffroom-bingo-004",
    "title": "A student discovers an eraser that has become smaller than a lentil.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student discovers an eraser that has become smaller than a lentil."
  },
  {
    "id": "staffroom-bingo-005",
    "title": "Someone asks what page you are on while the page number is on the board.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "Someone asks what page you are on while the page number is on the board."
  },
  {
    "id": "staffroom-bingo-006",
    "title": "A student confidently answers a different question—and somehow improves the lesson.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student confidently answers a different question—and somehow improves the lesson."
  },
  {
    "id": "staffroom-bingo-007",
    "title": "The class falls silent the instant an administrator walks past the door.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "The class falls silent the instant an administrator walks past the door."
  },
  {
    "id": "staffroom-bingo-008",
    "title": "Someone’s water bottle falls over with the force of a small landslide.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "Someone’s water bottle falls over with the force of a small landslide."
  },
  {
    "id": "staffroom-bingo-009",
    "title": "A student says, “Wait, we had homework?”",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student says, “Wait, we had homework?”"
  },
  {
    "id": "staffroom-bingo-010",
    "title": "Someone borrows a pencil and immediately loses it.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "Someone borrows a pencil and immediately loses it."
  },
  {
    "id": "staffroom-bingo-011",
    "title": "A chair makes an unexpectedly dramatic noise.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A chair makes an unexpectedly dramatic noise."
  },
  {
    "id": "staffroom-bingo-012",
    "title": "A student hands in work with no name but unmistakable artistic flourishes.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student hands in work with no name but unmistakable artistic flourishes."
  },
  {
    "id": "staffroom-bingo-013",
    "title": "Someone asks to go to the washroom less than two minutes after the bell.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "Someone asks to go to the washroom less than two minutes after the bell."
  },
  {
    "id": "staffroom-bingo-014",
    "title": "A student announces that the clock is slow.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student announces that the clock is slow."
  },
  {
    "id": "staffroom-bingo-015",
    "title": "The class debates whether the lights should be on or off.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "The class debates whether the lights should be on or off."
  },
  {
    "id": "staffroom-bingo-016",
    "title": "A student shares a wildly unrelated but genuinely interesting fact.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student shares a wildly unrelated but genuinely interesting fact."
  },
  {
    "id": "staffroom-bingo-017",
    "title": "Someone starts packing up because another person looked at the clock.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "Someone starts packing up because another person looked at the clock."
  },
  {
    "id": "staffroom-bingo-018",
    "title": "A student says, “Nobody told me,” and three classmates provide witnesses.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student says, “Nobody told me,” and three classmates provide witnesses."
  },
  {
    "id": "staffroom-bingo-019",
    "title": "You find a worksheet in a place no worksheet should be.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "You find a worksheet in a place no worksheet should be."
  },
  {
    "id": "staffroom-bingo-020",
    "title": "Someone asks, “What are we doing?” immediately after the instructions.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "Someone asks, “What are we doing?” immediately after the instructions."
  },
  {
    "id": "staffroom-bingo-021",
    "title": "A student produces a snack that requires surprising engineering to open.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student produces a snack that requires surprising engineering to open."
  },
  {
    "id": "staffroom-bingo-022",
    "title": "The classroom pencil sharpener sounds like construction equipment.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "The classroom pencil sharpener sounds like construction equipment."
  },
  {
    "id": "staffroom-bingo-023",
    "title": "Someone uses a ruler as anything except a ruler.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "Someone uses a ruler as anything except a ruler."
  },
  {
    "id": "staffroom-bingo-024",
    "title": "A student asks if spelling counts.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student asks if spelling counts."
  },
  {
    "id": "staffroom-bingo-025",
    "title": "The class notices a typo before you do.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "The class notices a typo before you do."
  },
  {
    "id": "staffroom-bingo-026",
    "title": "Someone says, “That’s what I meant,” after hearing the correct answer.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "Someone says, “That’s what I meant,” after hearing the correct answer."
  },
  {
    "id": "staffroom-bingo-027",
    "title": "A student tries to negotiate the number of required sentences.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student tries to negotiate the number of required sentences."
  },
  {
    "id": "staffroom-bingo-028",
    "title": "A hoodie becomes an emergency storage system.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "A hoodie becomes an emergency storage system."
  },
  {
    "id": "staffroom-bingo-029",
    "title": "Someone asks whether they need to write the date.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "Someone asks whether they need to write the date."
  },
  {
    "id": "staffroom-bingo-030",
    "title": "A student finds an old assignment in the depths of their desk or backpack.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student finds an old assignment in the depths of their desk or backpack."
  },
  {
    "id": "staffroom-bingo-031",
    "title": "The class reacts to a tiny insect as though it has taken command of the room.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "The class reacts to a tiny insect as though it has taken command of the room."
  },
  {
    "id": "staffroom-bingo-032",
    "title": "Someone forgets why they raised their hand.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "Someone forgets why they raised their hand."
  },
  {
    "id": "staffroom-bingo-033",
    "title": "A student begins with, “This might be a weird question, but…”",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student begins with, “This might be a weird question, but…”"
  },
  {
    "id": "staffroom-bingo-034",
    "title": "Someone reads the entire slide aloud without being asked.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "Someone reads the entire slide aloud without being asked."
  },
  {
    "id": "staffroom-bingo-035",
    "title": "A student says, “I knew that,” exactly one second too late.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student says, “I knew that,” exactly one second too late."
  },
  {
    "id": "staffroom-bingo-036",
    "title": "The room temperature becomes a topic of democratic debate.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "The room temperature becomes a topic of democratic debate."
  },
  {
    "id": "staffroom-bingo-037",
    "title": "Someone requests a new seat for reasons involving “the vibes.”",
    "category": "General classroom moments",
    "audience": "student",
    "description": "Someone requests a new seat for reasons involving “the vibes.”"
  },
  {
    "id": "staffroom-bingo-038",
    "title": "A student uses three colours of pen on one line.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student uses three colours of pen on one line."
  },
  {
    "id": "staffroom-bingo-039",
    "title": "Someone opens the wrong notebook with great confidence.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "Someone opens the wrong notebook with great confidence."
  },
  {
    "id": "staffroom-bingo-040",
    "title": "A student asks how long the answer must be before reading the prompt.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student asks how long the answer must be before reading the prompt."
  },
  {
    "id": "staffroom-bingo-041",
    "title": "A student looks for glasses that are already on their face.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student looks for glasses that are already on their face."
  },
  {
    "id": "staffroom-bingo-042",
    "title": "Someone asks, “Can we work with a partner?” before learning the task.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "Someone asks, “Can we work with a partner?” before learning the task."
  },
  {
    "id": "staffroom-bingo-043",
    "title": "A student makes a surprisingly accurate sound effect.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student makes a surprisingly accurate sound effect."
  },
  {
    "id": "staffroom-bingo-044",
    "title": "The class collectively forgets how to line up.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "The class collectively forgets how to line up."
  },
  {
    "id": "staffroom-bingo-045",
    "title": "Someone asks if they can use “etc.” to finish a list.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "Someone asks if they can use “etc.” to finish a list."
  },
  {
    "id": "staffroom-bingo-046",
    "title": "A student turns a minor classroom job into an official appointment.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student turns a minor classroom job into an official appointment."
  },
  {
    "id": "staffroom-bingo-047",
    "title": "Someone whispers louder than most people speak.",
    "category": "General classroom moments",
    "audience": "staff",
    "description": "Someone whispers louder than most people speak."
  },
  {
    "id": "staffroom-bingo-048",
    "title": "A student says, “I’m done,” then discovers the back side.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student says, “I’m done,” then discovers the back side."
  },
  {
    "id": "staffroom-bingo-049",
    "title": "The bell rings at the exact moment you say, “One last thing.”",
    "category": "General classroom moments",
    "audience": "student",
    "description": "The bell rings at the exact moment you say, “One last thing.”"
  },
  {
    "id": "staffroom-bingo-050",
    "title": "A student returns something you had accepted as lost forever.",
    "category": "General classroom moments",
    "audience": "student",
    "description": "A student returns something you had accepted as lost forever."
  },
  {
    "id": "staffroom-bingo-051",
    "title": "A student begins a story with, “So, hypothetically…”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student begins a story with, “So, hypothetically…”"
  },
  {
    "id": "staffroom-bingo-052",
    "title": "Someone says their adult told them they do not have to do something extremely ordinary.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone says their adult told them they do not have to do something extremely ordinary."
  },
  {
    "id": "staffroom-bingo-053",
    "title": "A student explains a complicated game rule more clearly than the lesson directions.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student explains a complicated game rule more clearly than the lesson directions."
  },
  {
    "id": "staffroom-bingo-054",
    "title": "Someone invents a unit of measurement on the spot.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone invents a unit of measurement on the spot."
  },
  {
    "id": "staffroom-bingo-055",
    "title": "A student asks whether a historical person had Wi-Fi.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student asks whether a historical person had Wi-Fi."
  },
  {
    "id": "staffroom-bingo-056",
    "title": "Someone confidently uses a word they have clearly only seen in print.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone confidently uses a word they have clearly only seen in print."
  },
  {
    "id": "staffroom-bingo-057",
    "title": "A student says something so insightful the room goes quiet for the right reason.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student says something so insightful the room goes quiet for the right reason."
  },
  {
    "id": "staffroom-bingo-058",
    "title": "Someone tries to settle a disagreement with rock-paper-scissors.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone tries to settle a disagreement with rock-paper-scissors."
  },
  {
    "id": "staffroom-bingo-059",
    "title": "A student describes yesterday as “back in the old days.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student describes yesterday as “back in the old days.”"
  },
  {
    "id": "staffroom-bingo-060",
    "title": "Someone gives an example that is oddly specific but completely correct.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone gives an example that is oddly specific but completely correct."
  },
  {
    "id": "staffroom-bingo-061",
    "title": "A student asks if zero is “basically nothing wearing a circle.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student asks if zero is “basically nothing wearing a circle.”"
  },
  {
    "id": "staffroom-bingo-062",
    "title": "Someone turns an academic discussion into a passionate debate about cereal.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone turns an academic discussion into a passionate debate about cereal."
  },
  {
    "id": "staffroom-bingo-063",
    "title": "A student uses “technically” and is, annoyingly, technically correct.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student uses “technically” and is, annoyingly, technically correct."
  },
  {
    "id": "staffroom-bingo-064",
    "title": "Someone asks whether the rubric has “a secret level.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone asks whether the rubric has “a secret level.”"
  },
  {
    "id": "staffroom-bingo-065",
    "title": "A student says, “I have a system,” and the system is impossible to explain.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student says, “I have a system,” and the system is impossible to explain."
  },
  {
    "id": "staffroom-bingo-066",
    "title": "Someone refers to a worksheet as “the document.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone refers to a worksheet as “the document.”"
  },
  {
    "id": "staffroom-bingo-067",
    "title": "A student makes a pun and looks around until someone acknowledges it.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student makes a pun and looks around until someone acknowledges it."
  },
  {
    "id": "staffroom-bingo-068",
    "title": "Someone asks a question you need a moment to recover from.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone asks a question you need a moment to recover from."
  },
  {
    "id": "staffroom-bingo-069",
    "title": "A student describes a perfectly ordinary object as “vintage.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student describes a perfectly ordinary object as “vintage.”"
  },
  {
    "id": "staffroom-bingo-070",
    "title": "Someone says, “No offence,” before stating a harmless preference.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone says, “No offence,” before stating a harmless preference."
  },
  {
    "id": "staffroom-bingo-071",
    "title": "A student solves a problem using a method you have never seen but cannot dispute.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student solves a problem using a method you have never seen but cannot dispute."
  },
  {
    "id": "staffroom-bingo-072",
    "title": "Someone calls the interactive board “the big TV.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone calls the interactive board “the big TV.”"
  },
  {
    "id": "staffroom-bingo-073",
    "title": "A student says, “Let me cook,” and then genuinely has a good idea.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student says, “Let me cook,” and then genuinely has a good idea."
  },
  {
    "id": "staffroom-bingo-074",
    "title": "Someone uses a meme reference as supporting evidence.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone uses a meme reference as supporting evidence."
  },
  {
    "id": "staffroom-bingo-075",
    "title": "A student asks if a fictional character could pass the class.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student asks if a fictional character could pass the class."
  },
  {
    "id": "staffroom-bingo-076",
    "title": "Someone describes a two-minute task as “a whole project.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone describes a two-minute task as “a whole project.”"
  },
  {
    "id": "staffroom-bingo-077",
    "title": "A student says, “That was my second guess.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student says, “That was my second guess.”"
  },
  {
    "id": "staffroom-bingo-078",
    "title": "Someone remembers a tiny detail from a lesson weeks ago.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone remembers a tiny detail from a lesson weeks ago."
  },
  {
    "id": "staffroom-bingo-079",
    "title": "A student asks whether neatness earns “bonus aura.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student asks whether neatness earns “bonus aura.”"
  },
  {
    "id": "staffroom-bingo-080",
    "title": "Someone says, “I’m not arguing; I’m explaining.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone says, “I’m not arguing; I’m explaining.”"
  },
  {
    "id": "staffroom-bingo-081",
    "title": "A student gives a compliment that sounds suspiciously like a roast.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student gives a compliment that sounds suspiciously like a roast."
  },
  {
    "id": "staffroom-bingo-082",
    "title": "Someone makes a connection so unexpected that it actually works.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone makes a connection so unexpected that it actually works."
  },
  {
    "id": "staffroom-bingo-083",
    "title": "A student starts an answer with, “According to my calculations…”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student starts an answer with, “According to my calculations…”"
  },
  {
    "id": "staffroom-bingo-084",
    "title": "Someone refers to the class before lunch as “the morning era.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone refers to the class before lunch as “the morning era.”"
  },
  {
    "id": "staffroom-bingo-085",
    "title": "A student becomes official timekeeper and takes the role extremely seriously.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student becomes official timekeeper and takes the role extremely seriously."
  },
  {
    "id": "staffroom-bingo-086",
    "title": "Someone says, “I can’t explain it, but I know it.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone says, “I can’t explain it, but I know it.”"
  },
  {
    "id": "staffroom-bingo-087",
    "title": "A student uses a vocabulary word from class in casual conversation.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student uses a vocabulary word from class in casual conversation."
  },
  {
    "id": "staffroom-bingo-088",
    "title": "Someone asks whether a group of three still counts as partners.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone asks whether a group of three still counts as partners."
  },
  {
    "id": "staffroom-bingo-089",
    "title": "A student declares an ordinary pen “lucky.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student declares an ordinary pen “lucky.”"
  },
  {
    "id": "staffroom-bingo-090",
    "title": "Someone says, “This is easy,” and immediately asks for help.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone says, “This is easy,” and immediately asks for help."
  },
  {
    "id": "staffroom-bingo-091",
    "title": "A student calls a correction “a plot twist.”",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student calls a correction “a plot twist.”"
  },
  {
    "id": "staffroom-bingo-092",
    "title": "Someone asks whether the teacher’s example will be on the test.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone asks whether the teacher’s example will be on the test."
  },
  {
    "id": "staffroom-bingo-093",
    "title": "A student politely challenges an answer key—and is right.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student politely challenges an answer key—and is right."
  },
  {
    "id": "staffroom-bingo-094",
    "title": "Someone turns “show your work” into a full graphic novel.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone turns “show your work” into a full graphic novel."
  },
  {
    "id": "staffroom-bingo-095",
    "title": "A student invents a mnemonic that the entire class remembers.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student invents a mnemonic that the entire class remembers."
  },
  {
    "id": "staffroom-bingo-096",
    "title": "Someone asks for clarification using only a facial expression.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone asks for clarification using only a facial expression."
  },
  {
    "id": "staffroom-bingo-097",
    "title": "A student says, “Respectfully…” and then begins negotiating.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student says, “Respectfully…” and then begins negotiating."
  },
  {
    "id": "staffroom-bingo-098",
    "title": "Someone describes a classroom routine like a sports commentator.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone describes a classroom routine like a sports commentator."
  },
  {
    "id": "staffroom-bingo-099",
    "title": "A student celebrates another student’s correct answer.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "A student celebrates another student’s correct answer."
  },
  {
    "id": "staffroom-bingo-100",
    "title": "Someone laughs at an academic joke without being prompted.",
    "category": "Student logic, quotes, and delightful chaos",
    "audience": "student",
    "description": "Someone laughs at an academic joke without being prompted."
  },
  {
    "id": "staffroom-bingo-101",
    "title": "Use “plot twist” to introduce the next step in a lesson.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Use “plot twist” to introduce the next step in a lesson."
  },
  {
    "id": "staffroom-bingo-102",
    "title": "Work “for legal reasons, that is a joke” naturally into class conversation.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Work “for legal reasons, that is a joke” naturally into class conversation."
  },
  {
    "id": "staffroom-bingo-103",
    "title": "Give a completely sincere “excellent question” before answering.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Give a completely sincere “excellent question” before answering."
  },
  {
    "id": "staffroom-bingo-104",
    "title": "Refer to the stapler as “our most reliable colleague.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Refer to the stapler as “our most reliable colleague.”"
  },
  {
    "id": "staffroom-bingo-105",
    "title": "Say “Let’s circle back” while physically drawing a circle.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Say “Let’s circle back” while physically drawing a circle."
  },
  {
    "id": "staffroom-bingo-106",
    "title": "Use “breaking news” to announce a routine instruction.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Use “breaking news” to announce a routine instruction."
  },
  {
    "id": "staffroom-bingo-107",
    "title": "Call a smooth transition “cinematic.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Call a smooth transition “cinematic.”"
  },
  {
    "id": "staffroom-bingo-108",
    "title": "Say, “I appreciate your commitment to the bit.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Say, “I appreciate your commitment to the bit.”"
  },
  {
    "id": "staffroom-bingo-109",
    "title": "Use “tiny but mighty” to describe a short assignment.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Use “tiny but mighty” to describe a short assignment."
  },
  {
    "id": "staffroom-bingo-110",
    "title": "Work “this is where the magic happens” into an ordinary demonstration.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Work “this is where the magic happens” into an ordinary demonstration."
  },
  {
    "id": "staffroom-bingo-111",
    "title": "Refer to a missing pencil as “an unsolved mystery.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Refer to a missing pencil as “an unsolved mystery.”"
  },
  {
    "id": "staffroom-bingo-112",
    "title": "Say “bold strategy” when a student tries an unusual method.",
    "category": "Low-key staff challenges",
    "audience": "student",
    "description": "Say “bold strategy” when a student tries an unusual method."
  },
  {
    "id": "staffroom-bingo-113",
    "title": "Describe the agenda as “today’s thrilling itinerary.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Describe the agenda as “today’s thrilling itinerary.”"
  },
  {
    "id": "staffroom-bingo-114",
    "title": "Use “administratively speaking” about something trivial.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Use “administratively speaking” about something trivial."
  },
  {
    "id": "staffroom-bingo-115",
    "title": "Call a successful cleanup “a masterclass in efficiency.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Call a successful cleanup “a masterclass in efficiency.”"
  },
  {
    "id": "staffroom-bingo-116",
    "title": "Say “I support this journey” about a harmless student choice.",
    "category": "Low-key staff challenges",
    "audience": "student",
    "description": "Say “I support this journey” about a harmless student choice."
  },
  {
    "id": "staffroom-bingo-117",
    "title": "Announce, “We have achieved paper distribution.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Announce, “We have achieved paper distribution.”"
  },
  {
    "id": "staffroom-bingo-118",
    "title": "Use “the rumours are true” before sharing a normal fact.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Use “the rumours are true” before sharing a normal fact."
  },
  {
    "id": "staffroom-bingo-119",
    "title": "Call the whiteboard marker selection “the colour palette.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Call the whiteboard marker selection “the colour palette.”"
  },
  {
    "id": "staffroom-bingo-120",
    "title": "Say, “That is between you and your future self,” about unfinished work.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Say, “That is between you and your future self,” about unfinished work."
  },
  {
    "id": "staffroom-bingo-121",
    "title": "Refer to a simple checklist as “the official protocol.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Refer to a simple checklist as “the official protocol.”"
  },
  {
    "id": "staffroom-bingo-122",
    "title": "Praise a student’s “elite-level page finding.”",
    "category": "Low-key staff challenges",
    "audience": "student",
    "description": "Praise a student’s “elite-level page finding.”"
  },
  {
    "id": "staffroom-bingo-123",
    "title": "Say “I’ll allow it” about an entirely acceptable answer.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Say “I’ll allow it” about an entirely acceptable answer."
  },
  {
    "id": "staffroom-bingo-124",
    "title": "Describe a quiet classroom as “suspiciously productive.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Describe a quiet classroom as “suspiciously productive.”"
  },
  {
    "id": "staffroom-bingo-125",
    "title": "Use “we love character development” after a corrected mistake.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Use “we love character development” after a corrected mistake."
  },
  {
    "id": "staffroom-bingo-126",
    "title": "Call a minor schedule change “a surprise remix.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Call a minor schedule change “a surprise remix.”"
  },
  {
    "id": "staffroom-bingo-127",
    "title": "Say “Welcome back” to a marker that starts working again.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Say “Welcome back” to a marker that starts working again."
  },
  {
    "id": "staffroom-bingo-128",
    "title": "Refer to a student volunteer as “today’s subject-matter expert.”",
    "category": "Low-key staff challenges",
    "audience": "student",
    "description": "Refer to a student volunteer as “today’s subject-matter expert.”"
  },
  {
    "id": "staffroom-bingo-129",
    "title": "Say “No notes” after an especially good explanation.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Say “No notes” after an especially good explanation."
  },
  {
    "id": "staffroom-bingo-130",
    "title": "Use “a devastating development” when the photocopier is out of paper.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Use “a devastating development” when the photocopier is out of paper."
  },
  {
    "id": "staffroom-bingo-131",
    "title": "Call unclaimed supplies “the lost-and-found starter pack.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Call unclaimed supplies “the lost-and-found starter pack.”"
  },
  {
    "id": "staffroom-bingo-132",
    "title": "Say, “We are entering our focused era.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Say, “We are entering our focused era.”"
  },
  {
    "id": "staffroom-bingo-133",
    "title": "Congratulate the class on surviving a two-step direction.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Congratulate the class on surviving a two-step direction."
  },
  {
    "id": "staffroom-bingo-134",
    "title": "Describe a clear desk as “minimalist design.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Describe a clear desk as “minimalist design.”"
  },
  {
    "id": "staffroom-bingo-135",
    "title": "Say, “I have consulted the evidence,” after checking the schedule.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Say, “I have consulted the evidence,” after checking the schedule."
  },
  {
    "id": "staffroom-bingo-136",
    "title": "Call a clever shortcut “research and development.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Call a clever shortcut “research and development.”"
  },
  {
    "id": "staffroom-bingo-137",
    "title": "Say “This meeting could have been an email” about two math variables meeting.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Say “This meeting could have been an email” about two math variables meeting."
  },
  {
    "id": "staffroom-bingo-138",
    "title": "Refer to the last five minutes as “the season finale.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Refer to the last five minutes as “the season finale.”"
  },
  {
    "id": "staffroom-bingo-139",
    "title": "Use “Please hold your applause” after writing something correctly.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Use “Please hold your applause” after writing something correctly."
  },
  {
    "id": "staffroom-bingo-140",
    "title": "Call an ordinary classroom tool “state-of-the-art.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Call an ordinary classroom tool “state-of-the-art.”"
  },
  {
    "id": "staffroom-bingo-141",
    "title": "Say, “The council has spoken,” after a class vote.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Say, “The council has spoken,” after a class vote."
  },
  {
    "id": "staffroom-bingo-142",
    "title": "Describe a forgotten name on a paper as “anonymous scholarship.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Describe a forgotten name on a paper as “anonymous scholarship.”"
  },
  {
    "id": "staffroom-bingo-143",
    "title": "Use “That sounds like a tomorrow problem” when it truly can wait.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Use “That sounds like a tomorrow problem” when it truly can wait."
  },
  {
    "id": "staffroom-bingo-144",
    "title": "Call a corrected typo “continuous improvement in action.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Call a corrected typo “continuous improvement in action.”"
  },
  {
    "id": "staffroom-bingo-145",
    "title": "Say “We’ve got range” after two very different answers.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Say “We’ve got range” after two very different answers."
  },
  {
    "id": "staffroom-bingo-146",
    "title": "Refer to a well-organized binder as “museum quality.”",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Refer to a well-organized binder as “museum quality.”"
  },
  {
    "id": "staffroom-bingo-147",
    "title": "Say “Nobody panic” before fixing a tiny, non-problematic issue.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Say “Nobody panic” before fixing a tiny, non-problematic issue."
  },
  {
    "id": "staffroom-bingo-148",
    "title": "Call the student who finds the right page “our navigation specialist.”",
    "category": "Low-key staff challenges",
    "audience": "student",
    "description": "Call the student who finds the right page “our navigation specialist.”"
  },
  {
    "id": "staffroom-bingo-149",
    "title": "Use “I respect the confidence” after a boldly incorrect guess.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Use “I respect the confidence” after a boldly incorrect guess."
  },
  {
    "id": "staffroom-bingo-150",
    "title": "Announce “Task failed successfully” when a mistake produces a useful discovery.",
    "category": "Low-key staff challenges",
    "audience": "staff",
    "description": "Announce “Task failed successfully” when a mistake produces a useful discovery."
  },
  {
    "id": "staffroom-bingo-151",
    "title": "Sing one line of “Wonderwall” naturally enough that the lesson continues.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Sing one line of “Wonderwall” naturally enough that the lesson continues."
  },
  {
    "id": "staffroom-bingo-152",
    "title": "Invite a student to mirror an overdramatic pose.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Invite a student to mirror an overdramatic pose."
  },
  {
    "id": "staffroom-bingo-153",
    "title": "Work one clean song lyric into an explanation without announcing it.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Work one clean song lyric into an explanation without announcing it."
  },
  {
    "id": "staffroom-bingo-154",
    "title": "Hum a recognizable tune until one student quietly joins in.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Hum a recognizable tune until one student quietly joins in."
  },
  {
    "id": "staffroom-bingo-155",
    "title": "Enter the room and say, “Ah, my public,” to no one in particular.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Enter the room and say, “Ah, my public,” to no one in particular."
  },
  {
    "id": "staffroom-bingo-156",
    "title": "Narrate ten seconds of classroom activity like a nature documentary.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Narrate ten seconds of classroom activity like a nature documentary."
  },
  {
    "id": "staffroom-bingo-157",
    "title": "Deliver one instruction in a movie-trailer voice.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Deliver one instruction in a movie-trailer voice."
  },
  {
    "id": "staffroom-bingo-158",
    "title": "Use a dramatic pause before revealing a very ordinary answer.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Use a dramatic pause before revealing a very ordinary answer."
  },
  {
    "id": "staffroom-bingo-159",
    "title": "Make a game-show “ding” when a student gets something right.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Make a game-show “ding” when a student gets something right."
  },
  {
    "id": "staffroom-bingo-160",
    "title": "Pretend a working whiteboard marker is a rare and precious artifact.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Pretend a working whiteboard marker is a rare and precious artifact."
  },
  {
    "id": "staffroom-bingo-161",
    "title": "Say “Enhance!” while zooming in on a document or image.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Say “Enhance!” while zooming in on a document or image."
  },
  {
    "id": "staffroom-bingo-162",
    "title": "Use a sports-commentator voice for one successful transition.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Use a sports-commentator voice for one successful transition."
  },
  {
    "id": "staffroom-bingo-163",
    "title": "Quietly add “in this economy?” to an appropriate classroom comment.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Quietly add “in this economy?” to an appropriate classroom comment."
  },
  {
    "id": "staffroom-bingo-164",
    "title": "Use “Previously on…” to recap yesterday’s learning.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Use “Previously on…” to recap yesterday’s learning."
  },
  {
    "id": "staffroom-bingo-165",
    "title": "Make a tiny desk drumroll before revealing the agenda.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Make a tiny desk drumroll before revealing the agenda."
  },
  {
    "id": "staffroom-bingo-166",
    "title": "Give a weather-report-style update on the classroom noise level.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Give a weather-report-style update on the classroom noise level."
  },
  {
    "id": "staffroom-bingo-167",
    "title": "Say “Roll credits” when the final task is complete.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Say “Roll credits” when the final task is complete."
  },
  {
    "id": "staffroom-bingo-168",
    "title": "Use “Meanwhile, in a parallel universe…” to introduce another solution.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Use “Meanwhile, in a parallel universe…” to introduce another solution."
  },
  {
    "id": "staffroom-bingo-169",
    "title": "Give a two-second royal wave when a student greets you dramatically.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Give a two-second royal wave when a student greets you dramatically."
  },
  {
    "id": "staffroom-bingo-170",
    "title": "Use jazz hands to draw attention to an important direction.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Use jazz hands to draw attention to an important direction."
  },
  {
    "id": "staffroom-bingo-171",
    "title": "Announce a routine handout as “fresh from the printer.”",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Announce a routine handout as “fresh from the printer.”"
  },
  {
    "id": "staffroom-bingo-172",
    "title": "Freeze for three seconds when someone says, “Wait, what?” then continue normally.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Freeze for three seconds when someone says, “Wait, what?” then continue normally."
  },
  {
    "id": "staffroom-bingo-173",
    "title": "Use “quest accepted” when a student takes on a challenge.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Use “quest accepted” when a student takes on a challenge."
  },
  {
    "id": "staffroom-bingo-174",
    "title": "Read one sentence as though it is a profound movie monologue.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Read one sentence as though it is a profound movie monologue."
  },
  {
    "id": "staffroom-bingo-175",
    "title": "Give an imaginary microphone to a student with an answer.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Give an imaginary microphone to a student with an answer."
  },
  {
    "id": "staffroom-bingo-176",
    "title": "Use a tiny bow after successfully connecting the interactive board.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Use a tiny bow after successfully connecting the interactive board."
  },
  {
    "id": "staffroom-bingo-177",
    "title": "Say “We ride at dawn” about preparing for tomorrow.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Say “We ride at dawn” about preparing for tomorrow."
  },
  {
    "id": "staffroom-bingo-178",
    "title": "Describe a group task as “a crossover episode.”",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Describe a group task as “a crossover episode.”"
  },
  {
    "id": "staffroom-bingo-179",
    "title": "Use “Cue the montage” before work time.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Use “Cue the montage” before work time."
  },
  {
    "id": "staffroom-bingo-180",
    "title": "Make eye contact with the clock and whisper, “Don’t rush me.”",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Make eye contact with the clock and whisper, “Don’t rush me.”"
  },
  {
    "id": "staffroom-bingo-181",
    "title": "Announce “A challenger approaches” when a hard question appears.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Announce “A challenger approaches” when a hard question appears."
  },
  {
    "id": "staffroom-bingo-182",
    "title": "Do one slow-motion thumbs-up across the room.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Do one slow-motion thumbs-up across the room."
  },
  {
    "id": "staffroom-bingo-183",
    "title": "Say “I’ve seen enough—give them full credit” about a strong sample.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Say “I’ve seen enough—give them full credit” about a strong sample."
  },
  {
    "id": "staffroom-bingo-184",
    "title": "Introduce a familiar routine as though it is a world premiere.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Introduce a familiar routine as though it is a world premiere."
  },
  {
    "id": "staffroom-bingo-185",
    "title": "Say “Some of you have never read the directions, and it shows” with warmth.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Say “Some of you have never read the directions, and it shows” with warmth."
  },
  {
    "id": "staffroom-bingo-186",
    "title": "Use one Shakespearean “alas” for a broken pencil or dry marker.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Use one Shakespearean “alas” for a broken pencil or dry marker."
  },
  {
    "id": "staffroom-bingo-187",
    "title": "Make a suspenseful sound before flipping a page.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Make a suspenseful sound before flipping a page."
  },
  {
    "id": "staffroom-bingo-188",
    "title": "Refer to the document camera as “live television.”",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Refer to the document camera as “live television.”"
  },
  {
    "id": "staffroom-bingo-189",
    "title": "Say “Welcome to my TED Talk” before an explanation under 30 seconds.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Say “Welcome to my TED Talk” before an explanation under 30 seconds."
  },
  {
    "id": "staffroom-bingo-190",
    "title": "Deliver a perfectly timed eyebrow raise that makes a student laugh.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Deliver a perfectly timed eyebrow raise that makes a student laugh."
  },
  {
    "id": "staffroom-bingo-191",
    "title": "Use “This changes everything” about a minor but useful shortcut.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Use “This changes everything” about a minor but useful shortcut."
  },
  {
    "id": "staffroom-bingo-192",
    "title": "Pretend to receive an important message, then announce that it is time to tidy.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Pretend to receive an important message, then announce that it is time to tidy."
  },
  {
    "id": "staffroom-bingo-193",
    "title": "Use one line in a robot voice while discussing technology.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Use one line in a robot voice while discussing technology."
  },
  {
    "id": "staffroom-bingo-194",
    "title": "Give a mock acceptance speech for finding the missing remote.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Give a mock acceptance speech for finding the missing remote."
  },
  {
    "id": "staffroom-bingo-195",
    "title": "Say “The prophecy has been fulfilled” when someone remembers a routine.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Say “The prophecy has been fulfilled” when someone remembers a routine."
  },
  {
    "id": "staffroom-bingo-196",
    "title": "Introduce a partner activity with “Choose your co-star.”",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Introduce a partner activity with “Choose your co-star.”"
  },
  {
    "id": "staffroom-bingo-197",
    "title": "Use a detective voice to investigate an unidentified paper.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Use a detective voice to investigate an unidentified paper."
  },
  {
    "id": "staffroom-bingo-198",
    "title": "Declare a correctly formatted title “absolutely magnificent.”",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "Declare a correctly formatted title “absolutely magnificent.”"
  },
  {
    "id": "staffroom-bingo-199",
    "title": "End with, “Thank you for attending my extremely short seminar.”",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "staff",
    "description": "End with, “Thank you for attending my extremely short seminar.”"
  },
  {
    "id": "staffroom-bingo-200",
    "title": "Get a student to answer your thumbs-up with an even bigger thumbs-up.",
    "category": "Musical, theatrical, and silly mini-challenges",
    "audience": "student",
    "description": "Get a student to answer your thumbs-up with an even bigger thumbs-up."
  },
  {
    "id": "staffroom-bingo-201",
    "title": "The interactive board works on the first try.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "The interactive board works on the first try."
  },
  {
    "id": "staffroom-bingo-202",
    "title": "The interactive board does not work until a student stands nearby.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "The interactive board does not work until a student stands nearby."
  },
  {
    "id": "staffroom-bingo-203",
    "title": "Someone says, “It’s not loading,” less than one second after clicking.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "Someone says, “It’s not loading,” less than one second after clicking."
  },
  {
    "id": "staffroom-bingo-204",
    "title": "A student has 27 browser tabs open and knows where everything is.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student has 27 browser tabs open and knows where everything is."
  },
  {
    "id": "staffroom-bingo-205",
    "title": "Someone forgets a password they used yesterday.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "Someone forgets a password they used yesterday."
  },
  {
    "id": "staffroom-bingo-206",
    "title": "A student solves a tech problem by refreshing the page.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student solves a tech problem by refreshing the page."
  },
  {
    "id": "staffroom-bingo-207",
    "title": "Turning it off and on again actually works.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "Turning it off and on again actually works."
  },
  {
    "id": "staffroom-bingo-208",
    "title": "Someone tries to tap a non-touch screen.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "Someone tries to tap a non-touch screen."
  },
  {
    "id": "staffroom-bingo-209",
    "title": "A student asks whether the file “saved itself.”",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student asks whether the file “saved itself.”"
  },
  {
    "id": "staffroom-bingo-210",
    "title": "A notification sounds and multiple people check their devices.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "A notification sounds and multiple people check their devices."
  },
  {
    "id": "staffroom-bingo-211",
    "title": "Someone shares the wrong screen or tab, but it is harmless and funny.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "Someone shares the wrong screen or tab, but it is harmless and funny."
  },
  {
    "id": "staffroom-bingo-212",
    "title": "A student names a file “final_FINAL_reallyfinal.”",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student names a file “final_FINAL_reallyfinal.”"
  },
  {
    "id": "staffroom-bingo-213",
    "title": "Someone closes the tab they needed most.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "Someone closes the tab they needed most."
  },
  {
    "id": "staffroom-bingo-214",
    "title": "A charger appears from the community supply at exactly the right moment.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A charger appears from the community supply at exactly the right moment."
  },
  {
    "id": "staffroom-bingo-215",
    "title": "A student remembers to mute before a surprise sound happens.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student remembers to mute before a surprise sound happens."
  },
  {
    "id": "staffroom-bingo-216",
    "title": "Someone uses Ctrl+Z and looks genuinely powerful.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "Someone uses Ctrl+Z and looks genuinely powerful."
  },
  {
    "id": "staffroom-bingo-217",
    "title": "A student teaches another student a keyboard shortcut.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student teaches another student a keyboard shortcut."
  },
  {
    "id": "staffroom-bingo-218",
    "title": "The Wi-Fi pauses long enough for everyone to contemplate nature.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "The Wi-Fi pauses long enough for everyone to contemplate nature."
  },
  {
    "id": "staffroom-bingo-219",
    "title": "Someone says “the internet is broken” when one page is slow.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "Someone says “the internet is broken” when one page is slow."
  },
  {
    "id": "staffroom-bingo-220",
    "title": "A student opens Teams and is immediately distracted by the activity bell.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student opens Teams and is immediately distracted by the activity bell."
  },
  {
    "id": "staffroom-bingo-221",
    "title": "Someone locates a file using search instead of scrolling for five minutes.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "Someone locates a file using search instead of scrolling for five minutes."
  },
  {
    "id": "staffroom-bingo-222",
    "title": "A student submits an assignment to the correct place on the first try.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student submits an assignment to the correct place on the first try."
  },
  {
    "id": "staffroom-bingo-223",
    "title": "A file opens in the wrong app and everyone pretends this is normal.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "A file opens in the wrong app and everyone pretends this is normal."
  },
  {
    "id": "staffroom-bingo-224",
    "title": "Someone uses dark mode and receives unsolicited reviews.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "Someone uses dark mode and receives unsolicited reviews."
  },
  {
    "id": "staffroom-bingo-225",
    "title": "A student finds the unmute button without assistance.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student finds the unmute button without assistance."
  },
  {
    "id": "staffroom-bingo-226",
    "title": "The document camera focuses on exactly the wrong thing.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "The document camera focuses on exactly the wrong thing."
  },
  {
    "id": "staffroom-bingo-227",
    "title": "Someone’s battery is at 3%, yet they remain emotionally calm.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "Someone’s battery is at 3%, yet they remain emotionally calm."
  },
  {
    "id": "staffroom-bingo-228",
    "title": "A student effectively uses Immersive Reader, dictation, or another accessibility tool.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student effectively uses Immersive Reader, dictation, or another accessibility tool."
  },
  {
    "id": "staffroom-bingo-229",
    "title": "Someone asks whether to click “Allow” without reading the message.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "Someone asks whether to click “Allow” without reading the message."
  },
  {
    "id": "staffroom-bingo-230",
    "title": "A student creates a surprisingly polished slide transition.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student creates a surprisingly polished slide transition."
  },
  {
    "id": "staffroom-bingo-231",
    "title": "Someone accidentally types into the chat instead of the document.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "Someone accidentally types into the chat instead of the document."
  },
  {
    "id": "staffroom-bingo-232",
    "title": "A student remembers where OneDrive saved the file.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student remembers where OneDrive saved the file."
  },
  {
    "id": "staffroom-bingo-233",
    "title": "The class collectively waits for an update bar to finish.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "The class collectively waits for an update bar to finish."
  },
  {
    "id": "staffroom-bingo-234",
    "title": "Someone says, “Mine looks different,” and they are correct.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "Someone says, “Mine looks different,” and they are correct."
  },
  {
    "id": "staffroom-bingo-235",
    "title": "A student spots the tiny settings gear before any adult does.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student spots the tiny settings gear before any adult does."
  },
  {
    "id": "staffroom-bingo-236",
    "title": "Someone fixes a problem by plugging in the cable all the way.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "Someone fixes a problem by plugging in the cable all the way."
  },
  {
    "id": "staffroom-bingo-237",
    "title": "A student shares a link with the correct permissions.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student shares a link with the correct permissions."
  },
  {
    "id": "staffroom-bingo-238",
    "title": "Someone searches within a page and feels like a wizard.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "Someone searches within a page and feels like a wizard."
  },
  {
    "id": "staffroom-bingo-239",
    "title": "The printer claims to be ready while behaving otherwise.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "The printer claims to be ready while behaving otherwise."
  },
  {
    "id": "staffroom-bingo-240",
    "title": "A student closes a pop-up without clicking the suspicious button.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student closes a pop-up without clicking the suspicious button."
  },
  {
    "id": "staffroom-bingo-241",
    "title": "Someone remembers to save before the device restarts.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "Someone remembers to save before the device restarts."
  },
  {
    "id": "staffroom-bingo-242",
    "title": "A student uses a digital tool because it helps—not just because it sparkles.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student uses a digital tool because it helps—not just because it sparkles."
  },
  {
    "id": "staffroom-bingo-243",
    "title": "Someone switches to airplane mode by accident.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "Someone switches to airplane mode by accident."
  },
  {
    "id": "staffroom-bingo-244",
    "title": "A student creates a useful chart instead of a decorative one.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student creates a useful chart instead of a decorative one."
  },
  {
    "id": "staffroom-bingo-245",
    "title": "The class completes a tech-free task without asking when devices are coming out.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "The class completes a tech-free task without asking when devices are coming out."
  },
  {
    "id": "staffroom-bingo-246",
    "title": "Someone knows what information not to enter into an AI tool.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "Someone knows what information not to enter into an AI tool."
  },
  {
    "id": "staffroom-bingo-247",
    "title": "A student double-checks an AI-generated answer and catches an error.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student double-checks an AI-generated answer and catches an error."
  },
  {
    "id": "staffroom-bingo-248",
    "title": "Someone credits a digital source without being reminded.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "Someone credits a digital source without being reminded."
  },
  {
    "id": "staffroom-bingo-249",
    "title": "A student helps with tech without taking over the other person’s device.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "student",
    "description": "A student helps with tech without taking over the other person’s device."
  },
  {
    "id": "staffroom-bingo-250",
    "title": "The lesson succeeds even though the planned technology does not.",
    "category": "Technology and Microsoft 365 moments",
    "audience": "staff",
    "description": "The lesson succeeds even though the planned technology does not."
  },
  {
    "id": "staffroom-bingo-251",
    "title": "Someone describes a school goal without reading it from a document.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "Someone describes a school goal without reading it from a document."
  },
  {
    "id": "staffroom-bingo-252",
    "title": "A student moment shows how learning strengthens a community.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "A student moment shows how learning strengthens a community."
  },
  {
    "id": "staffroom-bingo-253",
    "title": "Someone shares an encouraging school motto and another person nods knowingly.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "Someone shares an encouraging school motto and another person nods knowingly."
  },
  {
    "id": "staffroom-bingo-254",
    "title": "A staff member turns a small problem into a pilot instead of a giant committee.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A staff member turns a small problem into a pilot instead of a giant committee."
  },
  {
    "id": "staffroom-bingo-255",
    "title": "Someone mentions an innovation group in a classroom-relevant conversation.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "Someone mentions an innovation group in a classroom-relevant conversation."
  },
  {
    "id": "staffroom-bingo-256",
    "title": "A staff member checks the glossary before inventing another acronym.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A staff member checks the glossary before inventing another acronym."
  },
  {
    "id": "staffroom-bingo-257",
    "title": "Someone reminds a colleague to think before sharing a file.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "Someone reminds a colleague to think before sharing a file."
  },
  {
    "id": "staffroom-bingo-258",
    "title": "A classroom choice supports belonging without requiring a big announcement.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A classroom choice supports belonging without requiring a big announcement."
  },
  {
    "id": "staffroom-bingo-259",
    "title": "A student demonstrates engagement, support, and success in under five minutes.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "A student demonstrates engagement, support, and success in under five minutes."
  },
  {
    "id": "staffroom-bingo-260",
    "title": "Someone opens a school resource and finds the needed link on the first try.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "Someone opens a school resource and finds the needed link on the first try."
  },
  {
    "id": "staffroom-bingo-261",
    "title": "A staff member uses a school acronym and then kindly explains it.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A staff member uses a school acronym and then kindly explains it."
  },
  {
    "id": "staffroom-bingo-262",
    "title": "Someone checks a school newsletter and learns something useful about another school.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "Someone checks a school newsletter and learns something useful about another school."
  },
  {
    "id": "staffroom-bingo-263",
    "title": "A school progress snapshot sparks a real conversation.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A school progress snapshot sparks a real conversation."
  },
  {
    "id": "staffroom-bingo-264",
    "title": "Someone shares a story worthy of a community newsletter.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "Someone shares a story worthy of a community newsletter."
  },
  {
    "id": "staffroom-bingo-265",
    "title": "A classroom example connects learning to the local community.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A classroom example connects learning to the local community."
  },
  {
    "id": "staffroom-bingo-266",
    "title": "Someone mentions a Chinook and everyone understands its emotional significance.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "Someone mentions a Chinook and everyone understands its emotional significance."
  },
  {
    "id": "staffroom-bingo-267",
    "title": "A staff member uses Microsoft 365 to remove a repetitive step.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A staff member uses Microsoft 365 to remove a repetitive step."
  },
  {
    "id": "staffroom-bingo-268",
    "title": "Someone describes an innovation that gives time back to students.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "Someone describes an innovation that gives time back to students."
  },
  {
    "id": "staffroom-bingo-269",
    "title": "A student shows digital literacy by asking, “How do we know this is true?”",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "A student shows digital literacy by asking, “How do we know this is true?”"
  },
  {
    "id": "staffroom-bingo-270",
    "title": "Someone balances digital and non-digital learning without starting a philosophical war.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "Someone balances digital and non-digital learning without starting a philosophical war."
  },
  {
    "id": "staffroom-bingo-271",
    "title": "A student uses technology because it adds instructional value.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "A student uses technology because it adds instructional value."
  },
  {
    "id": "staffroom-bingo-272",
    "title": "A staff member skips technology because it does not add instructional value.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A staff member skips technology because it does not add instructional value."
  },
  {
    "id": "staffroom-bingo-273",
    "title": "Someone respectfully mentions privacy before sharing information.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "Someone respectfully mentions privacy before sharing information."
  },
  {
    "id": "staffroom-bingo-274",
    "title": "A staff member finds a helpful Microsoft 365 tutorial.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A staff member finds a helpful Microsoft 365 tutorial."
  },
  {
    "id": "staffroom-bingo-275",
    "title": "Someone contacts Technology Services with enough detail to reproduce the problem.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "Someone contacts Technology Services with enough detail to reproduce the problem."
  },
  {
    "id": "staffroom-bingo-276",
    "title": "A problem resolves immediately after the help desk is contacted.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A problem resolves immediately after the help desk is contacted."
  },
  {
    "id": "staffroom-bingo-277",
    "title": "Someone submits a maintenance request before creating an elaborate workaround.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "Someone submits a maintenance request before creating an elaborate workaround."
  },
  {
    "id": "staffroom-bingo-278",
    "title": "A staff member completes MFA without searching for their phone in panic.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A staff member completes MFA without searching for their phone in panic."
  },
  {
    "id": "staffroom-bingo-279",
    "title": "Someone says “student learning remains at the centre” and means it.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "Someone says “student learning remains at the centre” and means it."
  },
  {
    "id": "staffroom-bingo-280",
    "title": "A student activity builds belonging, agency, or shared responsibility.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "A student activity builds belonging, agency, or shared responsibility."
  },
  {
    "id": "staffroom-bingo-281",
    "title": "Someone uses student feedback to improve a routine.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "Someone uses student feedback to improve a routine."
  },
  {
    "id": "staffroom-bingo-282",
    "title": "A classroom moment reflects responsible innovation rather than novelty.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A classroom moment reflects responsible innovation rather than novelty."
  },
  {
    "id": "staffroom-bingo-283",
    "title": "Someone makes a process more inclusive with one small change.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "Someone makes a process more inclusive with one small change."
  },
  {
    "id": "staffroom-bingo-284",
    "title": "A student makes a meaningful connection to the local community.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "A student makes a meaningful connection to the local community."
  },
  {
    "id": "staffroom-bingo-285",
    "title": "Someone advances literacy or numeracy outside language arts or math.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "Someone advances literacy or numeracy outside language arts or math."
  },
  {
    "id": "staffroom-bingo-286",
    "title": "A staff member shares a practical idea across schools.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A staff member shares a practical idea across schools."
  },
  {
    "id": "staffroom-bingo-287",
    "title": "Someone calls a new approach a pilot and actually collects feedback.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "Someone calls a new approach a pilot and actually collects feedback."
  },
  {
    "id": "staffroom-bingo-288",
    "title": "A student identifies where AI might help—and where a human should decide.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "A student identifies where AI might help—and where a human should decide."
  },
  {
    "id": "staffroom-bingo-289",
    "title": "Someone uses “continuous improvement” about a change people can see.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "Someone uses “continuous improvement” about a change people can see."
  },
  {
    "id": "staffroom-bingo-290",
    "title": "A routine gives students more voice without creating total anarchy.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "A routine gives students more voice without creating total anarchy."
  },
  {
    "id": "staffroom-bingo-291",
    "title": "Someone celebrates a thriving community without sounding like they lost a bet.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "Someone celebrates a thriving community without sounding like they lost a bet."
  },
  {
    "id": "staffroom-bingo-292",
    "title": "A staff member finds the courier schedule before asking three group chats.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A staff member finds the courier schedule before asking three group chats."
  },
  {
    "id": "staffroom-bingo-293",
    "title": "Someone finds the parent portal without asking for directions.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "Someone finds the parent portal without asking for directions."
  },
  {
    "id": "staffroom-bingo-294",
    "title": "A staff member mentions a helpful learning-support tool and someone nearby leans in with interest.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A staff member mentions a helpful learning-support tool and someone nearby leans in with interest."
  },
  {
    "id": "staffroom-bingo-295",
    "title": "A conversation about AI includes privacy, critical thinking, or human agency.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "A conversation about AI includes privacy, critical thinking, or human agency."
  },
  {
    "id": "staffroom-bingo-296",
    "title": "Someone says “responsible innovation” while doing something responsible and innovative.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "Someone says “responsible innovation” while doing something responsible and innovative."
  },
  {
    "id": "staffroom-bingo-297",
    "title": "A student demonstrates that learning transferred to a new situation.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "A student demonstrates that learning transferred to a new situation."
  },
  {
    "id": "staffroom-bingo-298",
    "title": "Someone creates a welcoming, caring, respectful, safe, and inclusive moment.",
    "category": "School-community and innovation moments",
    "audience": "student",
    "description": "Someone creates a welcoming, caring, respectful, safe, and inclusive moment."
  },
  {
    "id": "staffroom-bingo-299",
    "title": "A staff member says “the division” and everyone knows which division.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A staff member says “the division” and everyone knows which division."
  },
  {
    "id": "staffroom-bingo-300",
    "title": "A success could honestly be described as community progress in action.",
    "category": "School-community and innovation moments",
    "audience": "staff",
    "description": "A success could honestly be described as community progress in action."
  },
  {
    "id": "staffroom-bingo-301",
    "title": "A student who rarely volunteers shares an idea.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student who rarely volunteers shares an idea."
  },
  {
    "id": "staffroom-bingo-302",
    "title": "A student revises work without treating feedback as a personal betrayal.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student revises work without treating feedback as a personal betrayal."
  },
  {
    "id": "staffroom-bingo-303",
    "title": "Someone says, “Ohhh, I get it now,” and genuinely does.",
    "category": "Learning wins and wholesome moments",
    "audience": "staff",
    "description": "Someone says, “Ohhh, I get it now,” and genuinely does."
  },
  {
    "id": "staffroom-bingo-304",
    "title": "A student helps a classmate without giving away the answer.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student helps a classmate without giving away the answer."
  },
  {
    "id": "staffroom-bingo-305",
    "title": "Someone uses evidence to change their mind.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "Someone uses evidence to change their mind."
  },
  {
    "id": "staffroom-bingo-306",
    "title": "A student asks for a challenge after finishing.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student asks for a challenge after finishing."
  },
  {
    "id": "staffroom-bingo-307",
    "title": "Someone takes a productive break and returns ready to work.",
    "category": "Learning wins and wholesome moments",
    "audience": "staff",
    "description": "Someone takes a productive break and returns ready to work."
  },
  {
    "id": "staffroom-bingo-308",
    "title": "A student catches and corrects their own mistake.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student catches and corrects their own mistake."
  },
  {
    "id": "staffroom-bingo-309",
    "title": "Someone respectfully disagrees with a classmate.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "Someone respectfully disagrees with a classmate."
  },
  {
    "id": "staffroom-bingo-310",
    "title": "A student asks a question that improves everyone’s understanding.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student asks a question that improves everyone’s understanding."
  },
  {
    "id": "staffroom-bingo-311",
    "title": "Someone uses a strategy from a previous lesson.",
    "category": "Learning wins and wholesome moments",
    "audience": "staff",
    "description": "Someone uses a strategy from a previous lesson."
  },
  {
    "id": "staffroom-bingo-312",
    "title": "A student explains their thinking more clearly the second time.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student explains their thinking more clearly the second time."
  },
  {
    "id": "staffroom-bingo-313",
    "title": "Someone includes a classmate without being prompted.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "Someone includes a classmate without being prompted."
  },
  {
    "id": "staffroom-bingo-314",
    "title": "A student takes a learning risk and survives beautifully.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student takes a learning risk and survives beautifully."
  },
  {
    "id": "staffroom-bingo-315",
    "title": "Someone gives a specific and sincere thank-you.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "Someone gives a specific and sincere thank-you."
  },
  {
    "id": "staffroom-bingo-316",
    "title": "A student recognizes their own progress.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student recognizes their own progress."
  },
  {
    "id": "staffroom-bingo-317",
    "title": "Someone notices that a classmate needs a little space.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "Someone notices that a classmate needs a little space."
  },
  {
    "id": "staffroom-bingo-318",
    "title": "A student chooses the right tool for the task.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student chooses the right tool for the task."
  },
  {
    "id": "staffroom-bingo-319",
    "title": "Someone finishes a difficult task and looks quietly proud.",
    "category": "Learning wins and wholesome moments",
    "audience": "staff",
    "description": "Someone finishes a difficult task and looks quietly proud."
  },
  {
    "id": "staffroom-bingo-320",
    "title": "A student gives useful peer feedback.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student gives useful peer feedback."
  },
  {
    "id": "staffroom-bingo-321",
    "title": "Someone asks for clarification instead of pretending to understand.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "Someone asks for clarification instead of pretending to understand."
  },
  {
    "id": "staffroom-bingo-322",
    "title": "A student connects classroom learning to life outside school.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student connects classroom learning to life outside school."
  },
  {
    "id": "staffroom-bingo-323",
    "title": "Someone celebrates improvement rather than perfection.",
    "category": "Learning wins and wholesome moments",
    "audience": "staff",
    "description": "Someone celebrates improvement rather than perfection."
  },
  {
    "id": "staffroom-bingo-324",
    "title": "A student persists through the “I can’t do this” phase.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student persists through the “I can’t do this” phase."
  },
  {
    "id": "staffroom-bingo-325",
    "title": "Someone uses a calming strategy before reacting.",
    "category": "Learning wins and wholesome moments",
    "audience": "staff",
    "description": "Someone uses a calming strategy before reacting."
  },
  {
    "id": "staffroom-bingo-326",
    "title": "A student appropriately asks for an accommodation or support.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student appropriately asks for an accommodation or support."
  },
  {
    "id": "staffroom-bingo-327",
    "title": "Someone offers a perspective that improves the discussion.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "Someone offers a perspective that improves the discussion."
  },
  {
    "id": "staffroom-bingo-328",
    "title": "A student notices bias, missing voices, or an assumption in a source.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student notices bias, missing voices, or an assumption in a source."
  },
  {
    "id": "staffroom-bingo-329",
    "title": "Someone uses humour to include a classmate, not target them.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "Someone uses humour to include a classmate, not target them."
  },
  {
    "id": "staffroom-bingo-330",
    "title": "A student volunteers for a job nobody usually wants.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student volunteers for a job nobody usually wants."
  },
  {
    "id": "staffroom-bingo-331",
    "title": "Someone remembers a classmate’s preferred name or pronunciation.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "Someone remembers a classmate’s preferred name or pronunciation."
  },
  {
    "id": "staffroom-bingo-332",
    "title": "A student solves a problem collaboratively after trying alone.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student solves a problem collaboratively after trying alone."
  },
  {
    "id": "staffroom-bingo-333",
    "title": "Someone credits the person who contributed the idea.",
    "category": "Learning wins and wholesome moments",
    "audience": "staff",
    "description": "Someone credits the person who contributed the idea."
  },
  {
    "id": "staffroom-bingo-334",
    "title": "A student checks the criteria before submitting.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student checks the criteria before submitting."
  },
  {
    "id": "staffroom-bingo-335",
    "title": "Someone turns a mistake into a useful example.",
    "category": "Learning wins and wholesome moments",
    "audience": "staff",
    "description": "Someone turns a mistake into a useful example."
  },
  {
    "id": "staffroom-bingo-336",
    "title": "A student chooses kindness when a joke could have gone the other way.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student chooses kindness when a joke could have gone the other way."
  },
  {
    "id": "staffroom-bingo-337",
    "title": "Someone recognizes an unreliable source.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "Someone recognizes an unreliable source."
  },
  {
    "id": "staffroom-bingo-338",
    "title": "A student asks, “Can I try it another way?”",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student asks, “Can I try it another way?”"
  },
  {
    "id": "staffroom-bingo-339",
    "title": "Someone uses precise vocabulary without making it weird.",
    "category": "Learning wins and wholesome moments",
    "audience": "staff",
    "description": "Someone uses precise vocabulary without making it weird."
  },
  {
    "id": "staffroom-bingo-340",
    "title": "A student organizes materials before being asked.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student organizes materials before being asked."
  },
  {
    "id": "staffroom-bingo-341",
    "title": "Someone improves the classroom by noticing what needs doing.",
    "category": "Learning wins and wholesome moments",
    "audience": "staff",
    "description": "Someone improves the classroom by noticing what needs doing."
  },
  {
    "id": "staffroom-bingo-342",
    "title": "A student thoughtfully connects to First Nations, Métis, or Inuit perspectives.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student thoughtfully connects to First Nations, Métis, or Inuit perspectives."
  },
  {
    "id": "staffroom-bingo-343",
    "title": "Someone asks whose perspective is missing.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "Someone asks whose perspective is missing."
  },
  {
    "id": "staffroom-bingo-344",
    "title": "A student uses feedback from one subject in another.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student uses feedback from one subject in another."
  },
  {
    "id": "staffroom-bingo-345",
    "title": "Someone creates something that makes classmates say, “That’s actually cool.”",
    "category": "Learning wins and wholesome moments",
    "audience": "staff",
    "description": "Someone creates something that makes classmates say, “That’s actually cool.”"
  },
  {
    "id": "staffroom-bingo-346",
    "title": "A student manages a disagreement without adult intervention.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student manages a disagreement without adult intervention."
  },
  {
    "id": "staffroom-bingo-347",
    "title": "Someone helps reset the room at the end of class.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "Someone helps reset the room at the end of class."
  },
  {
    "id": "staffroom-bingo-348",
    "title": "A student says, “I used to think…, but now I think…”",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student says, “I used to think…, but now I think…”"
  },
  {
    "id": "staffroom-bingo-349",
    "title": "Someone chooses curiosity over certainty.",
    "category": "Learning wins and wholesome moments",
    "audience": "staff",
    "description": "Someone chooses curiosity over certainty."
  },
  {
    "id": "staffroom-bingo-350",
    "title": "A student leaves the class more confident than they entered.",
    "category": "Learning wins and wholesome moments",
    "audience": "student",
    "description": "A student leaves the class more confident than they entered."
  },
  {
    "id": "staffroom-bingo-351",
    "title": "A colleague appears with exactly the supply you need.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A colleague appears with exactly the supply you need."
  },
  {
    "id": "staffroom-bingo-352",
    "title": "Someone says, “Quick question,” and it is actually quick.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone says, “Quick question,” and it is actually quick."
  },
  {
    "id": "staffroom-bingo-353",
    "title": "A colleague uses reply-all only when everyone needs the reply.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A colleague uses reply-all only when everyone needs the reply."
  },
  {
    "id": "staffroom-bingo-354",
    "title": "Someone refills the copier paper instead of walking away.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone refills the copier paper instead of walking away."
  },
  {
    "id": "staffroom-bingo-355",
    "title": "A staff member shares a resource with no expectation of a meeting.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A staff member shares a resource with no expectation of a meeting."
  },
  {
    "id": "staffroom-bingo-356",
    "title": "Someone brings the good whiteboard markers.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone brings the good whiteboard markers."
  },
  {
    "id": "staffroom-bingo-357",
    "title": "A colleague remembers your supervision duty before you do.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A colleague remembers your supervision duty before you do."
  },
  {
    "id": "staffroom-bingo-358",
    "title": "Someone holds a door while carrying an impossible number of things.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone holds a door while carrying an impossible number of things."
  },
  {
    "id": "staffroom-bingo-359",
    "title": "A staff member fixes a tiny problem that has annoyed everyone for weeks.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A staff member fixes a tiny problem that has annoyed everyone for weeks."
  },
  {
    "id": "staffroom-bingo-360",
    "title": "Someone says, “I already made a template,” and saves the day.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone says, “I already made a template,” and saves the day."
  },
  {
    "id": "staffroom-bingo-361",
    "title": "A colleague brings back the item they borrowed.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A colleague brings back the item they borrowed."
  },
  {
    "id": "staffroom-bingo-362",
    "title": "Someone labels the leftovers in the staff room.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone labels the leftovers in the staff room."
  },
  {
    "id": "staffroom-bingo-363",
    "title": "A staff member volunteers to take notes and produces readable notes.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A staff member volunteers to take notes and produces readable notes."
  },
  {
    "id": "staffroom-bingo-364",
    "title": "Someone finds a positive way to describe a chaotic day.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone finds a positive way to describe a chaotic day."
  },
  {
    "id": "staffroom-bingo-365",
    "title": "A colleague checks in at exactly the right time.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A colleague checks in at exactly the right time."
  },
  {
    "id": "staffroom-bingo-366",
    "title": "Someone makes a meeting shorter through excellent preparation.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone makes a meeting shorter through excellent preparation."
  },
  {
    "id": "staffroom-bingo-367",
    "title": "A staff member shares a student success story that lifts the room.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "student",
    "description": "A staff member shares a student success story that lifts the room."
  },
  {
    "id": "staffroom-bingo-368",
    "title": "Someone sends an email with a genuinely useful subject line.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone sends an email with a genuinely useful subject line."
  },
  {
    "id": "staffroom-bingo-369",
    "title": "A colleague says, “You don’t need to reply tonight.”",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A colleague says, “You don’t need to reply tonight.”"
  },
  {
    "id": "staffroom-bingo-370",
    "title": "Someone cleans the microwave without filing a press release.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone cleans the microwave without filing a press release."
  },
  {
    "id": "staffroom-bingo-371",
    "title": "A staff member offers help and waits long enough to hear the answer.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A staff member offers help and waits long enough to hear the answer."
  },
  {
    "id": "staffroom-bingo-372",
    "title": "Someone returns a cart, cable, or key to its actual home.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone returns a cart, cable, or key to its actual home."
  },
  {
    "id": "staffroom-bingo-373",
    "title": "A colleague makes you laugh during a stressful moment.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A colleague makes you laugh during a stressful moment."
  },
  {
    "id": "staffroom-bingo-374",
    "title": "Someone asks, “Is this accessible?” before publishing or printing.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone asks, “Is this accessible?” before publishing or printing."
  },
  {
    "id": "staffroom-bingo-375",
    "title": "A staff member finds a solution that works for students and staff.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A staff member finds a solution that works for students and staff."
  },
  {
    "id": "staffroom-bingo-376",
    "title": "Someone shares credit generously.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone shares credit generously."
  },
  {
    "id": "staffroom-bingo-377",
    "title": "A colleague successfully uses the laminator on the first attempt.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A colleague successfully uses the laminator on the first attempt."
  },
  {
    "id": "staffroom-bingo-378",
    "title": "Someone arrives at a meeting with the correct document already open.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone arrives at a meeting with the correct document already open."
  },
  {
    "id": "staffroom-bingo-379",
    "title": "A staff member remembers the name of a substitute or visiting colleague.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A staff member remembers the name of a substitute or visiting colleague."
  },
  {
    "id": "staffroom-bingo-380",
    "title": "Someone makes coffee before the pot becomes a historical artifact.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone makes coffee before the pot becomes a historical artifact."
  },
  {
    "id": "staffroom-bingo-381",
    "title": "A colleague says, “I can cover that,” and means it.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A colleague says, “I can cover that,” and means it."
  },
  {
    "id": "staffroom-bingo-382",
    "title": "Someone updates the shared document instead of creating “Copy of Copy.”",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone updates the shared document instead of creating “Copy of Copy.”"
  },
  {
    "id": "staffroom-bingo-383",
    "title": "A staff member asks for input before the decision is already made.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A staff member asks for input before the decision is already made."
  },
  {
    "id": "staffroom-bingo-384",
    "title": "Someone provides context when forwarding a message.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone provides context when forwarding a message."
  },
  {
    "id": "staffroom-bingo-385",
    "title": "A colleague notices good work happening quietly.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A colleague notices good work happening quietly."
  },
  {
    "id": "staffroom-bingo-386",
    "title": "Someone solves a scheduling puzzle without saying “moving pieces.”",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone solves a scheduling puzzle without saying “moving pieces.”"
  },
  {
    "id": "staffroom-bingo-387",
    "title": "A staff member shares a shortcut that is actually shorter.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A staff member shares a shortcut that is actually shorter."
  },
  {
    "id": "staffroom-bingo-388",
    "title": "Someone gives a hallway compliment and keeps moving.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone gives a hallway compliment and keeps moving."
  },
  {
    "id": "staffroom-bingo-389",
    "title": "A colleague returns from the printer with your pages too.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A colleague returns from the printer with your pages too."
  },
  {
    "id": "staffroom-bingo-390",
    "title": "Someone admits, “I don’t know,” and then helps find out.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone admits, “I don’t know,” and then helps find out."
  },
  {
    "id": "staffroom-bingo-391",
    "title": "A staff member wisely says, “That can wait until tomorrow.”",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A staff member wisely says, “That can wait until tomorrow.”"
  },
  {
    "id": "staffroom-bingo-392",
    "title": "Someone makes room for another voice in a discussion.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone makes room for another voice in a discussion."
  },
  {
    "id": "staffroom-bingo-393",
    "title": "A colleague catches a typo before it becomes 200 copies.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A colleague catches a typo before it becomes 200 copies."
  },
  {
    "id": "staffroom-bingo-394",
    "title": "Someone remembers the snacks and the dietary needs.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone remembers the snacks and the dietary needs."
  },
  {
    "id": "staffroom-bingo-395",
    "title": "A staff member protects another person’s planning time.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A staff member protects another person’s planning time."
  },
  {
    "id": "staffroom-bingo-396",
    "title": "Someone celebrates a behind-the-scenes contribution.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone celebrates a behind-the-scenes contribution."
  },
  {
    "id": "staffroom-bingo-397",
    "title": "A colleague sends the link instead of saying, “It’s somewhere in Teams.”",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A colleague sends the link instead of saying, “It’s somewhere in Teams.”"
  },
  {
    "id": "staffroom-bingo-398",
    "title": "Someone uses the staff calendar and prevents a surprise conflict.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone uses the staff calendar and prevents a surprise conflict."
  },
  {
    "id": "staffroom-bingo-399",
    "title": "A staff member ends a meeting early and becomes briefly legendary.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "A staff member ends a meeting early and becomes briefly legendary."
  },
  {
    "id": "staffroom-bingo-400",
    "title": "Someone makes the school feel more human on a difficult day.",
    "category": "Staff, colleague, and school-community moments",
    "audience": "staff",
    "description": "Someone makes the school feel more human on a difficult day."
  },
  {
    "id": "staffroom-bingo-401",
    "title": "The temperature changes by ten degrees between arrival and dismissal.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "The temperature changes by ten degrees between arrival and dismissal."
  },
  {
    "id": "staffroom-bingo-402",
    "title": "Someone says, “At least it’s a dry cold.”",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "Someone says, “At least it’s a dry cold.”"
  },
  {
    "id": "staffroom-bingo-403",
    "title": "A student wears shorts during weather that suggests otherwise.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "A student wears shorts during weather that suggests otherwise."
  },
  {
    "id": "staffroom-bingo-404",
    "title": "The wind rearranges everyone’s plans.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "The wind rearranges everyone’s plans."
  },
  {
    "id": "staffroom-bingo-405",
    "title": "A Chinook becomes the most popular member of the school community.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "A Chinook becomes the most popular member of the school community."
  },
  {
    "id": "staffroom-bingo-406",
    "title": "Indoor recess is announced and the room reacts like breaking news.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "Indoor recess is announced and the room reacts like breaking news."
  },
  {
    "id": "staffroom-bingo-407",
    "title": "Outdoor recess is restored and morale rises instantly.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "Outdoor recess is restored and morale rises instantly."
  },
  {
    "id": "staffroom-bingo-408",
    "title": "Someone tracks in snow after stomping their boots “really well.”",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "Someone tracks in snow after stomping their boots “really well.”"
  },
  {
    "id": "staffroom-bingo-409",
    "title": "A mitten appears with no known owner.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "A mitten appears with no known owner."
  },
  {
    "id": "staffroom-bingo-410",
    "title": "A student reports that the playground is “basically an ice rink.”",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "A student reports that the playground is “basically an ice rink.”"
  },
  {
    "id": "staffroom-bingo-411",
    "title": "The sun shines while snow is actively falling.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "The sun shines while snow is actively falling."
  },
  {
    "id": "staffroom-bingo-412",
    "title": "Someone uses a toque as classroom storage.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "Someone uses a toque as classroom storage."
  },
  {
    "id": "staffroom-bingo-413",
    "title": "A boot change takes longer than the activity it precedes.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "A boot change takes longer than the activity it precedes."
  },
  {
    "id": "staffroom-bingo-414",
    "title": "A student insists they are not cold while visibly shivering.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "A student insists they are not cold while visibly shivering."
  },
  {
    "id": "staffroom-bingo-415",
    "title": "The class debates whether the sky means snow, rain, smoke, or all three.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "The class debates whether the sky means snow, rain, smoke, or all three."
  },
  {
    "id": "staffroom-bingo-416",
    "title": "Someone mentions road conditions before saying good morning.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "Someone mentions road conditions before saying good morning."
  },
  {
    "id": "staffroom-bingo-417",
    "title": "A tumbleweed or dramatic piece of debris crosses the school grounds.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "A tumbleweed or dramatic piece of debris crosses the school grounds."
  },
  {
    "id": "staffroom-bingo-418",
    "title": "The room gets too warm because everyone dressed for winter.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "The room gets too warm because everyone dressed for winter."
  },
  {
    "id": "staffroom-bingo-419",
    "title": "Someone loses one glove and believes completely that it will return.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "Someone loses one glove and believes completely that it will return."
  },
  {
    "id": "staffroom-bingo-420",
    "title": "A weather alert and a field-trip plan coexist uneasily.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "A weather alert and a field-trip plan coexist uneasily."
  },
  {
    "id": "staffroom-bingo-421",
    "title": "A student identifies the exact farm equipment visible outside.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "A student identifies the exact farm equipment visible outside."
  },
  {
    "id": "staffroom-bingo-422",
    "title": "Wildlife near the school briefly outranks the lesson.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "Wildlife near the school briefly outranks the lesson."
  },
  {
    "id": "staffroom-bingo-423",
    "title": "Someone sees the mountains clearly and announces it to the room.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "Someone sees the mountains clearly and announces it to the room."
  },
  {
    "id": "staffroom-bingo-424",
    "title": "The parking lot requires advanced winter strategy.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "The parking lot requires advanced winter strategy."
  },
  {
    "id": "staffroom-bingo-425",
    "title": "A student arrives covered in snow when there is almost none outside.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "A student arrives covered in snow when there is almost none outside."
  },
  {
    "id": "staffroom-bingo-426",
    "title": "Someone says, “If you don’t like the weather, wait five minutes.”",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "Someone says, “If you don’t like the weather, wait five minutes.”"
  },
  {
    "id": "staffroom-bingo-427",
    "title": "A classroom window becomes the unofficial weather station.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "A classroom window becomes the unofficial weather station."
  },
  {
    "id": "staffroom-bingo-428",
    "title": "The wind makes a door, sign, or vent sound haunted.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "The wind makes a door, sign, or vent sound haunted."
  },
  {
    "id": "staffroom-bingo-429",
    "title": "A student negotiates coat requirements like a labour lawyer.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "A student negotiates coat requirements like a labour lawyer."
  },
  {
    "id": "staffroom-bingo-430",
    "title": "Someone calls a warm winter day “spring,” knowing better.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "Someone calls a warm winter day “spring,” knowing better."
  },
  {
    "id": "staffroom-bingo-431",
    "title": "Mud season enters the building one boot at a time.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "Mud season enters the building one boot at a time."
  },
  {
    "id": "staffroom-bingo-432",
    "title": "A student uses a snowbank as a scientific case study.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "A student uses a snowbank as a scientific case study."
  },
  {
    "id": "staffroom-bingo-433",
    "title": "Someone remembers sunglasses and mittens on the same day.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "Someone remembers sunglasses and mittens on the same day."
  },
  {
    "id": "staffroom-bingo-434",
    "title": "The class pauses to appreciate an unexpectedly beautiful sky.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "The class pauses to appreciate an unexpectedly beautiful sky."
  },
  {
    "id": "staffroom-bingo-435",
    "title": "A bus delay becomes the day’s main plot.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "A bus delay becomes the day’s main plot."
  },
  {
    "id": "staffroom-bingo-436",
    "title": "Someone says “highway” and three people offer route advice.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "Someone says “highway” and three people offer route advice."
  },
  {
    "id": "staffroom-bingo-437",
    "title": "A student explains rural internet like an expert witness.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "A student explains rural internet like an expert witness."
  },
  {
    "id": "staffroom-bingo-438",
    "title": "The lost-and-found could outfit a small winter expedition.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "The lost-and-found could outfit a small winter expedition."
  },
  {
    "id": "staffroom-bingo-439",
    "title": "A class plant reacts to the season more dramatically than anyone else.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "A class plant reacts to the season more dramatically than anyone else."
  },
  {
    "id": "staffroom-bingo-440",
    "title": "Someone checks the forecast and gets three different answers.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "Someone checks the forecast and gets three different answers."
  },
  {
    "id": "staffroom-bingo-441",
    "title": "A student predicts the weather using a grandparent’s wisdom.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "A student predicts the weather using a grandparent’s wisdom."
  },
  {
    "id": "staffroom-bingo-442",
    "title": "The phrase “dress in layers” proves itself once again.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "The phrase “dress in layers” proves itself once again."
  },
  {
    "id": "staffroom-bingo-443",
    "title": "A gust of wind takes one piece of paper on an adventure.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "A gust of wind takes one piece of paper on an adventure."
  },
  {
    "id": "staffroom-bingo-444",
    "title": "Someone refers to the +2°C afternoon as “beautiful out.”",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "Someone refers to the +2°C afternoon as “beautiful out.”"
  },
  {
    "id": "staffroom-bingo-445",
    "title": "A student treats a puddle like an irresistible research opportunity.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "A student treats a puddle like an irresistible research opportunity."
  },
  {
    "id": "staffroom-bingo-446",
    "title": "A bus conversation begins with wildlife, weather, or both.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "A bus conversation begins with wildlife, weather, or both."
  },
  {
    "id": "staffroom-bingo-447",
    "title": "A staff member has an ice scraper and sunscreen within reach.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "A staff member has an ice scraper and sunscreen within reach."
  },
  {
    "id": "staffroom-bingo-448",
    "title": "Someone hears a snowplow and knows hope.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "student",
    "description": "Someone hears a snowplow and knows hope."
  },
  {
    "id": "staffroom-bingo-449",
    "title": "The class successfully transitions through wet-boot season.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "The class successfully transitions through wet-boot season."
  },
  {
    "id": "staffroom-bingo-450",
    "title": "Alberta weather provides a perfect real-world lesson example.",
    "category": "Alberta, weather, and school-day reality",
    "audience": "staff",
    "description": "Alberta weather provides a perfect real-world lesson example."
  },
  {
    "id": "staffroom-bingo-451",
    "title": "Everyone has a pencil at the same time.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "Everyone has a pencil at the same time."
  },
  {
    "id": "staffroom-bingo-452",
    "title": "Every paper handed in has a name on it.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "Every paper handed in has a name on it."
  },
  {
    "id": "staffroom-bingo-453",
    "title": "A lesson finishes exactly when planned.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "A lesson finishes exactly when planned."
  },
  {
    "id": "staffroom-bingo-454",
    "title": "The class completes a transition faster the second time without prompting.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "The class completes a transition faster the second time without prompting."
  },
  {
    "id": "staffroom-bingo-455",
    "title": "A student returns a borrowed pencil on the same day.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A student returns a borrowed pencil on the same day."
  },
  {
    "id": "staffroom-bingo-456",
    "title": "No one asks what time class ends.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "No one asks what time class ends."
  },
  {
    "id": "staffroom-bingo-457",
    "title": "A full week passes without an orphaned water bottle.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "A full week passes without an orphaned water bottle."
  },
  {
    "id": "staffroom-bingo-458",
    "title": "The correct number of copies comes out of the copier.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "The correct number of copies comes out of the copier."
  },
  {
    "id": "staffroom-bingo-459",
    "title": "A group chooses roles without a constitutional crisis.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "A group chooses roles without a constitutional crisis."
  },
  {
    "id": "staffroom-bingo-460",
    "title": "The floor is cleaner at dismissal than at arrival.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "The floor is cleaner at dismissal than at arrival."
  },
  {
    "id": "staffroom-bingo-461",
    "title": "Every device is charged enough for the task.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "Every device is charged enough for the task."
  },
  {
    "id": "staffroom-bingo-462",
    "title": "A student reads all the instructions before starting.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A student reads all the instructions before starting."
  },
  {
    "id": "staffroom-bingo-463",
    "title": "The class remembers a special schedule change.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "The class remembers a special schedule change."
  },
  {
    "id": "staffroom-bingo-464",
    "title": "Someone finds the original file instead of recreating it.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "Someone finds the original file instead of recreating it."
  },
  {
    "id": "staffroom-bingo-465",
    "title": "A student uses a semicolon correctly and casually.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A student uses a semicolon correctly and casually."
  },
  {
    "id": "staffroom-bingo-466",
    "title": "The last whiteboard marker has plenty of ink.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "The last whiteboard marker has plenty of ink."
  },
  {
    "id": "staffroom-bingo-467",
    "title": "Everyone returns from a break on time.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "Everyone returns from a break on time."
  },
  {
    "id": "staffroom-bingo-468",
    "title": "A debate ends with minds changed and friendships intact.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A debate ends with minds changed and friendships intact."
  },
  {
    "id": "staffroom-bingo-469",
    "title": "A student asks for help before the final two minutes.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A student asks for help before the final two minutes."
  },
  {
    "id": "staffroom-bingo-470",
    "title": "All the glue sticks have lids.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "All the glue sticks have lids."
  },
  {
    "id": "staffroom-bingo-471",
    "title": "A substitute note contains only good surprises.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A substitute note contains only good surprises."
  },
  {
    "id": "staffroom-bingo-472",
    "title": "Every group member contributes something meaningful.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "Every group member contributes something meaningful."
  },
  {
    "id": "staffroom-bingo-473",
    "title": "A student remembers exactly where yesterday’s lesson stopped.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A student remembers exactly where yesterday’s lesson stopped."
  },
  {
    "id": "staffroom-bingo-474",
    "title": "The interactive board, audio, internet, and login all work at once.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "The interactive board, audio, internet, and login all work at once."
  },
  {
    "id": "staffroom-bingo-475",
    "title": "A forgotten item finds its owner before reaching lost-and-found.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A forgotten item finds its owner before reaching lost-and-found."
  },
  {
    "id": "staffroom-bingo-476",
    "title": "The class spontaneously thanks a guest speaker.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "The class spontaneously thanks a guest speaker."
  },
  {
    "id": "staffroom-bingo-477",
    "title": "A student notices and fixes an accessibility barrier.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A student notices and fixes an accessibility barrier."
  },
  {
    "id": "staffroom-bingo-478",
    "title": "Someone remembers both sides of the double-sided handout.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "Someone remembers both sides of the double-sided handout."
  },
  {
    "id": "staffroom-bingo-479",
    "title": "A whole-class laugh happens without anyone being the target.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A whole-class laugh happens without anyone being the target."
  },
  {
    "id": "staffroom-bingo-480",
    "title": "The class asks to keep working when time is up.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "The class asks to keep working when time is up."
  },
  {
    "id": "staffroom-bingo-481",
    "title": "A student independently cites their information source.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A student independently cites their information source."
  },
  {
    "id": "staffroom-bingo-482",
    "title": "The room gets quiet after a single cue.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "The room gets quiet after a single cue."
  },
  {
    "id": "staffroom-bingo-483",
    "title": "A staff member receives a genuinely helpful automated notification.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "A staff member receives a genuinely helpful automated notification."
  },
  {
    "id": "staffroom-bingo-484",
    "title": "The first seating plan works for more than a week.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "The first seating plan works for more than a week."
  },
  {
    "id": "staffroom-bingo-485",
    "title": "A student uses “because” and then provides actual evidence.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A student uses “because” and then provides actual evidence."
  },
  {
    "id": "staffroom-bingo-486",
    "title": "The recycling bin contains only recyclable items.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "The recycling bin contains only recyclable items."
  },
  {
    "id": "staffroom-bingo-487",
    "title": "A group project reaches completion with no missing names.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A group project reaches completion with no missing names."
  },
  {
    "id": "staffroom-bingo-488",
    "title": "A classroom routine works so well that a visitor notices.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "A classroom routine works so well that a visitor notices."
  },
  {
    "id": "staffroom-bingo-489",
    "title": "A student teaches you something useful.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A student teaches you something useful."
  },
  {
    "id": "staffroom-bingo-490",
    "title": "Someone finds a missing document by searching its exact title.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "Someone finds a missing document by searching its exact title."
  },
  {
    "id": "staffroom-bingo-491",
    "title": "The class handles an unexpected change with impressive flexibility.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "The class handles an unexpected change with impressive flexibility."
  },
  {
    "id": "staffroom-bingo-492",
    "title": "A student says, “That was hard, but good.”",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A student says, “That was hard, but good.”"
  },
  {
    "id": "staffroom-bingo-493",
    "title": "A staff member leaves with the same travel mug they arrived with.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "A staff member leaves with the same travel mug they arrived with."
  },
  {
    "id": "staffroom-bingo-494",
    "title": "The printer finishes without beeping, blinking, or bargaining.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "The printer finishes without beeping, blinking, or bargaining."
  },
  {
    "id": "staffroom-bingo-495",
    "title": "A student applies learning in a way you did not plan.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A student applies learning in a way you did not plan."
  },
  {
    "id": "staffroom-bingo-496",
    "title": "The day includes a moment everyone will still quote next week.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "The day includes a moment everyone will still quote next week."
  },
  {
    "id": "staffroom-bingo-497",
    "title": "A classroom problem is solved with kindness before policy is required.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "A classroom problem is solved with kindness before policy is required."
  },
  {
    "id": "staffroom-bingo-498",
    "title": "Someone says, “We make a pretty good team,” and it is true.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "staff",
    "description": "Someone says, “We make a pretty good team,” and it is true."
  },
  {
    "id": "staffroom-bingo-499",
    "title": "You notice a small sign that a student feels they belong.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "You notice a small sign that a student feels they belong."
  },
  {
    "id": "staffroom-bingo-500",
    "title": "At the end of the day, something went better than anyone expected.",
    "category": "Long-game, rare, and legendary squares",
    "audience": "student",
    "description": "At the end of the day, something went better than anyone expected."
  }
]
);
