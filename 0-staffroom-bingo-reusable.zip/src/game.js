const BOARD_SIZE = 5;
const FREE_INDEX = 12;

function hashString(value) {
  let hash = 2166136261;
  for (const character of value) {
    hash ^= character.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function seededRandom(seed) {
  let state = seed || 1;
  return () => {
    state += 0x6d2b79f5;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

export function createDailyCard(dateKey, catalog) {
  const studentExperiences = Array.isArray(catalog)
    ? catalog.filter((experience) => experience.audience === "student")
    : [];
  const staffExperiences = Array.isArray(catalog)
    ? catalog.filter((experience) => experience.audience !== "student")
    : [];
  const halfCard = (BOARD_SIZE * BOARD_SIZE - 1) / 2;
  if (studentExperiences.length < halfCard || staffExperiences.length < halfCard) {
    throw new RangeError("A daily card needs at least 12 student moments and 12 staff moments.");
  }

  const random = seededRandom(hashString(dateKey));
  const shuffle = (items) => {
    const candidates = [...items];
    for (let index = candidates.length - 1; index > 0; index -= 1) {
      const swapIndex = Math.floor(random() * (index + 1));
      [candidates[index], candidates[swapIndex]] = [candidates[swapIndex], candidates[index]];
    }
    return candidates;
  };
  const chosen = shuffle([
    ...shuffle(studentExperiences).slice(0, halfCard),
    ...shuffle(staffExperiences).slice(0, halfCard)
  ]);
  let experienceIndex = 0;
  return Array.from({ length: BOARD_SIZE * BOARD_SIZE }, (_, index) => {
    if (index === FREE_INDEX) return { experienceId: null, marked: true };
    const experience = chosen[experienceIndex++];
    return { experienceId: experience.id, marked: false };
  });
}

export function detectBingos(card) {
  if (!Array.isArray(card) || card.length !== BOARD_SIZE * BOARD_SIZE) {
    throw new RangeError("A bingo card must contain exactly 25 squares.");
  }

  const lines = [];
  for (let row = 0; row < BOARD_SIZE; row += 1) {
    lines.push({
      id: `row-${row}`,
      indices: Array.from({ length: BOARD_SIZE }, (_, column) => row * BOARD_SIZE + column)
    });
  }
  for (let column = 0; column < BOARD_SIZE; column += 1) {
    lines.push({
      id: `column-${column}`,
      indices: Array.from({ length: BOARD_SIZE }, (_, row) => row * BOARD_SIZE + column)
    });
  }
  lines.push({ id: "diagonal-forward", indices: Array.from({ length: BOARD_SIZE }, (_, index) => index * (BOARD_SIZE + 1)) });
  lines.push({ id: "diagonal-backward", indices: Array.from({ length: BOARD_SIZE }, (_, index) => (index + 1) * (BOARD_SIZE - 1)) });

  return lines.filter(({ indices }) => indices.every((index) => card[index].marked)).map(({ id }) => id);
}

export function countMarkedSquares(card) {
  return card.filter((square, index) => index !== FREE_INDEX && square.marked).length;
}
