import { categories, experiences } from "./data/experiences.js";
import { countMarkedSquares, createDailyCard, detectBingos } from "./game.js";
import { formatEdmontonDate, getEdmontonDateKey } from "./time.js";
import { createInitialState, LocalDemoApi } from "./services/demo-api.js";
import { MultiplayerApi, MultiplayerApiError } from "./services/multiplayer-api.js";
import { getLoginRedirectUrl, selectStartupMode } from "./services/startup-mode.js";

let api;
const multiplayerApi = new MultiplayerApi();
const elements = {
  error: document.querySelector("#app-error"),
  board: document.querySelector("#bingo-board"),
  date: document.querySelector("#today-date"),
  squaresDone: document.querySelector("#squares-done"),
  linesDone: document.querySelector("#lines-done"),
  libraryCount: document.querySelector("#library-count"),
  progressBar: document.querySelector("#progress-bar"),
  progressFill: document.querySelector("#progress-fill"),
  celebration: document.querySelector("#celebration"),
  leaderboard: document.querySelector("#leaderboard"),
  leaderboardTabs: document.querySelectorAll("[data-leaderboard-view]"),
  leaderboardCaption: document.querySelector("#leaderboard-caption"),
  leaderboardNote: document.querySelector("#leaderboard-note"),
  suggestions: document.querySelector("#suggestion-list"),
  moderation: document.querySelector("#moderation-list"),
  pendingCount: document.querySelector("#pending-count"),
  ideaTotal: document.querySelector("#idea-total"),
  moderationTotal: document.querySelector("#moderation-total"),
  schoolName: document.querySelector("#school-name"),
  approval: document.querySelector("#approval-setting"),
  footerSchool: document.querySelector("#footer-school-name"),
  status: document.querySelector("#save-status"),
  modeBadge: document.querySelector("#mode-badge"),
  leaderboardDisclaimer: document.querySelector("#leaderboard-disclaimer"),
  suggestionLevel: document.querySelector("#suggestion-level"),
  suggestionPrivacyNote: document.querySelector("#suggestion-privacy-note"),
  catalogAdminTab: document.querySelector("#catalog-admin-tab"),
  catalogPendingCount: document.querySelector("#catalog-pending-count"),
  catalogPendingTotal: document.querySelector("#catalog-pending-total"),
  catalogPendingList: document.querySelector("#catalog-pending-list"),
  catalogLibraryTotal: document.querySelector("#catalog-library-total"),
  catalogLibraryList: document.querySelector("#catalog-library-list"),
  gameContent: document.querySelector("#game-content"),
  unavailable: document.querySelector("#service-unavailable"),
  availabilityTitle: document.querySelector("#availability-title"),
  availabilityMessage: document.querySelector("#availability-message"),
  welcome: document.querySelector("#welcome"),
  suggestionsTab: document.querySelector("#suggestions-tab"),
  localAdminTab: document.querySelector("#local-admin-tab")
};

let state;
const today = getEdmontonDateKey();
let activeLeaderboardView = "daily";
let multiplayerMode = false;
let multiplayerVersion = null;
let multiplayerCatalog = new Map();
let catalogAdminAvailable = false;

function setError(message) {
  elements.error.textContent = message;
  elements.error.hidden = false;
}

function announce(message) {
  elements.status.textContent = "";
  window.requestAnimationFrame(() => { elements.status.textContent = message; });
}

async function persist(message = "Saved on this device.") {
  try {
    await api.saveState(state);
    announce(message);
    elements.error.hidden = true;
    return true;
  } catch (error) {
    setError(`Your change could not be saved in this browser. ${error.message}`);
    return false;
  }
}

function getCatalog() {
  return [...experiences, ...state.customExperiences];
}

function ensureTodayCard() {
  if (state.dayKey !== today || !Array.isArray(state.card) || state.card.length !== 25) {
    state.dayKey = today;
    state.card = createDailyCard(today, getCatalog());
    state.bingos = [];
  }
}

function renderBoard() {
  const catalog = multiplayerMode
    ? multiplayerCatalog
    : new Map(getCatalog().map((experience) => [experience.id, experience]));
  elements.board.replaceChildren();
  state.card.forEach((square, index) => {
    const isFree = index === 12;
    const tile = document.createElement(isFree ? "div" : "button");
    if (!isFree) {
      tile.type = "button";
      tile.setAttribute("aria-pressed", String(square.marked));
    }
    tile.className = `bingo-square${isFree ? " free-square" : ""}`;
    if (isFree) {
      tile.setAttribute("role", "group");
      tile.setAttribute("aria-label", "Free space, already marked");
      tile.innerHTML = '<span class="free-symbol" aria-hidden="true">✳</span><span class="free-title">FREE SPACE</span><span class="free-copy">Already marked</span>';
    } else {
      const experience = catalog.get(square.experienceId);
      if (!experience) throw new Error(`The card refers to a missing experience: ${square.experienceId}`);
      const audience = experience.audience === "student" ? "student moment" : "staff moment";
      tile.dataset.audience = experience.audience === "student" ? "student" : "staff";
      tile.setAttribute("aria-label", `${audience} in ${experience.category}: ${experience.title}, ${square.marked ? "completed" : "not completed"}`);
      tile.innerHTML = `<span class="square-category">${audience.toUpperCase()}</span><span class="square-title">${escapeHtml(experience.title)}</span><span class="square-check" aria-hidden="true">✓</span>`;
      tile.addEventListener("click", () => { void toggleSquare(index); });
    }
    elements.board.append(tile);
  });

  const completed = countMarkedSquares(state.card);
  elements.squaresDone.textContent = String(completed);
  elements.linesDone.textContent = String(state.bingos.length);
  elements.progressBar.setAttribute("aria-valuenow", String(completed));
  elements.progressFill.style.width = `${(completed / 24) * 100}%`;
}

async function toggleSquare(index) {
  if (multiplayerMode) {
    const previousBingos = new Set(state.bingos);
    try {
      const result = await multiplayerApi.setSquare({
        squareIndex: index,
        marked: !state.card[index].marked,
        expectedVersion: multiplayerVersion
      });
      applyMultiplayerCard(result);
      renderBoard();
      elements.error.hidden = true;
      if (result.bingos.some((line) => !previousBingos.has(line))) {
        elements.celebration.hidden = false;
        announce("Bingo! You completed a line in multiplayer.");
      } else {
        announce("Card updated and saved to multiplayer.");
      }
      try {
        await renderLeaderboard();
      } catch (error) {
        setError(`Your card was saved, but the shared leaderboard could not be refreshed. ${error.message}`);
      }
    } catch (error) {
      if (error.status === 409) {
        try {
          applyMultiplayerCard(await multiplayerApi.getCard());
          renderBoard();
          await renderLeaderboard();
        } catch (reloadError) {
          setError(`Your shared card could not be refreshed. ${reloadError.message}`);
        }
      } else {
        setError(`Your change could not be saved to multiplayer. ${error.message}`);
      }
    }
    return;
  }

  const previousBingos = new Set(state.bingos);
  const isMarking = !state.card[index].marked;
  state.card[index].marked = isMarking;
  state.overallPoints = Math.max(0, state.overallPoints + (isMarking ? 1 : -1));
  state.bingos = detectBingos(state.card);
  renderBoard();
  renderLeaderboard();
  await persist("Card updated and saved on this device.");
  if (state.bingos.some((line) => !previousBingos.has(line))) {
    elements.celebration.hidden = false;
    announce("Bingo! You completed a line.");
  }
}

async function renderLeaderboard(view = activeLeaderboardView) {
  activeLeaderboardView = view;
  const requestedMode = multiplayerMode;
  const leaderboards = requestedMode
    ? await multiplayerApi.getLeaderboards()
    : await api.getDemoLeaderboards({
      dailyPoints: countMarkedSquares(state.card),
      overallPoints: state.overallPoints
    });
  if (activeLeaderboardView !== view || requestedMode !== multiplayerMode) return;
  const leaderboard = leaderboards[view];
  if (!leaderboard) throw new Error(`Unknown leaderboard view: ${view}`);
  elements.leaderboardTabs.forEach((tab) => {
    const active = tab.dataset.leaderboardView === view;
    tab.classList.toggle("is-active", active);
    tab.setAttribute("aria-pressed", String(active));
  });
  elements.leaderboardCaption.textContent = leaderboard.caption;
  elements.leaderboardNote.textContent = leaderboard.note;
  elements.leaderboardDisclaimer.textContent = multiplayerMode
    ? "MULTIPLAYER · SHARED STANDINGS"
    : "LOCAL DEVELOPMENT · BROWSER-ONLY SCORES";
  elements.leaderboard.setAttribute("aria-labelledby", `leaderboard-title leaderboard-tab-${view}`);
  elements.leaderboard.replaceChildren();
  leaderboard.entries.forEach((entry) => {
    const item = document.createElement("li");
    item.className = "leaderboard-item";
    item.innerHTML = `<span class="leader-rank">${entry.rank}</span><span class="leader-avatar" aria-hidden="true">${escapeHtml(entry.initials)}</span><span class="leader-name">${escapeHtml(entry.name)}</span><span class="leader-score">${entry.score} points</span>`;
    elements.leaderboard.append(item);
  });
}

function applyMultiplayerCard(result) {
  state.dayKey = result.dayKey;
  state.card = result.card;
  state.bingos = result.bingos;
  state.overallPoints = result.overallPoints;
  multiplayerVersion = result.version;
  multiplayerCatalog = new Map((result.catalog ?? []).map((experience) => [experience.id, {
    id: experience.id,
    title: experience.text,
    category: experience.category,
    audience: experience.level
  }]));
}

function updateSuggestionPrivacyNote() {
  const icon = elements.suggestionPrivacyNote.querySelector("span");
  elements.suggestionPrivacyNote.replaceChildren(
    icon,
    document.createTextNode(multiplayerMode
      ? " Sent to administrators for review. Never enter student names or identifying details."
      : " Stored in this browser only. Never enter student names or identifying details.")
  );
  document.querySelector("#ideas-mode-copy").textContent = multiplayerMode
    ? "Suggest a kind, school-friendly moment for a future bingo card. Ideas are sent for administrator review. Never include student names or identifying details."
    : "Suggest a kind, school-friendly moment for a future bingo card. Local-development ideas stay in this browser. Never include student names or identifying details.";
}

async function refreshMultiplayerSuggestions() {
  try {
    const suggestions = await multiplayerApi.getMySuggestions();
    state.suggestions = suggestions.map((suggestion) => ({
      id: suggestion.id,
      title: suggestion.text,
      category: suggestion.category,
      level: suggestion.level,
      status: suggestion.moderationState
    }));
    renderSuggestions();
  } catch (error) {
    setError(`Your suggestions could not be loaded. ${error.message}`);
  }
}

async function refreshCatalogAdmin() {
  if (!catalogAdminAvailable) return false;
  try {
    renderCatalogAdmin(await multiplayerApi.getAdminCatalog());
    return true;
  } catch (error) {
    setError(`The catalog administration screen could not be loaded. ${error.message}`);
    return false;
  }
}

async function importSharedCatalog() {
  const button = document.querySelector("#import-catalog");
  button.disabled = true;
  try {
    const result = await multiplayerApi.importCatalog();
    if (!await refreshCatalogAdmin()) return;
    announce(`Catalog import complete. ${result.created} new entries added; ${result.existing} already existed.`);
  } catch (error) {
    setError(`The bundled catalog could not be imported. ${error.message}`);
  } finally {
    button.disabled = false;
  }
}

function renderCatalogAdmin(records) {
  const pending = records.filter((record) => record.moderationState === "pending");
  const library = records.filter((record) => record.moderationState !== "pending");
  elements.catalogPendingTotal.textContent = String(pending.length);
  elements.catalogPendingCount.textContent = String(pending.length);
  elements.catalogPendingCount.hidden = pending.length === 0;
  elements.catalogLibraryTotal.textContent = String(library.length);
  renderCatalogAdminList(elements.catalogPendingList, pending, "No teacher suggestions are waiting for review.");
  renderCatalogAdminList(elements.catalogLibraryList, library, "The shared catalog has no additional records.");
  elements.error.hidden = true;
}

function renderCatalogAdminList(container, records, emptyMessage) {
  container.replaceChildren();
  if (records.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = emptyMessage;
    container.append(empty);
    return;
  }
  records.forEach((record) => container.append(createCatalogAdminItem(record)));
}

function createCatalogAdminItem(record) {
  const item = document.createElement("article");
  item.className = "suggestion-item";
  const title = document.createElement("p");
  title.className = "suggestion-item-title";
  title.textContent = record.text;
  const meta = document.createElement("div");
  meta.className = "suggestion-meta catalog-admin-meta";
  meta.textContent = `${record.category} · ${record.level} · ${record.rarity} · ${record.active ? "active" : "inactive"}`;
  const status = document.createElement("span");
  status.className = `status-pill ${record.moderationState}`;
  status.textContent = record.moderationState;
  const provenance = document.createElement("span");
  provenance.textContent = record.submittedBy
    ? (record.isOwnSuggestion ? "Your suggestion" : "Teacher suggestion")
    : "Shared library";
  meta.append(document.createTextNode(" · "), status, document.createTextNode(" · "), provenance);
  item.append(title, meta);

  const actions = document.createElement("div");
  actions.className = "moderation-actions";
  const ownSuggestion = record.isOwnSuggestion === true;
  if (record.moderationState !== "approved") {
    const approve = document.createElement("button");
    approve.type = "button";
    approve.textContent = "Approve";
    approve.disabled = ownSuggestion;
    if (ownSuggestion) approve.title = "Another administrator must approve your suggestion.";
    approve.addEventListener("click", () => {
      void moderateCatalogRecord(record.id, { moderationState: "approved", active: true }, "Square approved.");
    });
    actions.append(approve);
  }
  if (record.moderationState !== "rejected") {
    const reject = document.createElement("button");
    reject.type = "button";
    reject.textContent = "Reject";
    reject.addEventListener("click", () => {
      void moderateCatalogRecord(record.id, { moderationState: "rejected" }, "Suggestion rejected.");
    });
    actions.append(reject);
  }
  if (record.active) {
    const deactivate = document.createElement("button");
    deactivate.type = "button";
    deactivate.textContent = "Deactivate";
    deactivate.addEventListener("click", () => {
      void moderateCatalogRecord(record.id, { active: false }, "Square deactivated.");
    });
    actions.append(deactivate);
  }

  const edit = document.createElement("details");
  edit.className = "catalog-edit";
  const summary = document.createElement("summary");
  summary.textContent = "Edit square";
  const form = createCatalogEditForm(record);
  edit.append(summary, form);
  item.append(actions, edit);
  return item;
}

function createCatalogEditForm(record) {
  const form = document.createElement("form");
  form.className = "catalog-edit-form";
  const textId = `catalog-text-${record.id}`;
  const textLabel = document.createElement("label");
  textLabel.htmlFor = textId;
  textLabel.textContent = "Square text";
  const text = document.createElement("textarea");
  text.id = textId;
  text.name = "text";
  text.maxLength = 300;
  text.required = true;
  text.value = record.text;

  const fields = document.createElement("div");
  fields.className = "catalog-edit-fields";
  const categoryId = `catalog-category-${record.id}`;
  const categoryLabel = document.createElement("label");
  categoryLabel.htmlFor = categoryId;
  categoryLabel.textContent = "Category";
  const category = document.createElement("input");
  category.type = "text";
  category.id = categoryId;
  category.name = "category";
  category.maxLength = 80;
  category.required = true;
  category.value = record.category;

  const levelId = `catalog-level-${record.id}`;
  const levelLabel = document.createElement("label");
  levelLabel.htmlFor = levelId;
  levelLabel.textContent = "Level";
  const level = document.createElement("select");
  level.id = levelId;
  level.name = "level";
  for (const [value, label] of [["student", "Student"], ["staff", "Staff"]]) {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = label;
    level.append(option);
  }
  level.value = record.level;

  const rarityId = `catalog-rarity-${record.id}`;
  const rarityLabel = document.createElement("label");
  rarityLabel.htmlFor = rarityId;
  rarityLabel.textContent = "Rarity";
  const rarity = document.createElement("select");
  rarity.id = rarityId;
  rarity.name = "rarity";
  for (const value of ["common", "uncommon", "rare"]) {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value[0].toUpperCase() + value.slice(1);
    rarity.append(option);
  }
  rarity.value = record.rarity;
  fields.append(categoryLabel, category, levelLabel, level, rarityLabel, rarity);

  const activeLabel = document.createElement("label");
  activeLabel.className = "catalog-edit-active";
  const active = document.createElement("input");
  active.type = "checkbox";
  active.name = "active";
  active.checked = record.active;
  const activeText = document.createElement("span");
  activeText.textContent = "Active in future daily cards";
  activeLabel.append(active, activeText);
  const save = document.createElement("button");
  save.type = "submit";
  save.className = "button button-secondary";
  save.textContent = "Save changes";
  form.append(textLabel, text, fields, activeLabel, save);
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    void moderateCatalogRecord(record.id, {
      text: text.value,
      category: category.value,
      level: level.value,
      rarity: rarity.value,
      active: active.checked
    }, "Square updated.");
  });
  return form;
}

async function moderateCatalogRecord(id, changes, successMessage) {
  try {
    await multiplayerApi.updateCatalogExperience(id, changes);
    await refreshCatalogAdmin();
    announce(successMessage);
  } catch (error) {
    setError(`The square could not be updated. ${error.message}`);
  }
}

async function configureCatalogAdmin() {
  try {
    const context = await multiplayerApi.getAuthContext();
    const principal = context.clientPrincipal;
    catalogAdminAvailable = Array.isArray(principal?.userRoles) && principal.userRoles.includes("admin");
    elements.catalogAdminTab.hidden = !catalogAdminAvailable;
  } catch {
    catalogAdminAvailable = false;
    elements.catalogAdminTab.hidden = true;
  }
}

function showUnavailable(title, message) {
  elements.welcome.hidden = true;
  elements.gameContent.hidden = true;
  elements.unavailable.hidden = false;
  elements.availabilityTitle.textContent = title;
  elements.availabilityMessage.textContent = message;
  elements.suggestionsTab.hidden = true;
  elements.localAdminTab.hidden = true;
  elements.modeBadge.hidden = true;
}

async function startLocalDemo() {
  api = new LocalDemoApi();
  multiplayerMode = false;
  multiplayerVersion = null;
  multiplayerCatalog = new Map();
  state = await api.loadState(today);
  ensureTodayCard();
  state.bingos = detectBingos(state.card);
  elements.welcome.hidden = false;
  elements.unavailable.hidden = true;
  elements.gameContent.hidden = false;
  elements.suggestionsTab.hidden = false;
  elements.localAdminTab.hidden = false;
  elements.modeBadge.hidden = false;
  elements.modeBadge.textContent = "LOCAL DEVELOPMENT";
  updateSuggestionPrivacyNote();
  elements.celebration.hidden = true;
  renderSettings();
  renderSuggestions();
  renderBoard();
  await renderLeaderboard();
  await persist();
}

async function startMultiplayer() {
  state = createInitialState(today);
  const result = await multiplayerApi.getCard();
  multiplayerMode = true;
  applyMultiplayerCard(result);
  elements.welcome.hidden = false;
  elements.unavailable.hidden = true;
  elements.gameContent.hidden = false;
  elements.suggestionsTab.hidden = false;
  elements.localAdminTab.hidden = true;
  elements.modeBadge.hidden = false;
  elements.modeBadge.textContent = "MULTIPLAYER";
  updateSuggestionPrivacyNote();
  elements.celebration.hidden = result.bingos.length === 0;
  renderBoard();
  renderSuggestions();
  elements.error.hidden = true;
  announce("multiplayer is active. Marks sync across devices.");
  try {
    const catalog = await multiplayerApi.getCatalog();
    const allExperiences = new Map((result.catalog ?? []).map((experience) => [experience.id, {
      id: experience.id,
      title: experience.text,
      category: experience.category,
      audience: experience.level
    }]));
    catalog.forEach((experience) => allExperiences.set(experience.id, {
      id: experience.id,
      title: experience.text,
      category: experience.category,
      audience: experience.level
    }));
    multiplayerCatalog = allExperiences;
    state.catalogCount = catalog.length;
    renderBoard();
    renderSuggestions();
  } catch (error) {
    state.catalogCount = null;
    elements.libraryCount.textContent = "—";
    setError(`Your card is ready, but the shared catalog count could not be loaded. ${error.message}`);
  }
  await refreshMultiplayerSuggestions();
  try {
    await renderLeaderboard();
  } catch (error) {
    setError(`multiplayer is active, but the shared leaderboard could not be loaded. ${error.message}`);
  }
}

function renderSuggestions() {
  elements.libraryCount.textContent = String(multiplayerMode
    ? (state.catalogCount ?? "—")
    : getCatalog().length);
  const pending = state.suggestions.filter((suggestion) => suggestion.status === "pending").length;
  elements.pendingCount.textContent = String(pending);
  elements.pendingCount.hidden = pending === 0;
  elements.ideaTotal.textContent = String(state.suggestions.length);
  elements.moderationTotal.textContent = String(pending);
  renderSuggestionItems(elements.suggestions, state.suggestions, false);
  renderSuggestionItems(elements.moderation, state.suggestions.filter((suggestion) => suggestion.status === "pending"), true);
}

function renderSuggestionItems(container, suggestions, isModeration) {
  container.replaceChildren();
  if (suggestions.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.innerHTML = isModeration
      ? "<strong>All caught up.</strong>There are no ideas waiting for review."
      : "<strong>Your idea board is open.</strong>Ideas you share on this device will show up here.";
    container.append(empty);
    return;
  }

  [...suggestions].reverse().forEach((suggestion) => {
    const item = document.createElement("article");
    item.className = "suggestion-item";
    item.innerHTML = `<p class="suggestion-item-title">${escapeHtml(suggestion.title)}</p><div class="suggestion-meta"><span>${escapeHtml(suggestion.category)}</span><span aria-hidden="true">·</span><span class="status-pill ${suggestion.status}">${escapeHtml(suggestion.status)}</span></div>`;
    if (isModeration) {
      const actions = document.createElement("div");
      actions.className = "moderation-actions";
      const approve = document.createElement("button");
      approve.type = "button";
      approve.textContent = "Approve idea";
      approve.addEventListener("click", () => { void moderateSuggestion(suggestion.id, "approved"); });
      const reject = document.createElement("button");
      reject.type = "button";
      reject.textContent = "Reject";
      reject.addEventListener("click", () => { void moderateSuggestion(suggestion.id, "rejected"); });
      actions.append(approve, reject);
      item.append(actions);
    }
    container.append(item);
  });
}

async function moderateSuggestion(id, status) {
  const suggestion = state.suggestions.find((entry) => entry.id === id);
  if (!suggestion || suggestion.status !== "pending") return;
  suggestion.status = status;
  if (status === "approved") {
    state.customExperiences.push({
      id: `community-${id}`,
      title: suggestion.title,
      category: suggestion.category,
      description: suggestion.title
    });
  }
  renderSuggestions();
  await persist(`Idea ${status} in this local demo.`);
}

function renderSettings() {
  elements.schoolName.value = state.settings.schoolName;
  elements.approval.checked = state.settings.requireApproval;
  elements.footerSchool.textContent = state.settings.schoolName || "DEMO SCHOOL";
}

async function submitSuggestion(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const titleField = form.elements.title;
  const categoryField = form.elements.category;
  const levelField = form.elements.level;
  const feedback = document.querySelector("#suggestion-feedback");
  const title = titleField.value.trim();
  feedback.classList.remove("is-error");
  if (title.length < 8) {
    feedback.textContent = "Add a little more detail (at least 8 characters).";
    feedback.classList.add("is-error");
    titleField.focus();
    return;
  }

  if (multiplayerMode) {
    try {
      const suggestion = await multiplayerApi.submitSuggestion({
        text: title,
        category: categoryField.value,
        level: levelField.value
      });
      state.suggestions.push({
        id: suggestion.id,
        title: suggestion.text,
        category: suggestion.category,
        level: suggestion.level,
        status: suggestion.moderationState
      });
      form.reset();
      document.querySelector("#character-count").textContent = "0 / 100";
      renderSuggestions();
      feedback.textContent = "Thanks! Your suggestion is waiting for administrator review.";
      announce("Suggestion sent for administrator review.");
      await refreshMultiplayerSuggestions();
    } catch (error) {
      feedback.textContent = "Your suggestion was not sent. Check the message above before leaving this page.";
      feedback.classList.add("is-error");
      setError(`Your suggestion could not be submitted. ${error.message}`);
    }
    return;
  }

  const suggestion = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    title,
    category: categoryField.value,
    level: levelField.value,
    status: state.settings.requireApproval ? "pending" : "approved"
  };
  state.suggestions.push(suggestion);
  if (suggestion.status === "approved") {
    state.customExperiences.push({
      id: `community-${suggestion.id}`,
      title,
      category: suggestion.category,
      audience: suggestion.level,
      description: title
    });
  }
  form.reset();
  document.querySelector("#character-count").textContent = "0 / 100";
  renderSuggestions();
  const saved = await persist(state.settings.requireApproval
    ? "Idea sent for local demo review."
    : "Idea added to this browser's demo inspiration pool.");
  feedback.textContent = saved
    ? (state.settings.requireApproval ? "Thanks! Your idea is waiting in the demo review queue." : "Thanks! Your idea is now part of this browser's demo inspiration pool.")
    : "The idea is not saved yet. Check the message above before leaving this page.";
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}

function navigate(viewName) {
  document.querySelectorAll(".view").forEach((view) => { view.hidden = view.id !== `view-${viewName}`; });
  document.querySelectorAll(".tab").forEach((tab) => {
    const active = tab.dataset.view === viewName;
    tab.classList.toggle("is-active", active);
    if (active) tab.setAttribute("aria-current", "page");
    else tab.removeAttribute("aria-current");
  });
  if (viewName === "suggestions") document.querySelector("#suggestion-title").focus({ preventScroll: true });
  if (viewName === "suggestions" && multiplayerMode) void refreshMultiplayerSuggestions();
  if (viewName === "catalog-admin") void refreshCatalogAdmin();
}

function bindEvents() {
  document.querySelectorAll(".tab").forEach((tab) => tab.addEventListener("click", () => navigate(tab.dataset.view)));
  elements.leaderboardTabs.forEach((tab) => tab.addEventListener("click", () => {
    void renderLeaderboard(tab.dataset.leaderboardView).catch((error) => {
      setError(`The shared leaderboard could not be loaded. ${error.message}`);
    });
  }));
  document.querySelectorAll("[data-go-to-suggestions]").forEach((button) => button.addEventListener("click", () => navigate("suggestions")));
  document.querySelector("#suggestion-form").addEventListener("submit", (event) => { void submitSuggestion(event); });
  document.querySelector("#suggestion-title").addEventListener("input", (event) => {
    document.querySelector("#character-count").textContent = `${event.currentTarget.value.length} / 100`;
  });
  elements.schoolName.addEventListener("change", () => {
    state.settings.schoolName = elements.schoolName.value.trim() || "Maple Grove School";
    renderSettings();
    void persist("Demo display name saved.");
  });
  elements.approval.addEventListener("change", () => {
    state.settings.requireApproval = elements.approval.checked;
    void persist("Suggestion review setting saved.");
  });
  document.querySelector("#import-catalog").addEventListener("click", () => { void importSharedCatalog(); });
  document.querySelector("#reset-demo").addEventListener("click", () => { void resetDemo(); });
  document.querySelector("#dismiss-celebration").addEventListener("click", () => { elements.celebration.hidden = true; });
}

async function resetDemo() {
  if (!window.confirm("Clear the card, suggestions, and demo settings saved in this browser?")) return;
  try {
    await api.clearState();
    if (multiplayerMode) {
      elements.celebration.hidden = true;
      document.querySelector("#settings-feedback").textContent = "Local demo data cleared.";
      elements.error.hidden = true;
      announce("Local demo data cleared.");
      return;
    }
    state = createInitialState(today);
    state.card = createDailyCard(today, getCatalog());
    elements.celebration.hidden = true;
    renderSettings();
    renderSuggestions();
    renderBoard();
    await renderLeaderboard();
    document.querySelector("#settings-feedback").textContent = "Local demo data cleared.";
    elements.error.hidden = true;
    announce("Local demo data cleared.");
  } catch (error) {
    setError(`Local demo data could not be cleared. ${error.message}`);
  }
}

async function start() {
  try {
    elements.date.textContent = formatEdmontonDate();
    const categorySelect = document.querySelector("#suggestion-category");
    categories.forEach((category) => {
      const option = document.createElement("option");
      option.value = category;
      option.textContent = category;
      categorySelect.append(option);
    });
    bindEvents();
    let status;
    try {
      status = await multiplayerApi.getStatus();
    } catch (error) {
      const mode = selectStartupMode({
        hostname: window.location.hostname,
        multiplayerEnabled: false,
        authenticated: false
      });
      if (mode === "local-demo") {
        await startLocalDemo();
        return;
      }
      showUnavailable(
        "Multiplayer could not be reached.",
        `The app could not verify multiplayer availability. Please try again later. ${error.message}`
      );
      return;
    }

    const multiplayerEnabled = status.enabled === true;
    let authContext = null;
    if (multiplayerEnabled) {
      try {
        authContext = await multiplayerApi.getAuthContext();
      } catch (error) {
        showUnavailable(
          "Your sign-in could not be verified.",
          `The app could not verify your sign-in. Please try again. ${error.message}`
        );
        return;
      }
    }
    const mode = selectStartupMode({
      hostname: window.location.hostname,
      multiplayerEnabled,
      authenticated: Boolean(authContext?.clientPrincipal)
    });
    if (mode === "login") {
      window.location.assign(getLoginRedirectUrl());
      return;
    }
    if (mode === "local-demo") {
      await startLocalDemo();
      return;
    }
    if (mode === "unavailable") {
      await configureCatalogAdmin();
      showUnavailable(
        "Multiplayer is unavailable.",
        "The shared game is not enabled or one of its required email, Graph identity, or storage settings is incomplete. Contact your administrator."
      );
      return;
    }

    await configureCatalogAdmin();
    try {
      await startMultiplayer();
    } catch (error) {
      if (error instanceof MultiplayerApiError && error.status === 401) {
        window.location.assign(getLoginRedirectUrl());
        return;
      }
      if (/active approved catalog needs at least 12 student and 12 staff experiences/i.test(error.message)) {
        showUnavailable(
          "The shared catalog needs initialization.",
          "An authorized Square admin can open Square admin and choose Import bundled library. The import adds missing entries only, leaves existing moderation and active states unchanged, and provides 250 student and 250 staff prompts."
        );
      } else {
        showUnavailable(
          "Multiplayer could not be started.",
          `Your shared game could not be loaded. Please try again later. ${error.message}`
        );
      }
    }
  } catch (error) {
    showUnavailable(
      "Staffroom Bingo could not start.",
      `The app could not load. Please try again later. ${error.message}`
    );
  }
}

void start();
