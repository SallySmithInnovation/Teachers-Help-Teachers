import { countMarkedSquares } from "../game.js";

const STORAGE_KEY = "staffroom-bingo-demo-v1";

function rankStandings(entries) {
  return [...entries]
    .sort((left, right) => right.score - left.score)
    .map((entry, index) => ({ ...entry, rank: index + 1 }));
}

function validPoints(value) {
  return Number.isSafeInteger(value) && value >= 0 ? value : 0;
}

function withLocalPlayer(standings, points) {
  return rankStandings([
    ...standings,
    { name: "You · this browser", initials: "Y", score: validPoints(points) }
  ]);
}

function makeDemoLeaderboards({ dailyPoints, overallPoints }) {
  return {
    daily: {
      caption: "Today's points",
      note: "This local-development score is saved in this browser only.",
      entries: withLocalPlayer([], dailyPoints)
    },
    overall: {
      caption: "Overall points · this browser",
      note: "Overall points are stored on this device only.",
      entries: withLocalPlayer([], overallPoints)
    },
    school: {
      caption: "School standings unavailable",
      note: "School rankings require authenticated multiplayer.",
      entries: []
    }
  };
}

const DEFAULT_SETTINGS = Object.freeze({
  schoolName: "Maple Grove School",
  requireApproval: true
});

export function createInitialState(dateKey) {
  return {
    version: 1,
    dayKey: dateKey,
    card: [],
    bingos: [],
    overallPoints: 0,
    suggestions: [],
    customExperiences: [],
    settings: { ...DEFAULT_SETTINGS }
  };
}

export class LocalDemoApi {
  constructor(storage = globalThis.localStorage) {
    this.storage = storage;
  }

  async loadState(dateKey) {
    const saved = this.storage.getItem(STORAGE_KEY);
    if (!saved) return createInitialState(dateKey);
    const state = JSON.parse(saved);
    if (!state || state.version !== 1 || typeof state !== "object") {
      throw new Error("Saved demo data is not in a format this version can read. Reset local demo data to start fresh.");
    }
    const merged = {
      ...createInitialState(dateKey),
      ...state,
      settings: { ...DEFAULT_SETTINGS, ...state.settings }
    };
    if (!Number.isSafeInteger(state.overallPoints) || state.overallPoints < 0) {
      merged.overallPoints = Array.isArray(state.card) ? countMarkedSquares(state.card) : 0;
    }
    return merged;
  }

  async saveState(state) {
    this.storage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  async clearState() {
    this.storage.removeItem(STORAGE_KEY);
  }

  async getDemoLeaderboards(scores) {
    return makeDemoLeaderboards(scores);
  }
}
