export class MultiplayerApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

async function request(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    credentials: "same-origin",
    cache: "no-store",
    headers: {
      ...(options.body ? { "content-type": "application/json" } : {}),
      ...options.headers
    }
  });
  let payload;
  try {
    payload = await response.json();
  } catch {
    throw new MultiplayerApiError(response.status, "The multiplayer service returned an unexpected response.");
  }
  if (!response.ok) {
    throw new MultiplayerApiError(response.status, payload.error || "The multiplayer request failed.");
  }
  return payload;
}

export class MultiplayerApi {
  async getStatus() {
    return request("/api/status");
  }

  async getAuthContext() {
    return request("/.auth/me");
  }

  async getCard() {
    return request("/api/card");
  }

  async setSquare({ squareIndex, marked, expectedVersion }) {
    return request("/api/marks", {
      method: "PUT",
      body: JSON.stringify({ squareIndex, marked, expectedVersion })
    });
  }

  async getLeaderboards() {
    return request("/api/leaderboards");
  }

  async getCatalog() {
    return request("/api/catalog");
  }

  async getMySuggestions() {
    return request("/api/catalog/suggestions");
  }

  async submitSuggestion(suggestion) {
    return request("/api/catalog/suggestions", {
      method: "POST",
      body: JSON.stringify(suggestion)
    });
  }

  async getAdminCatalog() {
    return request("/api/manage/catalog");
  }

  async importCatalog() {
    return request("/api/manage/catalog/import", { method: "POST" });
  }

  async createCatalogExperience(experience) {
    return request("/api/manage/catalog", {
      method: "POST",
      body: JSON.stringify(experience)
    });
  }

  async updateCatalogExperience(id, changes) {
    return request(`/api/manage/catalog/${encodeURIComponent(id)}`, {
      method: "PATCH",
      body: JSON.stringify(changes)
    });
  }
}
