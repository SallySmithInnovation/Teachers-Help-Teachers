export function isLocalDevelopmentHost(hostname) {
  return ["localhost", "127.0.0.1", "::1", "[::1]"].includes(String(hostname).toLowerCase());
}

export function selectStartupMode({ hostname, multiplayerEnabled, authenticated }) {
  if (multiplayerEnabled) return authenticated ? "multiplayer" : "login";
  return isLocalDevelopmentHost(hostname) ? "local-demo" : "unavailable";
}

export function getLoginRedirectUrl(returnPath = "/") {
  return `/.auth/login/aad?post_login_redirect_uri=${encodeURIComponent(returnPath)}`;
}
