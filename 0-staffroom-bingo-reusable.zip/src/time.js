const EDMONTON_TIME_ZONE = "America/Edmonton";

export function getEdmontonDateKey(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: EDMONTON_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(date);
  const values = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
  return `${values.year}-${values.month}-${values.day}`;
}

export function formatEdmontonDate(date = new Date()) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: EDMONTON_TIME_ZONE,
    weekday: "long",
    month: "long",
    day: "numeric"
  }).format(date);
}
