import test from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import { createDirectory } from "../api/src/directory.js";
import { createBingoService, HttpError, multiplayerConfigured, parsePrincipal } from "../api/src/domain.js";
import { experiences as sourceExperiences } from "../src/data/experiences.js";
import { LocalDemoApi } from "../src/services/demo-api.js";
import { MultiplayerApi } from "../src/services/multiplayer-api.js";

const entraObjectId = "00000000-0000-4000-8000-000000000001";
const swaUserId = "00000000-0000-4000-8000-000000000002";
const otherEntraObjectId = "00000000-0000-4000-8000-000000000003";
const email = "sample.user@example.test";
const otherEmail = "other.user@example.test";
const emailClaim = {
  typ: "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn",
  val: "sample.user@example.test"
};
const tenantIssuerPattern = /^https:\/\/login\.microsoftonline\.com\/(?:REPLACE_WITH_BINGO_TENANT_ID|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i;
const swaConfig = JSON.parse(readFileSync(new URL("../staticwebapp.config.json", import.meta.url), "utf8"));
const indexHtml = readFileSync(new URL("../index.html", import.meta.url), "utf8");
const deploymentWorkflow = readFileSync(
  new URL("../.github/workflows/azure-static-web-apps.yml", import.meta.url),
  "utf8"
);
const apiPackage = JSON.parse(readFileSync(new URL("../api/package.json", import.meta.url), "utf8"));
const baseEnv = {
  BINGO_MULTIPLAYER_ENABLED: "true",
  BINGO_SWA_USER_DETAILS_IS_EMAIL: "true",
  BINGO_STORAGE_CONNECTION: "fake-test-storage-connection-not-a-secret",
  BINGO_TENANT_ID: "00000000-0000-4000-8000-000000000004",
  BINGO_ALLOWED_EMAIL_DOMAIN: "example.test",
  AZURE_CLIENT_ID: "00000000-0000-4000-8000-000000000005",
  AZURE_CLIENT_SECRET_APP_SETTING_NAME: "fake-auth-setting-not-a-secret",
  GRAPH_CLIENT_ID: "00000000-0000-4000-8000-000000000006",
  GRAPH_CLIENT_SECRET: "fake-graph-secret-not-a-credential"
};
const principal = {
  identityProvider: "aad",
  userId: swaUserId,
  userDetails: email,
  userRoles: ["anonymous", "authenticated"]
};
const adminPrincipal = { ...principal, userRoles: ["anonymous", "authenticated", "admin"] };

function createMemoryStore() {
  const cards = new Map();
  const catalog = new Map();
  const winners = new Map();
  let cardEtagCounter = 0;
  let catalogEtagCounter = 0;
  return {
    cards,
    catalog,
    winners,
    async getCard(id, day) {
      return cards.get(`${id}/${day}`) ?? null;
    },
    async getOrCreateCard(id, day, properties) {
      const key = `${id}/${day}`;
      if (!cards.has(key)) cards.set(key, {
        partitionKey: id,
        rowKey: day,
        ...properties,
        etag: "card-etag-0"
      });
      return cards.get(key);
    },
    async updateCard(entity, etag) {
      const key = `${entity.partitionKey}/${entity.rowKey}`;
      const current = cards.get(key);
      if (current.etag !== etag) {
        const error = new Error("Precondition failed.");
        error.status = 412;
        throw error;
      }
      const updated = { ...entity, etag: `card-etag-${++cardEtagCounter}` };
      cards.set(key, updated);
      return updated;
    },
    async listCards({ entraObjectId, dayKey, schoolKey } = {}) {
      return [...cards.values()].filter((row) => (!entraObjectId || row.partitionKey === entraObjectId)
        && (!dayKey || row.rowKey === dayKey)
        && (!schoolKey || row.schoolKey === schoolKey));
    },
    async getCatalogExperience(id) {
      return catalog.get(id) ?? null;
    },
    async getCatalogExperiences(ids) {
      return ids.map((id) => catalog.get(id) ?? null);
    },
    async listCatalog({ activeOnly = false, submittedBy } = {}) {
      return [...catalog.values()].filter((row) => (!submittedBy || row.submittedBy === submittedBy)
        && (!activeOnly || (row.active === true && row.moderationState === "approved")));
    },
    async createCatalogExperience(experience) {
      if (catalog.has(experience.id)) return false;
      catalog.set(experience.id, {
        partitionKey: "catalog",
        rowKey: experience.id,
        ...experience,
        etag: "catalog-etag-0"
      });
      return true;
    },
    async updateCatalogExperience(experience, etag) {
      const current = catalog.get(experience.id);
      if (!current || current.etag !== etag) {
        const error = new Error("Precondition failed.");
        error.status = 412;
        throw error;
      }
      const updated = {
        ...experience,
        partitionKey: "catalog",
        rowKey: experience.id,
        etag: `catalog-etag-${++catalogEtagCounter}`
      };
      catalog.set(experience.id, updated);
      return updated;
    },
    async createWinner(winner) {
      const key = `${winner.dayKey}/${winner.entraObjectId}`;
      if (winners.has(key)) return false;
      winners.set(key, winner);
      return true;
    }
  };
}

function directoryFor({ id = entraObjectId, officeLocation = "Example Campus", displayName = "Sample User" } = {}) {
  return {
    getUserByEmail: async (userEmail) => ({
      id,
      mail: userEmail,
      userPrincipalName: userEmail,
      officeLocation,
      displayName
    })
  };
}

function createService({
  env = baseEnv,
  directory = { getUserByEmail: async (userEmail) => ({
    id: userEmail.toLowerCase() === otherEmail ? otherEntraObjectId : entraObjectId,
    mail: userEmail,
    userPrincipalName: userEmail,
    officeLocation: "Example Campus",
    displayName: "Sample User"
  }) },
  now
} = {}) {
  return createBingoService({
    store: createMemoryStore(),
    directory,
    env,
    now: now ?? (() => new Date("2026-11-16T19:00:00.000Z"))
  });
}

async function createSeededService(options) {
  const service = createService(options);
  await service.importCatalog(adminPrincipal);
  return service;
}

test("multiplayer configuration and SWA principal parsing fail closed", () => {
  assert.equal(multiplayerConfigured(baseEnv), true);
  assert.equal(multiplayerConfigured({ ...baseEnv, BINGO_TENANT_ID: "" }), false);
  assert.equal(multiplayerConfigured({ ...baseEnv, BINGO_TENANT_ID: undefined }), false);
  assert.equal(multiplayerConfigured({ ...baseEnv, BINGO_TENANT_ID: "not-a-tenant-id" }), false);
  assert.equal(multiplayerConfigured({ ...baseEnv, BINGO_ALLOWED_EMAIL_DOMAIN: undefined }), false);
  assert.equal(multiplayerConfigured({ ...baseEnv, BINGO_ALLOWED_EMAIL_DOMAIN: "*.example.test" }), false);
  assert.equal(multiplayerConfigured({ ...baseEnv, BINGO_ALLOWED_EMAIL_DOMAIN: "example..test" }), false);
  assert.equal(multiplayerConfigured({ ...baseEnv, AZURE_CLIENT_ID: "" }), false);
  assert.equal(multiplayerConfigured({ ...baseEnv, AZURE_CLIENT_SECRET_APP_SETTING_NAME: "" }), false);
  assert.equal(multiplayerConfigured({ ...baseEnv, BINGO_MULTIPLAYER_ENABLED: "false" }), false);
  assert.equal(multiplayerConfigured({ ...baseEnv, BINGO_MULTIPLAYER_ENABLED: undefined }), false);
  assert.equal(multiplayerConfigured({ ...baseEnv, BINGO_SWA_USER_DETAILS_IS_EMAIL: undefined }), false);
  assert.equal(multiplayerConfigured({
    ...baseEnv,
    BINGO_SWA_USER_DETAILS_IS_EMAIL: undefined,
    BINGO_SWA_USER_DETAILS_IS_OID: "true"
  }), false);
  assert.equal(parsePrincipal(Buffer.from(JSON.stringify(principal)).toString("base64")).userDetails, email);
  assert.equal(parsePrincipal("not-base64"), null);
});

test("SWA authentication is tenant-pinned and preserves API route authorization", () => {
  const provider = swaConfig.auth.identityProviders.azureActiveDirectory;
  assert.equal(provider.userDetailsClaim, emailClaim.typ);
  assert.equal(principal.userDetails, emailClaim.val);
  assert.match(provider.registration.openIdIssuer, tenantIssuerPattern);
  for (const issuer of [
    "https://login.microsoftonline.com/common",
    "https://login.microsoftonline.com/organizations",
    "https://login.microsoftonline.com/not-a-tenant-id",
    "https://login.microsoftonline.com/00000000-0000-4000-8000-000000000004/v2.0"
  ]) {
    assert.doesNotMatch(issuer, tenantIssuerPattern);
  }
  assert.equal(provider.registration.clientIdSettingName, "AZURE_CLIENT_ID");
  assert.equal(provider.registration.clientSecretSettingName, "AZURE_CLIENT_SECRET_APP_SETTING_NAME");
  assert.deepEqual(swaConfig.routes.find(({ route }) => route === "/").allowedRoles, ["authenticated"]);
  assert.deepEqual(swaConfig.routes.find(({ route }) => route === "/index.html").allowedRoles, ["authenticated"]);
  assert.deepEqual(swaConfig.routes.find(({ route }) => route === "/api/status").allowedRoles, ["anonymous"]);
  assert.deepEqual(swaConfig.routes.find(({ route }) => route === "/api/manage/*").allowedRoles, ["admin"]);
  assert.deepEqual(swaConfig.routes.find(({ route }) => route === "/api/*").allowedRoles, ["authenticated"]);
  assert.equal(swaConfig.responseOverrides["401"].redirect, "/.auth/login/aad?post_login_redirect_uri=.referrer");
  assert.equal(swaConfig.responseOverrides["401"].statusCode, 302);
  assert.equal(indexHtml.includes("DEMO MODE"), false);
  assert.equal(indexHtml.includes("Demo admin"), false);
  assert.equal(indexHtml.includes("DEMO STANDINGS"), false);
  assert.equal(indexHtml.includes("Edmonton date"), false);
});

test("catalog management requests use admin-protected SWA routes", async (t) => {
  const calls = [];
  t.mock.method(globalThis, "fetch", async (path, options) => {
    calls.push({ path, method: options.method ?? "GET" });
    return new Response("{}", { status: 200 });
  });
  const api = new MultiplayerApi();
  await api.getAdminCatalog();
  await api.importCatalog();
  await api.createCatalogExperience({});
  await api.updateCatalogExperience("square id", {});

  assert.deepEqual(calls, [
    { path: "/api/manage/catalog", method: "GET" },
    { path: "/api/manage/catalog/import", method: "POST" },
    { path: "/api/manage/catalog", method: "POST" },
    { path: "/api/manage/catalog/square%20id", method: "PATCH" }
  ]);
  for (const { path, method } of calls) {
    const matchedRule = swaConfig.routes.find((rule) =>
      (!rule.methods || rule.methods.includes(method))
      && (rule.route.endsWith("*") ? path.startsWith(rule.route.slice(0, -1)) : path === rule.route));
    assert.deepEqual(matchedRule?.allowedRoles, ["admin"], `${method} ${path} must require admin`);
  }
});

test("the SWA email is only a Graph lookup key and is never trusted as an OID", async () => {
  let directoryLookups = 0;
  const service = createService({
    directory: {
      getUserByEmail: async (userEmail) => {
        directoryLookups += 1;
        return {
          id: entraObjectId,
          mail: userEmail,
          userPrincipalName: userEmail,
          officeLocation: "Example Campus"
        };
      }
    }
  });

  for (const userDetails of ["Unrecognized User", "outsider@other.test", "staff@sub.example.test", entraObjectId]) {
    const nameClaimPrincipal = { ...principal, userDetails, userId: entraObjectId };
    await assert.rejects(
      service.getCard(nameClaimPrincipal),
      (error) => error instanceof HttpError && error.status === 401
    );
    await assert.rejects(
      service.getAdminCatalog({ ...nameClaimPrincipal, userRoles: [...principal.userRoles, "admin"] }),
      (error) => error instanceof HttpError && error.status === 401
    );
  }

  assert.equal(directoryLookups, 0);
});

test("API identity operations stay disabled until SWA email details are explicitly enabled", async () => {
  const service = createService({
    env: { ...baseEnv, BINGO_SWA_USER_DETAILS_IS_EMAIL: "false" },
    directory: { getUserByEmail: async () => assert.fail("Directory lookup must not run without the email claim gate.") }
  });

  assert.equal(multiplayerConfigured({ ...baseEnv, BINGO_SWA_USER_DETAILS_IS_EMAIL: "false" }), false);
  await assert.rejects(
    service.getCard(principal),
    (error) => error instanceof HttpError && error.status === 503
  );
  await assert.rejects(
    service.getAdminCatalog(adminPrincipal),
    (error) => error instanceof HttpError && error.status === 503
  );
});

test("production deployment stages the public frontend and builds the Node 22 API", () => {
  assert.match(deploymentWorkflow, /^\s+app_location:\s*"?public"?$/m);
  assert.match(deploymentWorkflow, /^\s+api_location:\s*"?api"?$/m);
  assert.match(deploymentWorkflow, /^\s+api_build_command:\s*"?npm run build"?$/m);
  assert.match(deploymentWorkflow, /^\s+output_location:\s*""$/m);
  assert.match(deploymentWorkflow, /^\s+skip_app_build:\s*true$/m);
  assert.doesNotMatch(deploymentWorkflow, /^\s+skip_api_build:\s*true$/m);
  assert.match(deploymentWorkflow, /mkdir public/);
  assert.match(deploymentWorkflow, /cp index\.html styles\.css staticwebapp\.config\.json public\//);
  assert.match(deploymentWorkflow, /cp -R src public\/src/);
  assert.equal(swaConfig.platform.apiRuntime, "node:22");
  assert.equal(apiPackage.main, "dist/src/functions.js");
  for (const file of ["index.html", "styles.css", "src/main.js", "staticwebapp.config.json"]) {
    assert.ok(existsSync(new URL(`../${file}`, import.meta.url)), `${file} must be available to stage`);
  }
});

test("disabled multiplayer leaves browser demo storage and leaderboards available", async () => {
  let savedState = null;
  const demo = new LocalDemoApi({
    getItem: () => savedState,
    setItem: (_key, value) => { savedState = value; },
    removeItem: () => { savedState = null; }
  });
  const state = await demo.loadState("2026-11-16");
  state.settings.schoolName = "Local sample";
  await demo.saveState(state);
  const restored = await demo.loadState("2026-11-16");

  assert.equal(multiplayerConfigured({ ...baseEnv, BINGO_MULTIPLAYER_ENABLED: "false" }), false);
  assert.equal(restored.settings.schoolName, "Local sample");
  const boards = await demo.getDemoLeaderboards({ dailyPoints: 0, overallPoints: 0 });
  assert.ok(boards.daily.entries.some(({ name }) => name === "You · this browser"));
});

test("daily card creation is stable and persists across requests", async () => {
  const service = await createSeededService();
  const first = await service.getCard(principal);
  const repeat = await service.getCard(principal);

  assert.equal(first.dayKey, "2026-11-16");
  assert.deepEqual(repeat.card, first.card);
  assert.equal(first.card.length, 25);
  assert.equal(first.card[12].marked, true);
  assert.equal(first.version, 0);
  assert.equal(repeat.version, 0);
});

test("invalid saved catalog data fails closed without creating a card", async () => {
  const store = createMemoryStore();
  store.catalog.set("broken-row", {
    partitionKey: "catalog",
    rowKey: "broken-row",
    text: "",
    category: "Invalid",
    level: "staff",
    rarity: "common",
    active: true,
    moderationState: "approved"
  });
  const service = createBingoService({
    store,
    directory: directoryFor(),
    env: baseEnv,
    now: () => new Date("2026-11-16T19:00:00.000Z")
  });

  await assert.rejects(
    service.getCard(principal),
    (error) => error instanceof HttpError && error.status === 503
  );
  assert.equal(store.cards.size, 0);
});

test("the configured UPN claim resolves existing records by Graph OID, not SWA's per-app user ID", async () => {
  const store = createMemoryStore();
  const lookedUpEmails = [];
  const upnPrincipal = { ...principal, userDetails: emailClaim.val };
  const service = createBingoService({
    store,
    directory: {
      getUserByEmail: async (userEmail) => {
        lookedUpEmails.push(userEmail);
        return {
          id: entraObjectId,
          mail: userEmail,
          userPrincipalName: userEmail,
          officeLocation: "Example Campus"
        };
      }
    },
    env: baseEnv,
    now: () => new Date("2026-11-16T19:00:00.000Z")
  });

  await service.importCatalog(adminPrincipal);
  const existingCard = {
    partitionKey: entraObjectId,
    rowKey: "2026-11-16",
    experienceIdsJson: JSON.stringify(sourceExperiences.slice(0, 24).map(({ id }) => id)),
    markedIndicesJson: "[0,6]",
    version: 4,
    schoolKey: "example campus",
    schoolLabel: "Example Campus",
    createdAt: "2026-10-01T00:00:00.000Z",
    updatedAt: "2026-10-02T00:00:00.000Z",
    etag: "existing-card"
  };
  store.cards.set(`${entraObjectId}/2026-11-16`, existingCard);
  await service.getCard(upnPrincipal);

  assert.deepEqual(lookedUpEmails, [emailClaim.val, emailClaim.val]);
  assert.equal(store.cards.get(`${entraObjectId}/2026-11-16`).markedIndicesJson, "[0,6]");
  assert.equal(store.cards.get(`${entraObjectId}/2026-11-16`).version, 4);
  assert.equal(store.cards.get(`${entraObjectId}/2026-11-16`).etag, "existing-card");
  assert.equal(store.cards.size, 1);
  assert.ok(store.cards.has(`${entraObjectId}/2026-11-16`));
  assert.equal(store.cards.has(`${swaUserId}/2026-11-16`), false);
});

test("a reused email follows only Graph's current OID and cannot inherit the prior user's card", async () => {
  const store = createMemoryStore();
  const service = createBingoService({
    store,
    directory: directoryFor({ id: otherEntraObjectId }),
    env: baseEnv,
    now: () => new Date("2026-11-16T19:00:00.000Z")
  });
  await service.importCatalog(adminPrincipal);
  const previousCard = {
    partitionKey: entraObjectId,
    rowKey: "2026-11-16",
    experienceIdsJson: JSON.stringify(sourceExperiences.slice(0, 24).map(({ id }) => id)),
    markedIndicesJson: "[2,8]",
    version: 5,
    schoolKey: "example campus",
    schoolLabel: "Example Campus",
    createdAt: "2026-10-01T00:00:00.000Z",
    updatedAt: "2026-10-02T00:00:00.000Z",
    etag: "prior-user-card"
  };
  store.cards.set(`${entraObjectId}/2026-11-16`, previousCard);

  const newUserCard = await service.getCard(principal);
  assert.equal(newUserCard.version, 0);
  assert.equal(store.cards.get(`${otherEntraObjectId}/2026-11-16`).markedIndicesJson, "[]");
  assert.deepEqual(store.cards.get(`${entraObjectId}/2026-11-16`), previousCard);
});

test("Microsoft Graph resolves one matching configured email to its immutable OID", async () => {
  const requestUrls = [];
  let authorization;
  const directory = createDirectory(baseEnv, {
    credential: {
      getToken: async (scope) => {
        assert.equal(scope, "https://graph.microsoft.com/.default");
        return { token: "test-access-token" };
      }
    },
    fetchImpl: async (url, options) => {
      const requestUrl = new URL(url);
      requestUrls.push(requestUrl);
      authorization = options.headers.authorization;
      return {
        ok: true,
        json: async () => ({
          ...(requestUrl.pathname === "/v1.0/users"
            ? {
              value: [{
                id: entraObjectId,
                mail: "o'hara@example.test",
                userPrincipalName: "o'hara@example.test"
              }]
            }
            : { id: entraObjectId, officeLocation: "Example Campus", displayName: "Sample User" })
        })
      };
    }
  });

  const user = await directory.getUserByEmail("O'Hara@EXAMPLE.TEST");
  const [lookupUrl, profileUrl] = requestUrls;
  assert.equal(authorization, "Bearer test-access-token");
  assert.equal(lookupUrl.origin, "https://graph.microsoft.com");
  assert.equal(lookupUrl.pathname, "/v1.0/users");
  assert.equal(lookupUrl.searchParams.get("$select"), "id,mail,userPrincipalName,officeLocation");
  assert.equal(lookupUrl.searchParams.get("$top"), "2");
  assert.equal(profileUrl.pathname, `/v1.0/users/${entraObjectId}`);
  assert.equal(profileUrl.searchParams.get("$select"), "id,displayName,officeLocation");
  assert.equal(requestUrls.length, 2);
  const filter = lookupUrl.searchParams.get("$filter");
  assert.equal(filter, "mail eq 'o''hara@example.test' or userPrincipalName eq 'o''hara@example.test'");
  assert.equal(user.id, entraObjectId);
  assert.equal(user.officeLocation, "Example Campus");
  assert.equal(user.displayName, "Sample User");
  const byId = await directory.getUserById(entraObjectId);
  assert.equal(byId.displayName, "Sample User");
  assert.equal(requestUrls[2].pathname, `/v1.0/users/${entraObjectId}`);
});

test("Graph lookup fails closed for invalid email, missing or ambiguous users, mismatches, and Graph errors", async () => {
  let calls = 0;
  const makeDirectory = (result, response = { ok: true, json: async () => result }) => createDirectory(baseEnv, {
    credential: { getToken: async () => ({ token: "fake-test-access-token" }) },
    fetchImpl: async () => {
      calls += 1;
      return response;
    }
  });

  assert.throws(() => createDirectory({ ...baseEnv, BINGO_TENANT_ID: "" }), /Tenant and allowed email domain/);
  assert.throws(() => createDirectory({ ...baseEnv, BINGO_ALLOWED_EMAIL_DOMAIN: "*.example.test" }),
    /Tenant and allowed email domain/);

  await assert.rejects(
    makeDirectory({ value: [] }).getUserByEmail("outsider@other.test"),
    (error) => error.status === 403
  );
  await assert.rejects(
    makeDirectory({ value: [] }).getUserByEmail("staff@sub.example.test"),
    (error) => error.status === 403
  );
  await assert.rejects(
    makeDirectory({ value: [] }).getUserByEmail("sample.user@example.test.attacker"),
    (error) => error.status === 403
  );
  assert.equal(calls, 0);

  await assert.rejects(
    makeDirectory({ value: [] }).getUserByEmail(email),
    (error) => error.status === 404
  );
  await assert.rejects(
    makeDirectory({ value: [{ id: entraObjectId }, { id: otherEntraObjectId }] }).getUserByEmail(email),
    (error) => error.status === 409
  );
  await assert.rejects(
    makeDirectory({ value: [{ id: entraObjectId, mail: "someone-else@other.test" }] }).getUserByEmail(email),
    (error) => error.status === 403
  );
  await assert.rejects(
    makeDirectory({ value: [{ id: "not-an-oid", mail: email }] }).getUserByEmail(email),
    (error) => error.status === 403
  );
  await assert.rejects(
    createDirectory(baseEnv, {
      credential: { getToken: async () => ({ token: "fake-test-access-token" }) },
      fetchImpl: async (url) => new URL(url).pathname === "/v1.0/users"
        ? { ok: true, json: async () => ({ value: [{ id: entraObjectId, mail: email }] }) }
        : { ok: true, json: async () => ({ id: otherEntraObjectId, officeLocation: "Example Campus" }) }
    }).getUserByEmail(email),
    (error) => error.status === 403
  );
  await assert.rejects(
    makeDirectory(null, { ok: false, status: 403 }).getUserByEmail(email),
    /HTTP 403/
  );
  await assert.rejects(
    createDirectory(baseEnv, {
      credential: { getToken: async () => ({ token: "fake-test-access-token" }) },
      fetchImpl: async () => { throw new Error("network failure"); }
    }).getUserByEmail(email),
    /network failure/
  );
});

test("non-admin principals are denied every admin API operation before Graph or storage access", async () => {
  let graphLookups = 0;
  const service = createService({
    directory: { getUserByEmail: async () => { graphLookups += 1; return directoryFor().getUserByEmail(email); } }
  });
  const operations = [
    () => service.getAdminCatalog(principal),
    () => service.importCatalog(principal),
    () => service.createCatalogExperience(principal, {
      id: "unauthorized-example",
      text: "Should not be created",
      category: "Test",
      level: "staff"
    }),
    () => service.updateCatalogExperience(principal, "any-entry", { active: false })
  ];

  for (const operation of operations) {
    await assert.rejects(operation(), (error) => error instanceof HttpError && error.status === 403);
  }
  await assert.rejects(
    service.getAdminCatalog({ ...adminPrincipal, userRoles: ["anonymous", "authenticated", "Admin"] }),
    (error) => error instanceof HttpError && error.status === 403
  );
  assert.equal(graphLookups, 0);
});

test("marks use optimistic concurrency and only server-validated wins are recorded once", async () => {
  const store = createMemoryStore();
  const service = createBingoService({
    store,
    directory: directoryFor(),
    env: baseEnv,
    now: () => new Date("2026-11-16T19:00:00.000Z")
  });
  await service.importCatalog(adminPrincipal);
  let card = await service.getCard(principal);

  for (const squareIndex of [0, 1, 2, 3, 4]) {
    card = await service.setSquare(principal, {
      squareIndex,
      marked: true,
      expectedVersion: card.version
    });
  }

  assert.ok(card.bingos.includes("row-0"));
  assert.equal(card.bingoClaimed, true);
  assert.equal(store.winners.size, 1);
  const winner = [...store.winners.values()][0];
  assert.equal(winner.entraObjectId, entraObjectId);
  assert.equal(winner.schoolLabel, "Example Campus");
  assert.equal(typeof winner.createdAt, "string");

  const repeat = await service.setSquare(principal, {
    squareIndex: 4,
    marked: true,
    expectedVersion: 0
  });
  assert.equal(repeat.bingoClaimed, false);
  assert.equal(store.winners.size, 1);
  for (const forbidden of [
    { isWinner: true },
    { userId: "another-user" },
    { office: "another school" },
    { timestamp: "2000-01-01T00:00:00.000Z" }
  ]) {
    await assert.rejects(
      service.setSquare(principal, { squareIndex: 5, marked: true, expectedVersion: card.version, ...forbidden }),
      (error) => error instanceof HttpError && error.status === 400
    );
  }
  await assert.rejects(
    service.setSquare(principal, { squareIndex: 5, marked: true, expectedVersion: 0 }),
    (error) => error instanceof HttpError && error.status === 409
  );
});

test("school totals exclude cards without a verified office location", async () => {
  const service = await createSeededService({ directory: directoryFor({ officeLocation: "" }) });
  const card = await service.getCard(principal);
  const leaderboards = await service.getLeaderboards(principal);

  assert.equal(card.schoolAvailable, false);
  assert.deepEqual(leaderboards.school.entries, []);
  assert.match(leaderboards.school.note, /cards without one are excluded/i);
});

test("shared leaderboards contain no seeded entries before real scores exist", async () => {
  const service = await createSeededService();
  const leaderboards = await service.getLeaderboards(principal);

  assert.deepEqual(leaderboards.daily.entries, []);
  assert.deepEqual(leaderboards.overall.entries, []);
  assert.deepEqual(leaderboards.school.entries, []);
});

test("leaderboards use verified names and combine historical card points by school", async () => {
  const store = createMemoryStore();
  const thirdId = "00000000-0000-4000-8000-000000000007";
  const lookups = [];
  const service = createBingoService({
    store,
    directory: {
      ...directoryFor({ officeLocation: "" }),
      getUserById: async (id) => {
        lookups.push(id);
        return { id, displayName: id === otherEntraObjectId ? "Third User" : "Another User" };
      }
    },
    env: baseEnv,
    now: () => new Date("2026-11-16T19:00:00.000Z")
  });
  const put = (id, day, marks, schoolKey = "", schoolLabel = "") => {
    store.cards.set(`${id}/${day}`, {
      partitionKey: id, rowKey: day, markedIndicesJson: JSON.stringify(marks),
      schoolKey, schoolLabel, etag: "existing"
    });
  };
  put(entraObjectId, "2026-11-15", [0, 1], "example campus", "Example Campus");
  put(entraObjectId, "2026-11-16", [0]);
  put(otherEntraObjectId, "2026-11-15", [0, 1, 2], "example campus", "Example Campus");
  put(otherEntraObjectId, "2026-11-16", [0, 1], "another campus", "Another Campus");
  put(thirdId, "2026-11-16", [0, 1, 2, 3], "example campus", "Example Campus");

  const boards = await service.getLeaderboards(principal);
  assert.deepEqual(boards.daily.entries.map(({ name, score }) => [name, score]), [
    ["Another User", 4], ["Third User", 2], ["Sample User", 1]
  ]);
  assert.deepEqual(boards.overall.entries.map(({ name, score }) => [name, score]), [
    ["Third User", 5], ["Another User", 4], ["Sample User", 3]
  ]);
  assert.deepEqual(boards.school.entries.map(({ name, score }) => [name, score]), [
    ["Example Campus", 9], ["Another Campus", 2]
  ]);
  assert.deepEqual(new Set(lookups), new Set([otherEntraObjectId, thirdId]));
  assert.equal(lookups.length, 2);
  const serialized = JSON.stringify(boards);
  for (const secret of [entraObjectId, otherEntraObjectId, thirdId, email, otherEmail, "markedIndicesJson"]) {
    assert.equal(serialized.includes(secret), false);
  }
});

test("leaderboards reject unauthorized requests and missing or failed Graph profiles", async () => {
  const store = createMemoryStore();
  store.cards.set(`${otherEntraObjectId}/2026-11-16`, {
    partitionKey: otherEntraObjectId, rowKey: "2026-11-16", markedIndicesJson: "[0]"
  });
  let calls = 0;
  const directory = {
    ...directoryFor(),
    getUserById: async () => { calls++; throw new Error("private Graph details"); }
  };
  const service = createBingoService({ store, directory, env: baseEnv, now: () => new Date("2026-11-16T19:00:00Z") });
  await assert.rejects(service.getLeaderboards(null), (error) => error.status === 401);
  assert.equal(calls, 0);
  await assert.rejects(service.getLeaderboards(principal), (error) =>
    error.status === 503 && !error.message.includes("private Graph details"));
  directory.getUserById = async () => ({ id: otherEntraObjectId, displayName: "" });
  await assert.rejects(service.getLeaderboards(principal), (error) => error.status === 503 && /display name/.test(error.message));
  directory.getUserById = async () => ({ id: otherEntraObjectId, displayName: otherEmail });
  await assert.rejects(service.getLeaderboards(principal), (error) => error.status === 503 && !error.message.includes(otherEmail));
  directory.getUserById = async () => ({ id: entraObjectId, displayName: "Wrong person" });
  await assert.rejects(service.getLeaderboards(principal), (error) => error.status === 503);
});

test("school leaderboard scope follows the latest server-side Graph office", async () => {
  const store = createMemoryStore();
  let officeLocation = "Example Campus";
  const service = createBingoService({
    store,
    directory: { getUserByEmail: async (userEmail) => ({
      id: entraObjectId,
      mail: userEmail,
      userPrincipalName: userEmail,
      officeLocation,
      displayName: "Sample User"
    }) },
    env: baseEnv,
    now: () => new Date("2026-11-16T19:00:00.000Z")
  });
  await service.importCatalog(adminPrincipal);
  await service.getCard(principal);
  officeLocation = "Another Campus";
  const leaderboards = await service.getLeaderboards(principal);
  const currentSquares = store.cards.get(`${entraObjectId}/2026-11-16`);

  assert.equal(leaderboards.school.entries[0].name, "Another Campus");
  assert.equal(currentSquares.schoolKey, "another campus");
});

test("school synchronization retries concurrent mark updates without losing them", async () => {
  const store = createMemoryStore();
  const updateCard = store.updateCard.bind(store);
  let conflictOnce = true;
  let officeLocation = "Example Campus";
  store.updateCard = async (entity, etag) => {
    if (conflictOnce) {
      conflictOnce = false;
      const current = store.cards.get(`${entity.partitionKey}/${entity.rowKey}`);
      store.cards.set(`${entity.partitionKey}/${entity.rowKey}`, {
        ...current,
        markedIndicesJson: "[7]",
        version: 1,
        etag: "card-etag-concurrent"
      });
      const error = new Error("Precondition failed.");
      error.status = 412;
      throw error;
    }
    return updateCard(entity, etag);
  };
  const service = createBingoService({
    store,
    directory: { getUserByEmail: async (userEmail) => ({
      id: entraObjectId,
      mail: userEmail,
      userPrincipalName: userEmail,
      officeLocation,
      displayName: "Sample User"
    }) },
    env: baseEnv,
    now: () => new Date("2026-11-16T19:00:00.000Z")
  });

  await service.importCatalog(adminPrincipal);
  await service.getCard(principal);
  officeLocation = "Another Campus";
  const leaderboards = await service.getLeaderboards(principal);
  const currentSquares = store.cards.get(`${entraObjectId}/2026-11-16`);

  assert.equal(leaderboards.school.entries[0].name, "Another Campus");
  assert.equal(currentSquares.schoolKey, "another campus");
  assert.equal(currentSquares.markedIndicesJson, "[7]");
  assert.equal(currentSquares.version, 1);
});

test("catalog import is explicit, idempotent, and safe while multiplayer is disabled", async () => {
  const env = { ...baseEnv, BINGO_MULTIPLAYER_ENABLED: "false" };
  const service = createService({ env });

  await assert.rejects(
    service.importCatalog(principal),
    (error) => error instanceof HttpError && error.status === 403
  );
  const firstImport = await service.importCatalog(adminPrincipal);
  const secondImport = await service.importCatalog(adminPrincipal);
  assert.equal(firstImport.created, sourceExperiences.length);
  assert.equal(firstImport.existing, 0);
  assert.equal(secondImport.created, 0);
  assert.equal(secondImport.existing, sourceExperiences.length);
  await assert.rejects(
    service.getCard(principal),
    (error) => error instanceof HttpError && error.status === 503
  );

  env.BINGO_MULTIPLAYER_ENABLED = "true";
  const activeCatalog = await service.getCatalog(principal);
  assert.equal(activeCatalog.length, 500);
  assert.equal(activeCatalog.filter(({ level }) => level === "student").length, 250);
  assert.equal(activeCatalog.filter(({ level }) => level === "staff").length, 250);
  assert.ok(activeCatalog.every(({ active, moderationState }) => active && moderationState === "approved"));
  const card = await service.getCard(principal);
  const cardExperience = card.catalog.find(({ id }) => id === card.card[0].experienceId);
  const seededExperience = sourceExperiences.find(({ id }) => id === cardExperience.id);
  assert.equal(cardExperience.text, seededExperience.title);
  assert.equal(cardExperience.level, seededExperience.audience);
});

test("teacher suggestions remain pending and never enter cards before approval", async () => {
  const store = createMemoryStore();
  const service = createBingoService({
    store,
    directory: { getUserByEmail: async (userEmail) => ({
      id: userEmail.toLowerCase() === otherEmail ? otherEntraObjectId : entraObjectId,
      mail: userEmail,
      userPrincipalName: userEmail,
      officeLocation: "Example Campus"
    }) },
    env: baseEnv,
    now: () => new Date("2026-11-16T19:00:00.000Z")
  });
  await service.importCatalog(adminPrincipal);
  const keptIds = new Set();
  const levels = { student: 0, staff: 0 };
  for (const [id, experience] of store.catalog) {
    if (levels[experience.level] < 12) {
      keptIds.add(id);
      levels[experience.level] += 1;
    }
  }
  for (const id of store.catalog.keys()) {
    if (!keptIds.has(id)) store.catalog.delete(id);
  }

  const suggestion = await service.submitSuggestion(principal, {
    text: "A student shares a cheerful discovery",
    category: "Learning & Curiosity",
    level: "student"
  });
  const saved = store.catalog.get(suggestion.id);
  assert.equal(saved.submittedBy, entraObjectId);
  assert.equal(saved.active, false);
  assert.equal(saved.moderationState, "pending");
  assert.equal(saved.createdAt, "2026-11-16T19:00:00.000Z");
  assert.deepEqual(await service.getMySuggestions(principal), [{
    id: suggestion.id,
    text: suggestion.text,
    category: suggestion.category,
    level: suggestion.level,
    moderationState: "pending",
    createdAt: suggestion.createdAt
  }]);
  const otherTeacher = {
    ...principal,
    userDetails: otherEmail
  };
  assert.deepEqual(await service.getMySuggestions(otherTeacher), []);
  await assert.rejects(
    service.submitSuggestion(principal, {
      text: "A square with forged status",
      category: "Unsafe",
      level: "student",
      active: true,
      moderationState: "approved",
      submittedBy: "another-user"
    }),
    (error) => error instanceof HttpError && error.status === 400
  );

  const card = await service.getCard(principal);
  assert.equal(card.catalog.length, 24);
  assert.equal(card.catalog.some(({ id }) => id === suggestion.id), false);
  assert.equal((await service.getCatalog(principal)).some(({ id }) => id === suggestion.id), false);
});

test("admins cannot approve their own suggestions but can moderate other teachers' submissions", async () => {
  const service = await createSeededService();
  const ownSuggestion = await service.submitSuggestion(adminPrincipal, {
    text: "An administrator's own suggestion",
    category: "Kindness & Community",
    level: "staff"
  });
  assert.equal(
    (await service.getAdminCatalog(adminPrincipal)).find(({ id }) => id === ownSuggestion.id).isOwnSuggestion,
    true
  );

  await assert.rejects(
    service.updateCatalogExperience(adminPrincipal, ownSuggestion.id, {
      active: true,
      moderationState: "approved"
    }),
    (error) => error instanceof HttpError && error.status === 403
  );

  const teacherPrincipal = { ...principal, userDetails: otherEmail };
  const teacherSuggestion = await service.submitSuggestion(teacherPrincipal, {
    text: "A teacher's community moment",
    category: "Kindness & Community",
    level: "staff"
  });
  assert.equal(
    (await service.getAdminCatalog(adminPrincipal)).find(({ id }) => id === teacherSuggestion.id).isOwnSuggestion,
    false
  );
  const approved = await service.updateCatalogExperience(adminPrincipal, teacherSuggestion.id, {
    active: true,
    moderationState: "approved"
  });
  assert.equal(approved.moderatedBy, entraObjectId);
  assert.equal(approved.moderationState, "approved");
  assert.equal((await service.getCatalog(principal)).some(({ id }) => id === teacherSuggestion.id), true);

  const rejected = await service.updateCatalogExperience(adminPrincipal, teacherSuggestion.id, {
    moderationState: "rejected"
  });
  assert.equal(rejected.active, false);
  assert.equal(rejected.moderationState, "rejected");
  assert.equal((await service.getCatalog(principal)).some(({ id }) => id === teacherSuggestion.id), false);
});

test("only admins manage catalog; active approved experiences are the public read view", async () => {
  const service = await createSeededService();
  const body = {
    id: "admin-created-example",
    text: "A new example from the catalog administrator",
    category: "Admin examples",
    level: "student"
  };
  await assert.rejects(
    service.createCatalogExperience(principal, body),
    (error) => error instanceof HttpError && error.status === 403
  );
  await assert.rejects(
    service.getAdminCatalog(principal),
    (error) => error instanceof HttpError && error.status === 403
  );
  await assert.rejects(
    service.importCatalog(principal),
    (error) => error instanceof HttpError && error.status === 403
  );

  const created = await service.createCatalogExperience(adminPrincipal, body);
  assert.equal(created.active, false);
  assert.equal(created.moderationState, "pending");
  assert.equal((await service.getCatalog(principal)).some(({ id }) => id === body.id), false);

  await assert.rejects(
    service.updateCatalogExperience(principal, body.id, { active: true, moderationState: "approved" }),
    (error) => error instanceof HttpError && error.status === 403
  );
  await assert.rejects(
    service.createCatalogExperience(adminPrincipal, { ...body, userId: principal.userId }),
    (error) => error instanceof HttpError && error.status === 400
  );

  const approved = await service.updateCatalogExperience(adminPrincipal, body.id, {
    active: true,
    moderationState: "approved"
  });
  assert.equal(approved.active, true);
  assert.equal((await service.getCatalog(principal)).some(({ id }) => id === body.id), true);

  const edited = await service.updateCatalogExperience(adminPrincipal, body.id, {
    text: "An edited admin-approved square"
  });
  assert.equal(edited.text, "An edited admin-approved square");
  await service.updateCatalogExperience(adminPrincipal, body.id, { active: false });
  assert.equal((await service.getCatalog(principal)).some(({ id }) => id === body.id), false);
  assert.equal((await service.getAdminCatalog(adminPrincipal)).some(({ id, active }) => id === body.id && !active), true);
});

test("catalog re-import never overwrites admin edits or moderation state", async () => {
  const service = await createSeededService();
  const [record] = await service.getAdminCatalog(adminPrincipal);
  await service.updateCatalogExperience(adminPrincipal, record.id, {
    text: "Admin-edited text",
    active: false,
    moderationState: "rejected"
  });

  const result = await service.importCatalog(adminPrincipal);
  const updated = (await service.getAdminCatalog(adminPrincipal)).find(({ id }) => id === record.id);

  assert.equal(result.created, 0);
  assert.equal(updated.text, "Admin-edited text");
  assert.equal(updated.active, false);
  assert.equal(updated.moderationState, "rejected");
});

test("catalog import leaves legacy entries outside the new bundle untouched", async () => {
  const store = createMemoryStore();
  const legacyRecord = {
    id: "kindness-community-01",
    text: "Previously active library entry",
    category: "Legacy category",
    level: "student",
    rarity: "rare",
    active: false,
    moderationState: "rejected"
  };
  await store.createCatalogExperience(legacyRecord);
  const before = store.catalog.get(legacyRecord.id);
  const service = createBingoService({
    store,
    directory: directoryFor(),
    env: baseEnv,
    now: () => new Date("2026-11-16T19:00:00.000Z")
  });

  const result = await service.importCatalog(adminPrincipal);
  assert.equal(result.created, 500);
  assert.equal(result.existing, 0);
  assert.deepEqual(store.catalog.get(legacyRecord.id), before);
});

test("authorization requires an authenticated configured directory identity", async () => {
  const service = createService();
  await assert.rejects(
    service.getCard({ ...principal, userRoles: ["anonymous"] }),
    (error) => error instanceof HttpError && error.status === 401
  );
  await assert.rejects(
    service.getCard({ ...principal, identityProvider: "github" }),
    (error) => error instanceof HttpError && error.status === 401
  );
  await assert.rejects(
    createService({ env: { ...baseEnv, BINGO_TENANT_ID: "" } }).getCard(principal),
    (error) => error instanceof HttpError && error.status === 503
  );
  await assert.rejects(
    createService({ env: { ...baseEnv, BINGO_ALLOWED_EMAIL_DOMAIN: undefined } }).getCard(principal),
    (error) => error instanceof HttpError && error.status === 503
  );
  await assert.rejects(
    createService({ directory: { getUserByEmail: async () => { const error = new Error("missing"); error.status = 404; throw error; } } }).getCard(principal),
    (error) => error instanceof HttpError && error.status === 403
  );
  await assert.rejects(
    createService({ directory: { getUserByEmail: async () => { const error = new Error("ambiguous"); error.status = 409; throw error; } } }).getCard(principal),
    (error) => error instanceof HttpError && error.status === 403
  );
  await assert.rejects(
    createService({ directory: { getUserByEmail: async () => { throw new Error("unavailable"); } } }).getCard(principal),
    (error) => error instanceof HttpError && error.status === 503
  );
  await assert.rejects(
    createService({ directory: { getUserByEmail: async () => ({
      id: "not-an-oid",
      mail: email,
      userPrincipalName: email,
      officeLocation: "Example Campus"
    }) } }).getCard(principal),
    (error) => error instanceof HttpError && error.status === 403
  );
  await assert.rejects(
    createService({ directory: { getUserByEmail: async () => ({
      id: otherEntraObjectId,
      mail: otherEmail,
      userPrincipalName: otherEmail,
      officeLocation: "Example Campus"
    }) } }).getCard(principal),
    (error) => error instanceof HttpError && error.status === 403
  );
});
