import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { experiences } from "../src/data/experiences.js";
import { countMarkedSquares, createDailyCard, detectBingos } from "../src/game.js";
import { createInitialState, LocalDemoApi } from "../src/services/demo-api.js";
import { getLoginRedirectUrl, selectStartupMode } from "../src/services/startup-mode.js";
import { formatEdmontonDate, getEdmontonDateKey } from "../src/time.js";

function parseCsv(input) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  const source = input.replace(/^\uFEFF/, "");
  for (let index = 0; index < source.length; index += 1) {
    const character = source[index];
    if (quoted) {
      if (character === '"' && source[index + 1] === '"') {
        cell += '"';
        index += 1;
      } else if (character === '"') {
        quoted = false;
      } else {
        cell += character;
      }
    } else if (character === '"' && cell.length === 0) {
      quoted = true;
    } else if (character === ",") {
      row.push(cell);
      cell = "";
    } else if (character === "\r" || character === "\n") {
      if (character === "\r" && source[index + 1] === "\n") index += 1;
      row.push(cell);
      if (row.some((value) => value !== "")) rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += character;
    }
  }
  if (cell || row.length) {
    row.push(cell);
    rows.push(row);
  }
  const [headers, ...records] = rows;
  return records.map((values) => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])));
}

const csvRows = parseCsv(readFileSync(new URL("../src/data/staff-classroom-bingo-500.csv", import.meta.url), "utf8"));

test("the 500-row CSV is normalized without losing sayings or category metadata", () => {
  assert.equal(csvRows.length, 500);
  assert.deepEqual(Object.keys(csvRows[0]), ["id", "text", "category"]);
  assert.equal(experiences.length, 500);
  assert.equal(new Set(experiences.map(({ id }) => id)).size, experiences.length);
  assert.equal(new Set(experiences.map(({ title }) => title.toLocaleLowerCase())).size, experiences.length);
  assert.equal(new Set(experiences.map(({ category }) => category)).size, 10);
  assert.equal(experiences.filter(({ audience }) => audience === "student").length, 250);
  assert.equal(experiences.filter(({ audience }) => audience === "staff").length, 250);
  assert.ok(experiences.every(({ title, category }) => title.trim() && title.length <= 300 && category.trim()));
  csvRows.forEach((row) => {
    const experience = experiences.find(({ id }) => id === `staffroom-bingo-${row.id.padStart(3, "0")}`);
    assert.ok(experience, `missing CSV row ${row.id}`);
    assert.equal(experience.title, row.text.trim());
    assert.equal(experience.category, row.category);
    assert.equal(experience.description, row.text.trim());
  });
  assert.equal(experiences[0].title, "A student asks, “Is this for marks?” before you finish the first sentence.");
  assert.equal(experiences.at(-1).title, "At the end of the day, something went better than anyone expected.");
});

test("the supplied sayings preserve their lighthearted school-day voice", () => {
  const titles = experiences.map(({ title }) => title);
  assert.ok(titles.some((title) => title.includes("Is this for marks?")));
  assert.ok(titles.some((title) => title.includes("Wonderwall")));
  assert.ok(titles.some((title) => title.includes("That was hard, but good.")));
  assert.ok(titles.includes("Invite a student to mirror an overdramatic pose."));
  assert.equal(titles.some((title) => /finger pistols/i.test(title)), false);
});

test("daily cards are stable by date, varied across dates, and include the free square", () => {
  const first = createDailyCard("2026-11-16", experiences);
  const repeat = createDailyCard("2026-11-16", experiences);
  const nextDay = createDailyCard("2026-11-17", experiences);
  assert.deepEqual(first, repeat);
  assert.equal(first.length, 25);
  assert.deepEqual(first[12], { experienceId: null, marked: true });
  assert.equal(new Set(first.filter((square) => square.experienceId).map((square) => square.experienceId)).size, 24);
  const audienceById = new Map(experiences.map(({ id, audience }) => [id, audience]));
  const audiences = first.filter((square) => square.experienceId).map(({ experienceId }) => audienceById.get(experienceId));
  assert.equal(audiences.filter((audience) => audience === "student").length, 12);
  assert.equal(audiences.filter((audience) => audience === "staff").length, 12);
  assert.notDeepEqual(first, nextDay);
});

test("bingo detection recognizes rows, columns, and both diagonals", () => {
  const card = Array.from({ length: 25 }, (_, index) => ({ marked: index === 12 }));
  assert.deepEqual(detectBingos(card), []);

  [0, 1, 2, 3, 4].forEach((index) => { card[index].marked = true; });
  [2, 7, 17, 22].forEach((index) => { card[index].marked = true; });
  [6, 8, 16, 18, 24].forEach((index) => { card[index].marked = true; });
  [4, 8, 16, 20].forEach((index) => { card[index].marked = true; });
  const lines = detectBingos(card);
  assert.ok(lines.includes("row-0"));
  assert.ok(lines.includes("column-2"));
  assert.ok(lines.includes("diagonal-forward"));
  assert.ok(lines.includes("diagonal-backward"));
});

test("marked count excludes the pre-marked free space", () => {
  const card = Array.from({ length: 25 }, (_, index) => ({ marked: index === 12 || index === 0 }));
  assert.equal(countMarkedSquares(card), 1);
});

test("date key and display date use the Edmonton timezone", () => {
  const instant = new Date("2026-01-01T06:30:00.000Z");
  assert.equal(getEdmontonDateKey(instant), "2025-12-31");
  assert.match(formatEdmontonDate(instant), /December 31/);
});

test("daily card rejects a catalog too small to fill all non-free spaces", () => {
  assert.throws(() => createDailyCard("2026-11-16", experiences.slice(0, 23)), RangeError);
});

test("local leaderboards contain only this browser's scores and no seeded sample players", async () => {
  const api = new LocalDemoApi({ getItem: () => null, setItem() {}, removeItem() {} });
  const leaderboards = await api.getDemoLeaderboards({ dailyPoints: 4, overallPoints: 12 });

  assert.deepEqual(Object.keys(leaderboards), ["daily", "overall", "school"]);
  assert.equal(leaderboards.daily.entries.find(({ name }) => name === "You · this browser").score, 4);
  assert.equal(leaderboards.overall.entries.find(({ name }) => name === "You · this browser").score, 12);
  assert.equal(leaderboards.daily.entries.length, 1);
  assert.equal(leaderboards.overall.entries.length, 1);
  assert.deepEqual(leaderboards.school.entries, []);
  assert.match(leaderboards.school.caption, /unavailable/i);
});

test("startup automatically chooses authenticated multiplayer, otherwise stays local-only or unavailable", () => {
  assert.equal(selectStartupMode({
    hostname: "bingo.example.org",
    multiplayerEnabled: true,
    authenticated: true
  }), "multiplayer");
  assert.equal(selectStartupMode({
    hostname: "bingo.example.org",
    multiplayerEnabled: true,
    authenticated: false
  }), "login");
  assert.equal(selectStartupMode({
    hostname: "bingo.example.org",
    multiplayerEnabled: false,
    authenticated: false
  }), "unavailable");
  assert.equal(selectStartupMode({
    hostname: "localhost",
    multiplayerEnabled: false,
    authenticated: false
  }), "local-demo");
  assert.equal(getLoginRedirectUrl(), "/.auth/login/aad?post_login_redirect_uri=%2F");
});

test("loading pre-leaderboard demo data initializes overall points from marked squares", async () => {
  const legacyState = createInitialState("2026-11-16");
  delete legacyState.overallPoints;
  legacyState.card = Array.from({ length: 25 }, (_, index) => ({ marked: index === 0 || index === 12 || index === 24 }));
  const api = new LocalDemoApi({ getItem: () => JSON.stringify(legacyState), setItem() {}, removeItem() {} });

  const state = await api.loadState("2026-11-16");
  assert.equal(state.overallPoints, 2);
});
